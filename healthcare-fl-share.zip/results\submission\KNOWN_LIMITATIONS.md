# Known Limitations & Empirical Context

This document outlines the methodological, computational, and clinical limitations of the `healthcare-fl` research platform to ensure transparent interpretation of all reported findings.

---

## 1. Academic Simulation vs. Operational Healthcare Environments

> [!WARNING]
> This platform is an **academic simulation** developed for algorithmic benchmarking of privacy-preserving federated learning. It is **not** approved clinical diagnostic software and must not be used for diagnostic decision-making or patient triage.

- **Synthetic Hospital Silos:** The five hospital clients are synthetic, patient-isolated partitions constructed from a single public benchmark dataset (NIH ChestX-ray14) and executed in a local Python environment. They do not represent distinct physical hospital networks.
- **Physical Network and Infrastructure:** In an operational healthcare deployment, federated learning operates across geographically dispersed hospital systems subject to varying network latency, firewall rules, disparate hardware accelerators, and intermittent client availability.
- **Data Integration:** Clinical deployment requires direct integration with Hospital Information Systems (HIS), Electronic Health Records (EHR), and Picture Archiving and Communication Systems (PACS) conforming to DICOM and HL7/FHIR standards, rather than pre-extracted 2D PNG radiographs.

---

## 2. Dataset Scope & Cohort Construction

- **Single-Source Public Dataset:** All radiographs originate from the NIH ChestX-ray14 dataset. Although client cohorts were partitioned to enforce patient disjointness, the underlying image acquisition physics (scanner manufacturers, detector types, beam energies) and patient demographics reflect the single originating institution.
- **Absence of Real Cross-Center Domain Shift:** Genuine multi-center clinical deployments encounter significant domain shift across scanner vendors, imaging protocols, and patient populations. A single-source benchmark cannot evaluate out-of-distribution generalization across distinct clinical health systems.
- **Test Set Construction & Scale ($N=30$):**
  - The held-out centralized test set consists of 30 scans (15 Pneumonia, 15 Clean Controls) subsampled from the NIH metadata under strict patient isolation from all client cohorts.
  - While $N=30$ is sufficient to provide an isolated comparative signal across baselines without test set leakage, each individual scan accounts for $3.33\%$ of the evaluation metric.
  - A shift of 1–2 false negatives or false positives causes large discrete jumps in precision ($\pm 8.3\%$) and recall ($\pm 6.7\%$). Fine-grained discrimination differences should be interpreted with this sample size constraint in mind.

---

## 3. Privacy Budget Scope & Interpretation ($\epsilon = 9.9496$)

- **Formal Theoretical Scope:** Differential privacy provides a mathematically provable upper bound on the privacy loss random variable between adjacent datasets differing by one patient.
- **Magnitude of Epsilon:** In theoretical differential privacy literature, values of $\epsilon < 1.0$ are typically preferred for strong worst-case protection against arbitrary adversaries. In contrast, deep learning deployments on high-dimensional image data frequently operate in the range $\epsilon \in [2, 10]$ due to gradient noise trade-offs.
- **Threat Model Dependence:** An $\epsilon = 9.9496$ at $\delta = 10^{-5}$ bounds the ratio of output probabilities by $e^{9.95} \approx 20,950$. Whether this provides meaningful protection in practice depends on the adversary's background knowledge, threat model, and specific attack capabilities (e.g., membership inference vs. attribute reconstruction). It should not be interpreted as an absolute barrier against all empirical inference risks.

---

## 4. Default Decision Thresholds under DP-SGD

- **Observed Probability Distributions:** Across all differential privacy experiments, output probabilities on both the client validation sets and the held-out test set remained below 0.50. Under the fixed decision rule $\hat{y} = \mathbb{I}(p \ge 0.50)$, all predictions were assigned to the negative class.
- **Threshold Sensitivity vs. Ranking:** While threshold-dependent metrics (F1 = 0.0000, Accuracy = 50.00%) reflect the uncalibrated hard threshold, threshold-independent metrics (validation ROC-AUC 0.6167–0.7278) indicate non-random probability ranking.
- **Need for Validation Calibration:** In practical applications of DP-SGD, decision thresholds should be calibrated on independent validation data (e.g., using Youden's $J$ index or precision-recall targets) rather than relying on an arbitrary default cutoff of 0.50.

---

## 5. Checkpoint Selection Trade-Off in the 3-Epoch Experiment

- **Protocol Constraint:** Global checkpoints were selected strictly by highest mean client validation F1 at fixed threshold $0.50$, retaining the earliest round on ties. Secondary metrics (loss or ROC-AUC) were explicitly prohibited from breaking ties.
- **Consequence for `fedavg_dp_3epoch`:**
  - Round 1 achieved Validation F1 = 0.0000 and Validation ROC-AUC = 0.6167.
  - Round 2 achieved Validation F1 = 0.0000 and Validation ROC-AUC = 0.7278.
  - Under the earliest-tie protocol, **Round 1 was selected as the final checkpoint**.
  - Therefore, the model evaluated on the held-out test set (achieving test ROC-AUC = 0.5067) was the Round 1 model, **not** the Round 2 model. The higher validation ROC-AUC observed in Round 2 was not selected under the F1-based protocol.

---

## 6. Binary Pathology Simplification

- **Single Target vs. Comorbidity:** Chest radiographs routinely exhibit multiple co-occurring cardiopulmonary pathologies (e.g., Pneumonia presenting concurrently with Pleural Effusion, Infiltration, or Atelectasis).
- **Clean Control Restriction:** Negative controls were restricted to patients who had "No Finding" and no record of pneumonia in any scan across the dataset. While scientifically clean for baseline benchmarking, real-world clinical workflows require distinguishing pneumonia from other pulmonary opacities.
