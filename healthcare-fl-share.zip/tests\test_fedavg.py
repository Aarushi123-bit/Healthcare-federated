"""Unit and integration tests for Flower FedAvg baseline modules.

Verifies:
1. Model weight NumPy serialization and deserialization.
2. Flower FedAvg weighted parameter aggregation arithmetic.
3. Patient-level isolation across clients, splits, and centralized test set.
4. Protection of production centralized baseline artifacts.
5. End-to-end 1-round smoke test of the federated pipeline.
"""

from collections import OrderedDict
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
import torch
from flwr.server.strategy.aggregate import aggregate

from clients.hospital_client import HospitalClient
from experiments.fedavg_baseline import build_client_cohorts, run_fedavg_experiment
from models.cnn import SmallChestXrayCNN


def test_parameter_round_trip():
    """Verify that SmallChestXrayCNN parameters serialize and deserialize losslessly."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    orig_params = [v.clone().cpu().numpy() for _, v in model.state_dict().items()]

    # Convert back to state_dict
    state_dict = OrderedDict(
        {k: torch.as_tensor(v) for k, v in zip(model.state_dict().keys(), orig_params)}
    )
    new_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    new_model.load_state_dict(state_dict, strict=True)

    for (k1, v1), (k2, v2) in zip(model.state_dict().items(), new_model.state_dict().items()):
        assert k1 == k2
        assert torch.allclose(v1, v2)


def test_flower_fedavg_weighted_aggregation():
    """Verify Flower's aggregate() computes exact sample-weighted parameter averages."""
    # Two client parameter updates:
    # Client 1: [1.0, 2.0], sample count = 10
    # Client 2: [5.0, 6.0], sample count = 30
    # Total samples = 40
    # Expected: (10 * [1, 2] + 30 * [5, 6]) / 40 = (0.25 * [1, 2]) + (0.75 * [5, 6]) = [4.0, 5.0]
    w1 = [np.array([1.0, 2.0], dtype=np.float32)]
    w2 = [np.array([5.0, 6.0], dtype=np.float32)]

    results = [(w1, 10), (w2, 30)]
    aggregated = aggregate(results)

    assert len(aggregated) == 1
    expected = np.array([4.0, 5.0], dtype=np.float32)
    assert np.allclose(aggregated[0], expected)


def test_client_cohort_disjointness_and_test_isolation(tmp_path):
    """Verify patient-level isolation and clean control filtering in build_client_cohorts."""
    base_dir = Path(__file__).resolve().parent.parent
    proc_dir = base_dir / "data" / "processed"
    cent_dir = base_dir / "results" / "centralized_baseline"

    test_df = pd.read_csv(cent_dir / "test_split.csv")
    test_pts = set(test_df["Patient ID"])

    # Build dummy image index containing names from manifests
    image_index = {}
    for c in range(1, 6):
        m = pd.read_csv(proc_dir / f"hospital_client_{c}_manifest.csv")
        for name in m["Image Index"]:
            image_index[name] = {"relative_path": f"images_001/images/{name}"}

    client_cohorts = build_client_cohorts(
        manifests_dir=proc_dir,
        image_index=image_index,
        test_patient_ids=test_pts,
        output_dir=tmp_path,
        samples_per_client=10,
        val_ratio=0.2,
        seed=42,
    )

    all_train_pts = set()
    all_val_pts = set()

    for c in range(1, 6):
        client_name = f"hospital_{c}"
        train_df = client_cohorts[client_name]["train"]
        val_df = client_cohorts[client_name]["val"]

        c_train_pts = set(train_df["Patient ID"])
        c_val_pts = set(val_df["Patient ID"])

        # No overlap between local train and local val
        assert len(c_train_pts.intersection(c_val_pts)) == 0

        # No overlap with centralized held-out test patients
        assert len(c_train_pts.intersection(test_pts)) == 0
        assert len(c_val_pts.intersection(test_pts)) == 0

        # No cross-client patient leakage
        assert len(c_train_pts.intersection(all_train_pts)) == 0
        assert len(c_val_pts.intersection(all_val_pts)) == 0

        all_train_pts.update(c_train_pts)
        all_val_pts.update(c_val_pts)

        # Manifest files were created in tmp_path
        assert (tmp_path / f"client_{c}_train.csv").exists()
        assert (tmp_path / f"client_{c}_val.csv").exists()


def test_production_centralized_artifacts_remain_untouched():
    """Verify that centralized baseline production artifacts exist and are not modified."""
    base_dir = Path(__file__).resolve().parent.parent
    cent_dir = base_dir / "results" / "centralized_baseline"

    expected_files = [
        "centralized_cnn_checkpoint.pt",
        "centralized_training_history.json",
        "task-190_recovered_baseline_record.json",
        "test_split.csv",
        "train_split.csv",
        "val_split.csv",
    ]

    for fname in expected_files:
        fpath = cent_dir / fname
        assert fpath.exists(), f"Production centralized file missing: {fname}"
        assert fpath.stat().st_size > 0, f"Production centralized file is empty: {fname}"


def test_fedavg_1_round_smoke(tmp_path):
    """Smoke test: 1 round of FedAvg across 5 clients, writing strictly to tmp_path."""
    history = run_fedavg_experiment(
        num_rounds=1,
        local_epochs=1,
        samples_per_client=10,
        batch_size=8,
        learning_rate=1e-3,
        seed=42,
        output_dir=tmp_path,
    )

    # 1. Output artifacts created in tmp_path
    checkpoint_path = tmp_path / "fedavg_global_model.pt"
    history_path = tmp_path / "fedavg_training_history.json"
    assert checkpoint_path.exists(), "Global model checkpoint missing!"
    assert history_path.exists(), "Federated history JSON missing!"
    assert checkpoint_path.stat().st_size > 400_000

    # 2. Check client manifests in tmp_path
    for c in range(1, 6):
        assert (tmp_path / f"client_{c}_train.csv").exists()
        assert (tmp_path / f"client_{c}_val.csv").exists()

    # 3. Validate history structure
    assert history["num_rounds"] == 1
    assert history["num_clients"] == 5
    assert history["best_round"] == 1
    assert len(history["rounds"]) == 1

    round_1 = history["rounds"][0]
    assert "mean_val_metrics" in round_1
    mean_val = round_1["mean_val_metrics"]
    assert "mean_val_f1" in mean_val
    assert "mean_val_loss" in mean_val

    # 4. Validate held-out test metrics evaluated strictly once
    assert "held_out_test_metrics" in history
    test_metrics = history["held_out_test_metrics"]
    assert test_metrics["sample_count"] == 30
    assert 0.0 <= test_metrics["accuracy"] <= 1.0
    assert 0.0 <= test_metrics["f1_score"] <= 1.0
    assert len(test_metrics["confusion_matrix"]) == 2
