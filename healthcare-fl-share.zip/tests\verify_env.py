"""Verification script for Phase 0 environment setup."""

import sys
import torch
import flwr
import opacus
import sklearn
import pandas
import numpy
import matplotlib


def main():
    print("=" * 60)
    print("ENVIRONMENT & PACKAGE VERIFICATION")
    print("=" * 60)
    print(f"Python Executable : {sys.executable}")
    print(f"Python Version    : {sys.version.split()[0]}")
    print("-" * 60)
    print(f"PyTorch           : {torch.__version__}")
    print(f"Flower (flwr)     : {flwr.__version__}")
    print(f"Opacus            : {opacus.__version__}")
    print(f"Scikit-Learn      : {sklearn.__version__}")
    print(f"Pandas            : {pandas.__version__}")
    print(f"NumPy             : {numpy.__version__}")
    print(f"Matplotlib        : {matplotlib.__version__}")
    print("-" * 60)

    # PyTorch Tensor Operation Test
    print("Running PyTorch tensor operation verification...")
    t_a = torch.randn(2, 3)
    t_b = torch.randn(3, 2)
    t_out = torch.matmul(t_a, t_b)
    print(f"Tensor dot product shape: {t_out.shape}")
    print(f"Tensor sum value        : {t_out.sum().item():.4f}")

    # Opacus + PyTorch DP-SGD ModuleValidator Test
    print("Running Opacus DP-SGD compatibility verification...")
    linear = torch.nn.Linear(10, 2)
    is_valid = opacus.validators.ModuleValidator.is_valid(linear)
    print(f"Linear layer Opacus-compliant: {is_valid}")

    print("=" * 60)
    print("STATUS: ALL CHECKS PASSED SUCCESSFULLY")
    print("=" * 60)


if __name__ == "__main__":
    main()
