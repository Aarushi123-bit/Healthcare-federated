"""Diagnostic Convolutional Neural Network for grayscale Chest X-ray images.

Designed for Opacus Differential Privacy (DP-SGD) compatibility:
- Accepts single-channel (grayscale) inputs of configurable dimensions (e.g., 224x224).
- Uses GroupNorm instead of BatchNorm to avoid sample-mixing gradients during DP-SGD.
- Outputs multi-label logits corresponding to the 14 official NIH pathologies.
"""

from typing import List
import torch
import torch.nn as nn


class SmallChestXrayCNN(nn.Module):
    """Compact Convolutional Neural Network for chest radiograph classification.

    Complies with Differential Privacy requirements by utilizing Group Normalization.
    """

    def __init__(
        self,
        in_channels: int = 1,
        num_classes: int = 14,
        num_groups: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.num_classes = num_classes

        # Feature extraction layers
        self.features = nn.Sequential(
            # Block 1: (B, 1, 224, 224) -> (B, 16, 112, 112)
            nn.Conv2d(in_channels, 16, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=num_groups, num_channels=16),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # Block 2: (B, 16, 112, 112) -> (B, 32, 56, 56)
            nn.Conv2d(16, 32, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=num_groups, num_channels=32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # Block 3: (B, 32, 56, 56) -> (B, 64, 28, 28)
            nn.Conv2d(32, 64, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=num_groups * 2, num_channels=64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # Block 4: (B, 64, 28, 28) -> (B, 64, 4, 4)
            nn.Conv2d(64, 64, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=num_groups * 2, num_channels=64),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((4, 4)),
        )

        # Classifier head
        flattened_dim = 64 * 4 * 4  # 1024
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(flattened_dim, 64),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(64, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        Args:
            x: Tensor of shape (batch_size, in_channels, height, width)

        Returns:
            Logits tensor of shape (batch_size, num_classes)
        """
        feats = self.features(x)
        logits = self.classifier(feats)
        return logits

