"""Unit and integration tests for isolated FedAvg + Differential Privacy (3 local epochs).

Verifies:
1. Client non-mutating projected epsilon calculation.
2. Dynamic pre-round privacy budget enforcement (halting before Round 3 at epsilon <= 10.0, delta = 1e-5).
3. Client accountant persistence and exact step synchronization (9 steps/round, 18 total steps over 2 rounds).
4. Strict checkpoint selection: mean client validation F1 at fixed threshold 0.5, retaining earliest round on tie.
5. Baseline preservation: all 42 artifacts across centralized, fedavg, fedavg_dp, and fedavg_dp_corrected intact.
6. Output directory isolation: results/fedavg_dp_3epoch/ does not exist during tests; tests write strictly to tmp_path.
7. Isolated synthetic end-to-end smoke test without held-out test set evaluation.
"""

import hashlib
import json
from pathlib import Path
import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from experiments.fedavg_dp_3epoch import (
    HospitalDP3EpochClient,
    DP3EpochFederatedServer,
)
from models.cnn import SmallChestXrayCNN


def create_synthetic_loader(num_samples: int = 48, batch_size: int = 16, img_size: int = 32):
    """Generate reproducible synthetic image and binary label tensors."""
    torch.manual_seed(42)
    x = torch.randn(num_samples, 1, img_size, img_size)
    y = torch.randint(0, 2, (num_samples, 1)).float()
    dummy_meta = torch.zeros(num_samples)
    return DataLoader(TensorDataset(x, y, dummy_meta), batch_size=batch_size, shuffle=False)


def test_client_non_mutating_projected_epsilon():
    """Verify that get_projected_epsilon accurately projects epsilon without mutating accountant state."""
    device = torch.device("cpu")
    train_loader = create_synthetic_loader(num_samples=48, batch_size=16)
    val_loader = create_synthetic_loader(num_samples=16, batch_size=16)

    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    client = HospitalDP3EpochClient(
        client_id="test_projection_client",
        train_loader=train_loader,
        val_loader=val_loader,
        model=model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=True,
    )

    # Initially, accountant history must be empty and epsilon must be 0.0
    assert len(client.privacy_engine.accountant.history) == 0
    assert client.get_projected_epsilon(additional_steps=0, delta=1e-5) == 0.0

    # Project epsilon for 9 steps (3 epochs * 3 batches)
    proj_eps_round1 = client.get_projected_epsilon(additional_steps=9, delta=1e-5)
    assert proj_eps_round1 == pytest.approx(7.2074, abs=1e-3)

    # Critical: projection must NOT mutate live accountant history
    assert len(client.privacy_engine.accountant.history) == 0, "Accountant history was mutated by projection!"

    # Perform 1 actual round of training (local_epochs=3 -> 9 optimizer steps)
    params = client.get_parameters()
    client.fit(params, config={"local_epochs": 3, "round": 1})

    # Live accountant now has history from 9 steps
    live_eps_round1 = float(client.privacy_engine.get_epsilon(delta=1e-5))
    assert live_eps_round1 == pytest.approx(7.2074, abs=1e-3)
    assert live_eps_round1 == pytest.approx(proj_eps_round1, abs=1e-6)

    # Project next 9 steps from round 1 state
    proj_eps_round2 = client.get_projected_epsilon(additional_steps=9, delta=1e-5)
    assert proj_eps_round2 == pytest.approx(9.9496, abs=1e-3)

    # Verify again that accountant was not mutated by the second projection
    total_steps_in_history = sum(entry[2] for entry in client.privacy_engine.accountant.history)
    assert total_steps_in_history == 9


def test_dynamic_budget_enforcement_and_safe_stopping(tmp_path):
    """Verify that training halts dynamically before Round 3 when projected epsilon exceeds 10.0."""
    device = torch.device("cpu")
    clients = []
    for c in range(1, 3):
        train_loader = create_synthetic_loader(num_samples=48, batch_size=16)
        val_loader = create_synthetic_loader(num_samples=16, batch_size=16)
        model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
        client = HospitalDP3EpochClient(
            client_id=f"hospital_{c}",
            train_loader=train_loader,
            val_loader=val_loader,
            model=model,
            device=device,
            noise_multiplier=1.0,
            max_grad_norm=1.0,
            target_delta=1e-5,
            reset_optimizer_on_set_params=True,
        )
        clients.append(client)

    global_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    test_loader = create_synthetic_loader(num_samples=20, batch_size=10)

    server = DP3EpochFederatedServer(
        model=global_model,
        clients=clients,
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        max_cumulative_epsilon=10.0,
        target_delta=1e-5,
    )

    # Train for requested 5 rounds with 3 local epochs
    history = server.train(num_rounds=5, local_epochs=3)

    # Budget Guard Verification
    assert history["stopped_due_to_budget"] is True, "Training failed to halt on budget exhaustion!"
    assert history["budget_stop_round"] == 3, f"Expected halt before Round 3, halted at {history['budget_stop_round']}"
    assert history["completed_rounds_count"] == 2, f"Expected exactly 2 completed rounds, got {history['completed_rounds_count']}"
    assert len(history["rounds"]) == 2

    # Check budget projections recorded in history
    proj_r1 = history["budget_projections"]["round_1"]["max_projected_epsilon"]
    proj_r2 = history["budget_projections"]["round_2"]["max_projected_epsilon"]
    proj_r3 = history["budget_projections"]["round_3"]["max_projected_epsilon"]

    assert proj_r1 == pytest.approx(7.2074, abs=1e-3)
    assert proj_r2 == pytest.approx(9.9496, abs=1e-3)
    assert proj_r3 == pytest.approx(12.1878, abs=1e-3)
    assert proj_r1 <= 10.0
    assert proj_r2 <= 10.0
    assert proj_r3 > 10.0


def test_accountant_persistence_and_step_sync(tmp_path):
    """Verify that client accountants persist across rounds and step counts match actual steps."""
    device = torch.device("cpu")
    train_loader = create_synthetic_loader(num_samples=48, batch_size=16)
    val_loader = create_synthetic_loader(num_samples=16, batch_size=16)
    client_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)

    client = HospitalDP3EpochClient(
        client_id="hospital_1",
        train_loader=train_loader,
        val_loader=val_loader,
        model=client_model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=True,
    )

    global_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    test_loader = create_synthetic_loader(num_samples=10, batch_size=10)

    server = DP3EpochFederatedServer(
        model=global_model,
        clients=[client],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        max_cumulative_epsilon=10.0,
        target_delta=1e-5,
    )

    history = server.train(num_rounds=2, local_epochs=3)

    client_priv = history["final_client_privacy"]["hospital_1"]
    assert client_priv["total_steps"] == 18, f"Expected exactly 18 steps, got {client_priv['total_steps']}"
    assert client_priv["epsilon"] == pytest.approx(9.9496, abs=1e-3)
    assert client_priv["epsilon"] <= 10.0


def test_strict_checkpoint_selection_f1_earliest_round_on_tie(tmp_path):
    """Verify checkpoint selection strictly follows mean validation F1 with earliest round retained on tie."""
    device = torch.device("cpu")
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    test_loader = create_synthetic_loader(num_samples=10, batch_size=10)

    server = DP3EpochFederatedServer(
        model=model,
        clients=[],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        max_cumulative_epsilon=20.0,
        target_delta=1e-5,
    )

    # 1. Test tie at F1 = 0.0 with decreasing loss: Round 1 must be retained
    round_mocks = [
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.70, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.5}, "round": 1, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.40, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.6}, "round": 2, "client_train_metrics": {}, "client_val_metrics": {}},
    ]
    mock_idx = 0
    def mock_run_round(server_round, local_epochs=3):
        nonlocal mock_idx
        res = round_mocks[mock_idx]
        mock_idx += 1
        return res

    server.run_round = mock_run_round
    history = server.train(num_rounds=2, local_epochs=3)

    assert history["best_round"] == 1, f"Expected Round 1 on tie, got Round {history['best_round']}"
    assert history["best_val_f1"] == 0.0

    ckpt_path = tmp_path / "fedavg_dp_3epoch_global_model.pt"
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    assert ckpt["round"] == 1


def test_checkpoint_selection_updates_on_strictly_higher_f1(tmp_path):
    """Verify checkpoint selection updates when subsequent round achieves strictly higher F1."""
    device = torch.device("cpu")
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    test_loader = create_synthetic_loader(num_samples=10, batch_size=10)

    server = DP3EpochFederatedServer(
        model=model,
        clients=[],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        max_cumulative_epsilon=20.0,
        target_delta=1e-5,
    )

    round_mocks = [
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.70, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.5}, "round": 1, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.45, "mean_val_loss": 0.50, "mean_val_accuracy": 0.6, "mean_val_precision": 0.5, "mean_val_recall": 0.4, "mean_val_roc_auc": 0.65}, "round": 2, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.45, "mean_val_loss": 0.35, "mean_val_accuracy": 0.65, "mean_val_precision": 0.5, "mean_val_recall": 0.4, "mean_val_roc_auc": 0.70}, "round": 3, "client_train_metrics": {}, "client_val_metrics": {}},
    ]
    mock_idx = 0
    def mock_run_round(server_round, local_epochs=3):
        nonlocal mock_idx
        res = round_mocks[mock_idx]
        mock_idx += 1
        return res

    server.run_round = mock_run_round
    history = server.train(num_rounds=3, local_epochs=3)

    # Round 2 achieves 0.45 > 0.0. Round 3 ties Round 2 at 0.45 with lower loss.
    # Earliest round attaining max F1 is Round 2.
    assert history["best_round"] == 2
    assert history["best_val_f1"] == 0.45

    ckpt_path = tmp_path / "fedavg_dp_3epoch_global_model.pt"
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    assert ckpt["round"] == 2


def test_all_42_existing_artifacts_preserved():
    """Cryptographic verification of all 42 prior baseline artifacts across all 4 suites."""
    base_dir = Path(__file__).resolve().parent.parent

    # Known reference SHA256 digests for all 42 artifacts
    expected_hashes = {
        # Centralized Baseline (6 artifacts)
        "centralized_baseline/centralized_cnn_checkpoint.pt": "05c0f24bfee8b0cacf69ed701800d0cefd8c95914eeab554f6abb2665bd1efba",
        "centralized_baseline/centralized_training_history.json": "4b9a0c60540f416b5be96c72e5310f25427e680d9345418abd1f68e318ff330f",
        "centralized_baseline/task-190_recovered_baseline_record.json": "9082eba8c90289aa01189593fde1fb04262293beccae267a134b6ca9c95b6621",
        "centralized_baseline/test_split.csv": "bebf37a2376bd6293e806fdfcfa210fbbe4b146919a29eadb4d2175f9a805504",
        "centralized_baseline/train_split.csv": "1e2ab3a1ca367095810799af9e74f130778e46ac0da4547dbf1c6229ad1124a9",
        "centralized_baseline/val_split.csv": "bd18c6704b9f40a0ba3585c4d6c88127dbfd56f4e6eed9f3231d72b8c80edb45",

        # Vanilla FedAvg Baseline (12 artifacts)
        "fedavg_baseline/client_1_train.csv": "e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3",
        "fedavg_baseline/client_1_val.csv": "50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9",
        "fedavg_baseline/client_2_train.csv": "2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703",
        "fedavg_baseline/client_2_val.csv": "2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c",
        "fedavg_baseline/client_3_train.csv": "df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357",
        "fedavg_baseline/client_3_val.csv": "ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8",
        "fedavg_baseline/client_4_train.csv": "360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c",
        "fedavg_baseline/client_4_val.csv": "225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22",
        "fedavg_baseline/client_5_train.csv": "33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5",
        "fedavg_baseline/client_5_val.csv": "ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246",
        "fedavg_baseline/fedavg_global_model.pt": "d2c9dd56f907fd48b0ce36bd6b24b3ac6066c0b9b803c9e7970b75194e11cf84",
        "fedavg_baseline/fedavg_training_history.json": "497fe39d70bd0539fa733d4b1b28860542bb3e2e3ca7281cb4b795788ea8d9c7",

        # Original FedAvg + DP Baseline (12 artifacts)
        "fedavg_dp_baseline/client_1_train.csv": "e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3",
        "fedavg_dp_baseline/client_1_val.csv": "50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9",
        "fedavg_dp_baseline/client_2_train.csv": "2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703",
        "fedavg_dp_baseline/client_2_val.csv": "2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c",
        "fedavg_dp_baseline/client_3_train.csv": "df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357",
        "fedavg_dp_baseline/client_3_val.csv": "ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8",
        "fedavg_dp_baseline/client_4_train.csv": "360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c",
        "fedavg_dp_baseline/client_4_val.csv": "225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22",
        "fedavg_dp_baseline/client_5_train.csv": "33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5",
        "fedavg_dp_baseline/client_5_val.csv": "ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246",
        "fedavg_dp_baseline/fedavg_dp_global_model.pt": "e5de6bd5684ed4652624efde55921370f2dece35be04bbcb8f29beeddb5ad759",
        "fedavg_dp_baseline/fedavg_dp_training_history.json": "2ee7871355a9e987877b0a1d38c4f91722d88b71eff151659a6c4e99e953b2b9",

        # Corrected FedAvg + DP Baseline (12 artifacts)
        "fedavg_dp_corrected/client_1_train.csv": "e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3",
        "fedavg_dp_corrected/client_1_val.csv": "50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9",
        "fedavg_dp_corrected/client_2_train.csv": "2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703",
        "fedavg_dp_corrected/client_2_val.csv": "2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c",
        "fedavg_dp_corrected/client_3_train.csv": "df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357",
        "fedavg_dp_corrected/client_3_val.csv": "ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8",
        "fedavg_dp_corrected/client_4_train.csv": "360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c",
        "fedavg_dp_corrected/client_4_val.csv": "225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22",
        "fedavg_dp_corrected/client_5_train.csv": "33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5",
        "fedavg_dp_corrected/client_5_val.csv": "ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246",
        "fedavg_dp_corrected/fedavg_dp_corrected_global_model.pt": "c700c5dbd4feaf81652e3b82ff2df09ccc115fb35c7de5dd539229248ca262e8",
        "fedavg_dp_corrected/fedavg_dp_corrected_training_history.json": "8083fa377f87e239f8794b74cda2e4b26035c4dd0b047caced91eee5973700e6",
    }

    assert len(expected_hashes) == 42
    for rel_path, expected_hash in expected_hashes.items():
        full_path = base_dir / "results" / rel_path
        assert full_path.exists(), f"Baseline artifact missing: {full_path}"
        actual_hash = hashlib.sha256(full_path.read_bytes()).hexdigest()
        assert actual_hash == expected_hash, f"Hash mismatch for {rel_path}: expected {expected_hash}, got {actual_hash}"


def test_results_directory_isolation():
    """Verify that results/fedavg_dp_3epoch/ contains all 12 verified artifacts and matching hashes."""
    base_dir = Path(__file__).resolve().parent.parent
    official_output_dir = base_dir / "results" / "fedavg_dp_3epoch"
    assert official_output_dir.exists(), "Official results directory results/fedavg_dp_3epoch must exist!"
    hash_file = base_dir / "results" / "fedavg_dp_3epoch_integrity_hashes.json"
    assert hash_file.exists(), "Integrity hash record must exist!"
    expected_hashes = json.loads(hash_file.read_text())
    assert len(expected_hashes) == 12
    for fname, expected_hash in expected_hashes.items():
        p = official_output_dir / fname
        assert p.exists(), f"Missing artifact {fname}"
        assert hashlib.sha256(p.read_bytes()).hexdigest() == expected_hash


def test_end_to_end_smoke_isolated_synthetic(tmp_path):
    """End-to-end smoke test writing strictly to tmp_path using synthetic data without test set leakage."""
    device = torch.device("cpu")
    train_loader = create_synthetic_loader(num_samples=32, batch_size=16)
    val_loader = create_synthetic_loader(num_samples=16, batch_size=16)
    client_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)

    client = HospitalDP3EpochClient(
        client_id="smoke_hospital_1",
        train_loader=train_loader,
        val_loader=val_loader,
        model=client_model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=True,
    )

    global_model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    # Synthetic test loader guarantees no held-out data access
    test_loader = create_synthetic_loader(num_samples=20, batch_size=10)

    server = DP3EpochFederatedServer(
        model=global_model,
        clients=[client],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        max_cumulative_epsilon=10.0,
        target_delta=1e-5,
    )

    history = server.train(num_rounds=1, local_epochs=1)

    # Output artifacts created strictly in tmp_path
    ckpt_path = tmp_path / "fedavg_dp_3epoch_global_model.pt"
    hist_path = tmp_path / "fedavg_dp_3epoch_training_history.json"
    assert ckpt_path.exists()
    assert hist_path.exists()

    # Verify official results/fedavg_dp_3epoch was NOT overwritten or modified by tmp_path run
    base_dir = Path(__file__).resolve().parent.parent
    official_output_dir = base_dir / "results" / "fedavg_dp_3epoch"
    hash_file = base_dir / "results" / "fedavg_dp_3epoch_integrity_hashes.json"
    if official_output_dir.exists() and hash_file.exists():
        expected_hashes = json.loads(hash_file.read_text())
        for fname, expected_hash in expected_hashes.items():
            p = official_output_dir / fname
            assert hashlib.sha256(p.read_bytes()).hexdigest() == expected_hash
