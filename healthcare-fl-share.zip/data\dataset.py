"""PyTorch Dataset module for NIH ChestX-ray14 hospital client partitions.

Loads images on-demand from disk without loading the entire dataset into RAM:
- Reads manifest CSVs generated during patient-wise partitioning.
- Resolves image paths across images_001 through images_012.
- Converts images to single-channel grayscale ('L') via PIL.
- Resizes to configurable dimensions (default: 224x224).
- Normalizes pixel values to [0.0, 1.0] float32 tensors.
- Parses and multi-hot encodes the 14 official NIH ChestX-ray14 pathologies.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import os
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch.utils.data import Dataset

# Official 14 clinical pathologies documented in NIH ChestX-ray14
NIH_PATHOLOGIES: List[str] = [
    "Atelectasis",
    "Cardiomegaly",
    "Consolidation",
    "Edema",
    "Effusion",
    "Emphysema",
    "Fibrosis",
    "Hernia",
    "Infiltration",
    "Mass",
    "Nodule",
    "Pleural_Thickening",
    "Pneumonia",
    "Pneumothorax",
]

PATHOLOGY_TO_IDX: Dict[str, int] = {name: idx for idx, name in enumerate(NIH_PATHOLOGIES)}


def encode_nih_labels(finding_labels_str: str) -> np.ndarray:
    """Encode pipe-separated finding label strings from Data_Entry_2017.csv

    into a multi-hot binary indicator array of shape (14,).

    If 'No Finding', all 14 indicators remain 0.0.
    """
    label_vec = np.zeros(len(NIH_PATHOLOGIES), dtype=np.float32)
    if pd.isna(finding_labels_str) or not str(finding_labels_str).strip():
        return label_vec

    findings = [f.strip() for f in str(finding_labels_str).split("|") if f.strip()]
    for finding in findings:
        if finding in PATHOLOGY_TO_IDX:
            label_vec[PATHOLOGY_TO_IDX[finding]] = 1.0

    return label_vec


def resolve_image_path(raw_dir: Path, image_name: str, relative_path: Optional[str] = None) -> Path:
    """Resolve the absolute on-disk path for an image file across images_001 through images_012."""
    # 1. Fast path: check relative_path from manifest if provided
    if relative_path and isinstance(relative_path, str):
        candidate = raw_dir / relative_path
        if candidate.is_file():
            return candidate

    # 2. Search across image archives images_001 to images_012
    for i in range(1, 13):
        folder_name = f"images_{i:03d}"
        # Check nested images/ directory first, then root folder
        nested = raw_dir / folder_name / "images" / image_name
        if nested.is_file():
            return nested
        direct = raw_dir / folder_name / image_name
        if direct.is_file():
            return direct

    raise FileNotFoundError(f"Image '{image_name}' could not be located in any archive in '{raw_dir}'")


class NIHChestXrayClientDataset(Dataset):
    """PyTorch Dataset representing a single simulated hospital client's data.

    Supports lazy on-demand loading of individual images and configurable subset limits
    for lightweight smoke testing.
    """

    def __init__(
        self,
        manifest_path: Path,
        raw_dir: Path,
        image_size: Tuple[int, int] = (224, 224),
        max_samples: Optional[int] = None,
    ):
        """Initialize the client dataset.

        Args:
            manifest_path: Path to client manifest CSV (e.g., hospital_client_1_manifest.csv)
            raw_dir: Path to raw NIH ChestX-ray14 root on external drive
            image_size: Tuple of (height, width) for resizing
            max_samples: If set, limits dataset to first N samples (e.g. 8 or 16 for smoke testing)
        """
        self.manifest_path = Path(manifest_path)
        self.raw_dir = Path(raw_dir)
        self.image_size = image_size

        if not self.manifest_path.is_file():
            raise FileNotFoundError(f"Client manifest not found: {self.manifest_path}")

        # Read manifest CSV
        df = pd.read_csv(self.manifest_path)
        if max_samples is not None and max_samples > 0:
            df = df.head(max_samples).copy()

        self.df = df.reset_index(drop=True)

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        row = self.df.iloc[idx]
        image_name = row["Image Index"]
        rel_path = row.get("relative_path", None)

        # 1. Resolve disk path
        file_path = resolve_image_path(self.raw_dir, image_name, rel_path)

        # 2. Read with PIL and convert to grayscale
        with Image.open(file_path) as img:
            gray_img = img.convert("L")
            resized_img = gray_img.resize(self.image_size, resample=Image.Resampling.BILINEAR)

            # Convert to numpy array [0.0, 1.0]
            img_arr = np.array(resized_img, dtype=np.float32) / 255.0

        # Convert to PyTorch tensor of shape (1, H, W)
        image_tensor = torch.from_numpy(img_arr).unsqueeze(0)

        # 3. Parse labels
        finding_labels = row.get("Finding Labels", "No Finding")
        label_vec = encode_nih_labels(finding_labels)
        label_tensor = torch.from_numpy(label_vec)

        metadata = {
            "image_index": image_name,
            "patient_id": int(row["Patient ID"]),
            "finding_labels": str(finding_labels),
            "file_path": str(file_path),
        }

        return image_tensor, label_tensor, metadata

