# Technical Implementation Guide: Privacy-Preserving Federated Learning

## 1. Architectural Overview

The `healthcare-fl` platform implements an empirical research framework for federated learning across simulated clinical nodes. The system models a federation of 5 simulated hospital clients collaborating to train a shared diagnostic neural network on radiographs from the public NIH ChestX-ray14 dataset without centralizing patient records.

```
                    ┌────────────────────────────────────────────────────────┐
                    │               DP3EpochFederatedServer                  │
                    │  - Global Model (SmallChestXrayCNN)                    │
                    │  - Dynamic Privacy Budget Guard (ε ≤ 10.0, δ = 1e-5)   │
                    │  - FedAvg Weighted Parameter Aggregation               │
                    │  - Validation-Based F1 Checkpoint Selection            │
                    └───────────────▲────────────────────────▲───────────────┘
                                    │ Broadcast / Aggregate  │
            ┌───────────────────────┴──────────┐   ┌─────────┴──────────────────────┐
            │                                  │   │                                │
┌───────────┴───────────────────────┐          │   │          ┌─────────────────────┴─────────────┐
│      HospitalDP3EpochClient 1     │        ..... │          │      HospitalDP3EpochClient 5     │
│ - Local Cohort: 48 Train / 12 Val │              │          │ - Local Cohort: 48 Train / 12 Val │
│ - Opacus DP-SGD (C=1.0, σ=1.0)    │                         │ - Opacus DP-SGD (C=1.0, σ=1.0)    │
│ - Poisson Sampler (q = 16/48)     │                         │ - Poisson Sampler (q = 16/48)     │
│ - Persistent PRVAccountant        │                         │ - Persistent PRVAccountant        │
│ - Adam Momentum Reset on Sync     │                         │ - Adam Momentum Reset on Sync     │
└───────────────────────────────────┘                         └───────────────────────────────────┘
```

> [!NOTE]
> The five clients are synthetic, patient-isolated partitions created from the single public NIH ChestX-ray14 dataset to simulate multi-institutional data isolation; they do not represent distinct physical hospital networks.

---

## 2. Dataset Pipeline & Patient-Level Cohort Construction

### A. Clinical Classification Task
- **Target Pathology:** Detection of Pneumonia from frontal chest radiographs.
- **Binary Cohort Formulation:**
  - **Positive ($y = 1.0$):** Scans labeled with "Pneumonia" in official NIH metadata. Exactly 1 scan is sampled per unique patient ID.
  - **Clean Controls ($y = 0.0$):** Scans labeled "No Finding" from patients who **never** had a pneumonia diagnosis in any scan across the entire NIH ChestX-ray14 dataset.

### B. Patient Disjointness Guarantees
Cohort creation in [`experiments/fedavg_baseline.py`](file:///c:/Users/Vaishnavi%20Sinha/OneDrive/Desktop/SRM/Project/healthcare-fl/experiments/fedavg_baseline.py) (`build_client_cohorts`) enforces strict topological isolation:
1. $\text{Patients}(\text{Client}_i) \cap \text{Patients}(\text{Client}_j) = \emptyset \quad \forall i \neq j$ (Zero inter-client patient overlap).
2. $\text{Patients}(\text{Client}_i\text{-Train}) \cap \text{Patients}(\text{Client}_i\text{-Val}) = \emptyset \quad \forall i$ (Zero intra-client train/validation overlap).
3. $\text{Patients}(\text{Client}_i) \cap \text{Patients}(\text{Central-Test}) = \emptyset \quad \forall i$ (Zero client/held-out test overlap).
4. Each simulated client receives 60 total scans stratified 50/50: 48 training scans (24 pneumonia, 24 control) and 12 validation scans (6 pneumonia, 6 control).
5. The centralized held-out test split contains 30 scans (15 pneumonia, 15 control) from completely distinct patients subsampled from the NIH metadata.

---

## 3. Diagnostic Model Architecture & Normalization Choice

The diagnostic network is implemented as [`SmallChestXrayCNN`](file:///c:/Users/Vaishnavi%20Sinha/OneDrive/Desktop/SRM/Project/healthcare-fl/models/cnn.py):
- **Input:** Single-channel grayscale radiographs $(1 \times 224 \times 224)$ normalized to $[0, 1]$.
- **Normalization Selection (GroupNorm vs. BatchNorm):**
  - Standard Batch Normalization calculates mean and variance across all samples in a mini-batch, which couples activations across individual samples. In standard DP-SGD implementations (such as Opacus), computing true per-sample gradients requires independent forward/backward pathways per sample.
  - While specialized per-sample batch normalization adaptations exist in research literature, standard practice in DP-SGD frameworks is to employ sample-independent normalization layers.
  - We use **Group Normalization** (`GroupNorm`, `num_groups=4`), which normalizes features within channel groups for each sample independently, guaranteeing zero inter-sample gradient coupling.
- **Feature Extractor:** 4 sequential convolutional blocks:
  - Block 1: Conv2d(1 $\to$ 16, k=3, p=1) $\to$ GroupNorm(4, 16) $\to$ ReLU $\to$ MaxPool2d(2)
  - Block 2: Conv2d(16 $\to$ 32, k=3, p=1) $\to$ GroupNorm(4, 32) $\to$ ReLU $\to$ MaxPool2d(2)
  - Block 3: Conv2d(32 $\to$ 64, k=3, p=1) $\to$ GroupNorm(8, 64) $\to$ ReLU $\to$ MaxPool2d(2)
  - Block 4: Conv2d(64 $\to$ 64, k=3, p=1) $\to$ GroupNorm(8, 64) $\to$ ReLU $\to$ AdaptiveAvgPool2d((4, 4))
- **Classifier Head:** Flatten $\to$ Linear(1024 $\to$ 64) $\to$ ReLU $\to$ Dropout(0.1) $\to$ Linear(64 $\to$ 1). Outputs a single raw logit $z \in \mathbb{R}$.

---

## 4. Differential Privacy Mechanics & Mathematical Guarantees

### A. Formal Differential Privacy Guarantee
A randomized algorithm $\mathcal{M}$ satisfies $(\epsilon, \delta)$-differential privacy if for all adjacent datasets $D, D'$ differing by at most one patient record, and all measurable subsets of outputs $S \subseteq \text{Range}(\mathcal{M})$:
$$\mathbb{P}[\mathcal{M}(D) \in S] \le e^\epsilon \, \mathbb{P}[\mathcal{M}(D') \in S] + \delta$$
- This guarantee bounds the privacy loss random variable, limiting an adversary's ability to infer whether an individual patient was included in the training cohort.
- It does **not** provide absolute immunity against all possible empirical attacks regardless of budget; rather, the strength of the privacy bound is strictly parameterized by $(\epsilon, \delta)$.

### B. DP-SGD Implementation Details
Each client wraps its model and optimizer with Opacus `PrivacyEngine` (`make_private`):
1. **Poisson Subsampling:** Training batches are formed by including each sample independently with probability $q = \frac{B}{N} = \frac{16}{48} = \frac{1}{3}$.
2. **Per-Sample Gradient Clipping:** For each sample $i$ in batch $B$, the individual gradient $g_i$ is clipped to maximum $L_2$ norm $C = 1.0$:
   $$\bar{g}_i = g_i \cdot \min\left(1, \frac{C}{\|g_i\|_2}\right)$$
3. **Calibrated Gaussian Noise:** Independent Gaussian noise is added to the clipped sum with noise multiplier $\sigma = 1.0$:
   $$\tilde{g} = \sum_{i \in B} \bar{g}_i + \mathcal{N}\left(0, \sigma^2 C^2 \mathbf{I}\right)$$
4. **Gradient Normalization:** The noisy sum is divided by the nominal batch size $B = 16$:
   $$g_{\text{step}} = \frac{1}{B} \tilde{g}$$
5. **Loss Reduction Compatibility:** In Opacus 1.4.1, `GradSampleModule` automatically scales backpropagated loss by $|B|$ when `criterion = nn.BCEWithLogitsLoss(reduction="mean")`, recovering true unscaled per-sample gradients $g_i$ prior to clipping.

### C. Persistent Accounting & Optimizer State Reset
- **Accountant Persistence:** Each client maintains an Opacus `PRVAccountant` (Privacy Random Variable Accountant) across rounds. The accountant accumulates the history of tuples $(q, \sigma, \text{steps})$ across all communication rounds without resetting.
- **Adam State Reset:** In [`HospitalDPClient`](file:///c:/Users/Vaishnavi%20Sinha/OneDrive/Desktop/SRM/Project/healthcare-fl/clients/hospital_dp_client.py#L68-L88), setting `reset_optimizer_on_set_params=True` executes `self.dp_optimizer.state.clear()` whenever new global parameters are loaded from the server. This wipes Adam's first-moment ($m_t$) and second-moment ($v_t$) buffers from previous rounds, preventing momentum carryover from interfering with newly aggregated global weights, while preserving the client's `PrivacyEngine` and accountant state intact.

---

## 5. Dynamic Privacy Budget Enforcement

In [`experiments/fedavg_dp_3epoch.py`](file:///c:/Users/Vaishnavi%20Sinha/OneDrive/Desktop/SRM/Project/healthcare-fl/experiments/fedavg_dp_3epoch.py), `DP3EpochFederatedServer.train` implements dynamic pre-round privacy budget gating:
1. **Non-Mutating Projection:** Before starting communication round $r$, the server queries each client:
   ```python
   proj_eps = client.get_projected_epsilon(additional_steps=expected_round_steps, delta=self.target_delta)
   ```
   `get_projected_epsilon` creates an ephemeral clone of `accountant.history`, appends the proposed round steps $(q, \sigma, \text{additional\_steps})$, and computes projected cumulative $\epsilon$ at $\delta = 10^{-5}$ without modifying the client's active accountant.
2. **Pre-Round Stopping Guard:** If any client's projected $\epsilon > \epsilon_{\text{budget}} = 10.0$, the server terminates training immediately:
   - No parameters are broadcast for round $r$.
   - No client executes `fit()`.
   - Zero optimizer steps are taken.
   - The server proceeds directly to checkpoint selection and held-out test evaluation.

---

## 6. Model Selection & Test Protocol

1. **Validation Checkpoint Selection:**
   - Evaluated on local client validation sets ($N=12$ per client, 60 total).
   - Selection metric: Mean client validation F1 score at decision threshold $0.50$.
   - **Tie-Breaking Rule:** Earliest round is retained on ties (`cur_f1 > best_val_f1`). Secondary metrics (loss or ROC-AUC) are explicitly prohibited from breaking ties.
2. **One-Time Test Set Evaluation:**
   - Evaluated strictly once after federated training terminates.
   - The selected checkpoint is loaded into the global model and evaluated on `results/centralized_baseline/test_split.csv` ($N=30$).
   - Metrics computed: Accuracy, Precision, Recall, Macro F1, ROC-AUC, BCE Loss, and Confusion Matrix.
   - The test set is never accessed during training, validation, or hyperparameter selection.
