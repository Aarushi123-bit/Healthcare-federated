"""Isolated FedAvg + Differential Privacy experiment with 3 local epochs and budget enforcement.

Experimental Design:
1. Local Epochs: local_epochs = 3 per communication round.
2. Privacy Budget Enforcement: Enforces max_cumulative_epsilon <= 10.0 at delta = 1e-5.
   Before each round, non-mutating projections of each client's live PRVAccountant calculate
   projected cumulative epsilon if the round's steps were taken. If projected epsilon > 10.0,
   training terminates prior to executing that round.
3. Persistent Accounting: Client PRV accountants persist across rounds, accumulating actual steps.
4. Adam Optimizer State Reset: Local Adam momentum/variance buffers are reset on weight sync.
5. Strict Checkpoint Selection: Mean client validation F1 at fixed threshold 0.5; earliest round on tie.
6. Isolated Outputs: All artifacts written exclusively to results/fedavg_dp_3epoch/.
7. Baseline Preservation: All 42 prior baseline artifacts remain untouched.
"""

from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Optional, Tuple
import json
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from opacus.accountants import PRVAccountant

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from clients.hospital_dp_client import HospitalDPClient
from data.partitioning import build_image_index
from experiments.centralized_baseline import (
    BinaryChestXrayDataset,
    evaluate_model,
    load_config,
)
from experiments.fedavg_baseline import build_client_cohorts
from models.cnn import SmallChestXrayCNN
from server.federated_server import FederatedServer


class HospitalDP3EpochClient(HospitalDPClient):
    """Hospital client extending HospitalDPClient with non-mutating privacy projection."""

    def get_projected_epsilon(self, additional_steps: int = 0, delta: float = 1e-5) -> float:
        """Compute projected cumulative epsilon if additional_steps were executed.

        Uses a non-mutating clone of the live PRVAccountant history without altering
        the client's actual accountant state.
        """
        temp_acc = PRVAccountant()
        temp_acc.history = list(self.privacy_engine.accountant.history)
        if additional_steps > 0:
            temp_acc.history.append(
                (self.noise_multiplier, self.sample_rate, additional_steps)
            )
        if not temp_acc.history:
            return 0.0
        return float(temp_acc.get_epsilon(delta=delta))


class DP3EpochFederatedServer(FederatedServer):
    """Federated server with dynamic privacy budget guard and strict F1 checkpoint selection."""

    def __init__(
        self,
        model: torch.nn.Module,
        clients: List[HospitalDP3EpochClient],
        test_loader: DataLoader,
        device: torch.device,
        output_dir: Path,
        max_cumulative_epsilon: float = 10.0,
        target_delta: float = 1e-5,
    ):
        super().__init__(
            model=model,
            clients=clients,
            test_loader=test_loader,
            device=device,
            output_dir=output_dir,
        )
        self.max_cumulative_epsilon = max_cumulative_epsilon
        self.target_delta = target_delta

    def train(
        self,
        num_rounds: int = 5,
        local_epochs: int = 3,
    ) -> Dict[str, Any]:
        """Execute federated training with pre-round dynamic privacy budget enforcement."""
        checkpoint_path = self.output_dir / "fedavg_dp_3epoch_global_model.pt"
        history_path = self.output_dir / "fedavg_dp_3epoch_training_history.json"

        round_history = []
        best_round = -1
        best_val_f1 = -1.0
        best_val_loss = float("inf")
        stopped_due_to_budget = False
        budget_stop_round = -1
        budget_projections = {}

        start_time = time.time()

        for r in range(1, num_rounds + 1):
            # 1. Dynamic Pre-Round Privacy Budget Verification across all clients
            client_projections = {}
            budget_exceeded = False
            max_proj_eps = 0.0

            for client in self.clients:
                # Number of batches per epoch under Poisson sampling
                steps_per_epoch = len(client.raw_train_loader)
                expected_round_steps = steps_per_epoch * local_epochs
                proj_eps = client.get_projected_epsilon(
                    additional_steps=expected_round_steps,
                    delta=self.target_delta,
                )
                client_projections[client.client_id] = {
                    "projected_round_steps": expected_round_steps,
                    "sample_rate": client.sample_rate,
                    "projected_epsilon": round(proj_eps, 6),
                }
                max_proj_eps = max(max_proj_eps, proj_eps)
                if proj_eps > self.max_cumulative_epsilon:
                    budget_exceeded = True

            budget_projections[f"round_{r}"] = {
                "max_projected_epsilon": round(max_proj_eps, 6),
                "budget_limit": self.max_cumulative_epsilon,
                "clients": client_projections,
            }

            if budget_exceeded:
                stopped_due_to_budget = True
                budget_stop_round = r
                print(
                    f"[Privacy Guard] Halting before Round {r}: "
                    f"projected epsilon ({max_proj_eps:.4f}) exceeds budget ({self.max_cumulative_epsilon:.4f})."
                )
                break

            # 2. Execute Round
            round_summary = self.run_round(
                server_round=r,
                local_epochs=local_epochs,
            )
            round_history.append(round_summary)

            cur_f1 = round_summary["mean_val_metrics"]["mean_val_f1"]
            cur_loss = round_summary["mean_val_metrics"]["mean_val_loss"]

            # Strict Model Selection Rule:
            # Mean client validation F1 at fixed threshold 0.5.
            # Earliest round on tie; do NOT use loss or ROC-AUC as tie-breaker.
            is_better = cur_f1 > best_val_f1
            if is_better:
                best_val_f1 = cur_f1
                best_val_loss = cur_loss
                best_round = r
                torch.save(
                    {
                        "round": r,
                        "model_state_dict": self.model.state_dict(),
                        "mean_val_f1": best_val_f1,
                        "mean_val_loss": best_val_loss,
                    },
                    checkpoint_path,
                )

        total_duration = time.time() - start_time

        # 3. Held-out test set evaluation (strictly once on selected best model)
        if checkpoint_path.exists():
            best_checkpoint = torch.load(
                checkpoint_path, map_location=self.device, weights_only=False
            )
            self.model.load_state_dict(best_checkpoint["model_state_dict"])
            test_metrics = evaluate_model(
                model=self.model,
                loader=self.test_loader,
                criterion=self.criterion,
                device=self.device,
            )
            test_metrics["sample_count"] = len(self.test_loader.dataset)
        else:
            test_metrics = {
                "accuracy": 0.0,
                "precision": 0.0,
                "recall": 0.0,
                "f1_score": 0.0,
                "roc_auc": 0.5,
                "loss": 0.0,
                "sample_count": 0,
            }

        # Extract final privacy accounting details from clients
        final_client_privacy = {}
        for client in self.clients:
            eps = float(client.privacy_engine.get_epsilon(delta=self.target_delta))
            final_client_privacy[client.client_id] = {
                "epsilon": eps,
                "delta": self.target_delta,
                "sample_rate": client.sample_rate,
                "total_steps": sum(entry[2] for entry in client.privacy_engine.accountant.history) if client.privacy_engine.accountant.history else 0,
            }

        history = {
            "experiment": "fedavg_dp_3epoch",
            "privacy_mechanism": "opacus_dp_sgd",
            "privacy_unit": "patient_level_within_client",
            "accountant_type": "PRVAccountant",
            "poisson_sampling": True,
            "local_epochs": local_epochs,
            "max_cumulative_epsilon": self.max_cumulative_epsilon,
            "target_delta": self.target_delta,
            "stopped_due_to_budget": stopped_due_to_budget,
            "budget_stop_round": budget_stop_round,
            "completed_rounds_count": len(round_history),
            "best_round": best_round,
            "best_val_f1": best_val_f1,
            "best_val_loss": best_val_loss,
            "training_duration_seconds": round(total_duration, 2),
            "budget_projections": budget_projections,
            "final_client_privacy": final_client_privacy,
            "rounds": round_history,
            "held_out_test_metrics": test_metrics,
            "checkpoint_path": str(checkpoint_path.resolve()),
        }

        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)

        return history


def run_fedavg_dp_3epoch_experiment(
    num_rounds: int = 5,
    local_epochs: int = 3,
    samples_per_client: int = 60,
    batch_size: int = 16,
    noise_multiplier: float = 1.0,
    max_grad_norm: float = 1.0,
    learning_rate: float = 1e-3,
    target_delta: float = 1e-5,
    max_cumulative_epsilon: float = 10.0,
    image_size: Tuple[int, int] = (224, 224),
    seed: int = 42,
    config_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
    test_loader: Optional[DataLoader] = None,
) -> Dict[str, Any]:
    """Execute end-to-end 3-epoch FedAvg + DP experiment across 5 hospital clients."""
    # 1. Deterministic seeding
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 2. Paths and configuration
    cfg = load_config(config_path)
    raw_dir = Path(cfg["dataset"]["raw_dir"])
    proc_dir = BASE_DIR / cfg["dataset"]["processed_dir"]

    if output_dir is None:
        output_dir = BASE_DIR / "results" / "fedavg_dp_3epoch"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 3. Test Loader resolution (held-out test set isolation)
    if test_loader is None:
        central_test_path = BASE_DIR / "results" / "centralized_baseline" / "test_split.csv"
        if not central_test_path.exists():
            raise FileNotFoundError(f"Centralized test split not found at: {central_test_path}")
        test_df = pd.read_csv(central_test_path)
        test_ds = BinaryChestXrayDataset(test_df, raw_dir, image_size=image_size)
        test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)
        test_patient_ids = set(test_df["Patient ID"])
    else:
        test_patient_ids = set()

    # 4. Build image index for fast lookup
    image_index = build_image_index(raw_dir)

    # 5. Build patient-isolated client cohorts
    client_cohorts = build_client_cohorts(
        manifests_dir=proc_dir,
        image_index=image_index,
        test_patient_ids=test_patient_ids,
        output_dir=output_dir,
        samples_per_client=samples_per_client,
        val_ratio=0.2,
        seed=seed,
    )

    # 6. Initialize HospitalDP3EpochClient instances
    clients: List[HospitalDP3EpochClient] = []
    for c in range(1, 6):
        client_id = f"hospital_{c}"
        train_df = client_cohorts[client_id]["train"]
        val_df = client_cohorts[client_id]["val"]

        train_ds = BinaryChestXrayDataset(train_df, raw_dir, image_size=image_size)
        val_ds = BinaryChestXrayDataset(val_df, raw_dir, image_size=image_size)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

        client_model = SmallChestXrayCNN(
            in_channels=1,
            num_classes=1,
            num_groups=4,
            dropout=0.1,
        ).to(device)

        client = HospitalDP3EpochClient(
            client_id=client_id,
            train_loader=train_loader,
            val_loader=val_loader,
            model=client_model,
            device=device,
            noise_multiplier=noise_multiplier,
            max_grad_norm=max_grad_norm,
            learning_rate=learning_rate,
            target_delta=target_delta,
            reset_optimizer_on_set_params=True,
        )
        clients.append(client)

    # 7. Initialize Global Server Model and Orchestrator
    global_model = SmallChestXrayCNN(
        in_channels=1,
        num_classes=1,
        num_groups=4,
        dropout=0.1,
    ).to(device)

    server = DP3EpochFederatedServer(
        model=global_model,
        clients=clients,
        test_loader=test_loader,
        device=device,
        output_dir=output_dir,
        max_cumulative_epsilon=max_cumulative_epsilon,
        target_delta=target_delta,
    )

    # 8. Run Federated Training with Budget Guard
    history = server.train(
        num_rounds=num_rounds,
        local_epochs=local_epochs,
    )

    return history


if __name__ == "__main__":
    run_fedavg_dp_3epoch_experiment()
