"""Unit and integration tests for FedAvg with Differential Privacy (Opacus DP-SGD).

Verifies:
1. Native Opacus compatibility of SmallChestXrayCNN.
2. Poisson sampling and empty-batch gradient safety (no NaN).
3. Monotonic privacy accounting across multi-round global parameter reloads.
4. Immutability and SHA256 integrity of centralized and FedAvg baselines.
5. End-to-end 1-round smoke test writing strictly to tmp_path.
"""

from collections import OrderedDict
import hashlib
import json
from pathlib import Path
import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from opacus import PrivacyEngine
from opacus.validators import ModuleValidator

from clients.hospital_dp_client import HospitalDPClient
from experiments.fedavg_dp_baseline import run_fedavg_dp_experiment
from models.cnn import SmallChestXrayCNN


def test_opacus_cnn_native_compatibility():
    """Verify that SmallChestXrayCNN is natively compatible with Opacus without changes."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    errors = ModuleValidator.validate(model, strict=False)
    assert errors == [], f"Opacus validation errors found: {errors}"
    assert ModuleValidator.is_valid(model) is True


def test_poisson_sampling_and_empty_batch_handling():
    """Verify that Poisson sampling empty batches (|B|=0) are handled safely without NaN."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    x = torch.randn(12, 1, 224, 224)
    y = torch.randint(0, 2, (12, 1)).float()
    ds = TensorDataset(x, y)
    loader = DataLoader(ds, batch_size=4)

    pe = PrivacyEngine()
    dp_model, dp_opt, _ = pe.make_private(
        module=model,
        optimizer=opt,
        data_loader=loader,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        poisson_sampling=True,
    )

    empty_x = torch.empty(0, 1, 224, 224)
    dp_opt.zero_grad()
    out = dp_model(empty_x)
    dummy_loss = out.sum()  # 0.0, no NaN
    assert not torch.isnan(dummy_loss)
    dummy_loss.backward()
    dp_opt.step()

    # Verify no NaN entered parameters
    for p in dp_model.parameters():
        assert not torch.isnan(p).any(), "NaN detected in parameters after empty batch step!"

    # Accountant stepped
    assert len(pe.accountant.history) == 1
    eps = pe.get_epsilon(delta=1e-5)
    assert eps > 0


def test_accountant_monotonicity_across_fl_rounds():
    """Verify that global weight reloads preserve accountant history and increase epsilon."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    device = torch.device("cpu")
    x = torch.randn(24, 1, 224, 224)
    y = torch.randint(0, 2, (24, 1)).float()
    train_ds = TensorDataset(x, y)
    val_ds = TensorDataset(x[:6], y[:6])

    train_loader = DataLoader(train_ds, batch_size=8, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=6, shuffle=False)

    client = HospitalDPClient(
        client_id="test_client",
        train_loader=train_loader,
        val_loader=val_loader,
        model=model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
    )

    epsilons = []
    total_steps = []

    for r in range(1, 4):
        # Reload global weights
        current_params = client.get_parameters()
        client.set_parameters(current_params)

        _, _, metrics = client.fit(current_params, config={"local_epochs": 1, "round": r})
        epsilons.append(metrics["epsilon"])
        total_steps.append(metrics["total_steps"])

    # Monotonicity checks
    assert epsilons[1] > epsilons[0], f"Epsilon failed to increase: {epsilons}"
    assert epsilons[2] > epsilons[1], f"Epsilon failed to increase: {epsilons}"
    assert total_steps[1] > total_steps[0]
    assert total_steps[2] > total_steps[1]


def test_existing_baseline_artifacts_hashes_intact():
    """Verify that centralized and FedAvg baseline files exist and have unchanged SHA256 hashes."""
    base_dir = Path(__file__).resolve().parent.parent
    hash_file = base_dir / "results" / "baseline_integrity_hashes.json"
    assert hash_file.exists(), f"Hash reference file not found: {hash_file}"

    with open(hash_file, "r") as f:
        reference_hashes = json.load(f)

    for rel_path, expected_hash in reference_hashes.items():
        full_path = base_dir / "results" / rel_path
        assert full_path.exists(), f"Baseline artifact missing: {full_path}"
        actual_hash = hashlib.sha256(full_path.read_bytes()).hexdigest()
        assert actual_hash == expected_hash, f"Hash mismatch for {rel_path}: expected {expected_hash}, got {actual_hash}"


def test_fedavg_dp_1_round_smoke(tmp_path):
    """Smoke test: 1 round of FedAvg + DP across 5 clients writing strictly to tmp_path."""
    history = run_fedavg_dp_experiment(
        num_rounds=1,
        local_epochs=1,
        samples_per_client=10,
        batch_size=8,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        learning_rate=1e-3,
        target_delta=1e-5,
        seed=42,
        output_dir=tmp_path,
    )

    # 1. Output artifacts created in tmp_path
    checkpoint_path = tmp_path / "fedavg_dp_global_model.pt"
    history_path = tmp_path / "fedavg_dp_training_history.json"
    assert checkpoint_path.exists(), "DP Global model checkpoint missing!"
    assert history_path.exists(), "DP Federated history JSON missing!"
    assert checkpoint_path.stat().st_size > 400_000

    # 2. Check client manifests in tmp_path
    for c in range(1, 6):
        assert (tmp_path / f"client_{c}_train.csv").exists()
        assert (tmp_path / f"client_{c}_val.csv").exists()

    # 3. Checkpoint loadability
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert "model_state_dict" in ckpt
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)

    # 4. History structure & privacy metadata
    assert history["experiment"] == "fedavg_dp_baseline"
    assert history["privacy_mechanism"] == "opacus_dp_sgd"
    assert history["poisson_sampling"] is True
    assert history["accountant_type"] == "PRVAccountant"
    assert "final_client_privacy" in history

    for c in range(1, 6):
        cid = f"hospital_{c}"
        assert cid in history["final_client_privacy"]
        cpriv = history["final_client_privacy"][cid]
        assert cpriv["epsilon"] > 0
        assert cpriv["delta"] == 1e-5
        assert cpriv["total_steps"] > 0

    # 5. Held-out test set evaluated strictly once
    assert "held_out_test_metrics" in history
    test_metrics = history["held_out_test_metrics"]
    assert test_metrics["sample_count"] == 30
    assert 0.0 <= test_metrics["accuracy"] <= 1.0
    assert 0.0 <= test_metrics["f1_score"] <= 1.0
    assert len(test_metrics["confusion_matrix"]) == 2

