"""Unit and integration tests for corrected FedAvg + DP (Opacus DP-SGD).

Verifies:
1. Local Adam optimizer state reset on set_parameters() without affecting PrivacyEngine.
2. Accountant persistence and monotonic epsilon growth across FL rounds under optimizer resets.
3. Corrected checkpoint selection rule: strictly mean validation F1, earliest round on tie.
4. Baseline preservation: all 30 artifacts across centralized, fedavg, and fedavg_dp baselines intact.
5. End-to-end 1-round smoke test writing strictly to tmp_path.
"""

from collections import OrderedDict
import hashlib
import json
from pathlib import Path
import pytest
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from clients.hospital_dp_client import HospitalDPClient
from experiments.fedavg_dp_corrected import (
    CorrectedDPFederatedServer,
    run_fedavg_dp_corrected_experiment,
)
from models.cnn import SmallChestXrayCNN


def test_optimizer_state_reset_on_set_parameters():
    """Verify that setting reset_optimizer_on_set_params=True clears Adam momentum and variance."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    device = torch.device("cpu")
    x = torch.randn(8, 1, 224, 224)
    y = torch.randint(0, 2, (8, 1)).float()
    loader = DataLoader(TensorDataset(x, y), batch_size=4)

    # 1. Test with reset_optimizer_on_set_params=True (Corrected mode)
    client_corrected = HospitalDPClient(
        client_id="test_corrected",
        train_loader=loader,
        val_loader=loader,
        model=model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=True,
    )

    # Step once to populate Adam momentum and variance state
    params = client_corrected.get_parameters()
    client_corrected.fit(params, config={"local_epochs": 1, "round": 1})
    assert len(client_corrected.dp_optimizer.state) > 0, "Optimizer state should be populated after training step!"

    # Call set_parameters with new/global parameters
    client_corrected.set_parameters(params)
    assert len(client_corrected.dp_optimizer.state) == 0, "Optimizer state was not cleared on set_parameters!"

    # 2. Test backward compatibility: reset_optimizer_on_set_params=False (Default mode)
    model2 = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    client_default = HospitalDPClient(
        client_id="test_default",
        train_loader=loader,
        val_loader=loader,
        model=model2,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=False,
    )
    params2 = client_default.get_parameters()
    client_default.fit(params2, config={"local_epochs": 1, "round": 1})
    assert len(client_default.dp_optimizer.state) > 0
    client_default.set_parameters(params2)
    assert len(client_default.dp_optimizer.state) > 0, "Default mode should retain optimizer state!"


def test_accountant_persistence_with_optimizer_reset():
    """Verify that clearing Adam state does NOT clear or alter Opacus PrivacyEngine accountant."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    device = torch.device("cpu")
    x = torch.randn(16, 1, 224, 224)
    y = torch.randint(0, 2, (16, 1)).float()
    loader = DataLoader(TensorDataset(x, y), batch_size=4)

    client = HospitalDPClient(
        client_id="test_client",
        train_loader=loader,
        val_loader=loader,
        model=model,
        device=device,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        target_delta=1e-5,
        reset_optimizer_on_set_params=True,
    )

    epsilons = []
    total_steps = []

    for r in range(1, 4):
        params = client.get_parameters()
        # set_parameters triggers optimizer state clear
        client.set_parameters(params)
        assert len(client.dp_optimizer.state) == 0

        _, _, metrics = client.fit(params, config={"local_epochs": 1, "round": r})
        epsilons.append(metrics["epsilon"])
        total_steps.append(metrics["total_steps"])

    # Monotonic privacy accounting must hold despite optimizer resets
    assert epsilons[1] > epsilons[0], f"Epsilon failed to increase: {epsilons}"
    assert epsilons[2] > epsilons[1], f"Epsilon failed to increase: {epsilons}"
    assert total_steps[0] > 0
    assert total_steps[1] > total_steps[0]
    assert total_steps[2] > total_steps[1]


def test_corrected_checkpoint_selection_strict_f1_earliest(tmp_path):
    """Verify checkpoint selection uses strict F1 and retains earliest round on tie without loss tie-breaker."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    device = torch.device("cpu")
    x = torch.randn(8, 1, 224, 224)
    y = torch.randint(0, 2, (8, 1)).float()
    test_loader = DataLoader(TensorDataset(x, y, torch.zeros(8)), batch_size=4)

    server = CorrectedDPFederatedServer(
        model=model,
        clients=[],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        criterion=nn.BCEWithLogitsLoss(),
    )

    # Mock run_round to simulate 4 rounds where F1 is all 0.0, but loss varies
    round_mocks = [
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.75, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.5}, "round": 1, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.50, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.6}, "round": 2, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.35, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.7}, "round": 3, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.20, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.8}, "round": 4, "client_train_metrics": {}, "client_val_metrics": {}},
    ]

    mock_idx = 0
    def mock_run_round(server_round, local_epochs=1):
        nonlocal mock_idx
        res = round_mocks[mock_idx]
        mock_idx += 1
        return res

    server.run_round = mock_run_round

    history = server.train(num_rounds=4, local_epochs=1)

    # Under strict F1-only selection, Round 1 (earliest) MUST be retained despite Round 4 having lower loss!
    assert history["best_round"] == 1, f"Expected Round 1 on tie, got Round {history['best_round']}"
    assert history["best_val_f1"] == 0.0

    checkpoint_path = tmp_path / "fedavg_dp_corrected_global_model.pt"
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert ckpt["round"] == 1


def test_corrected_checkpoint_selection_updates_on_strictly_higher_f1(tmp_path):
    """Verify checkpoint selection updates when a round achieves strictly higher F1."""
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    device = torch.device("cpu")
    x = torch.randn(8, 1, 224, 224)
    y = torch.randint(0, 2, (8, 1)).float()
    test_loader = DataLoader(TensorDataset(x, y, torch.zeros(8)), batch_size=4)

    server = CorrectedDPFederatedServer(
        model=model,
        clients=[],
        test_loader=test_loader,
        device=device,
        output_dir=tmp_path,
        criterion=nn.BCEWithLogitsLoss(),
    )

    round_mocks = [
        {"mean_val_metrics": {"mean_val_f1": 0.0, "mean_val_loss": 0.70, "mean_val_accuracy": 0.5, "mean_val_precision": 0.0, "mean_val_recall": 0.0, "mean_val_roc_auc": 0.5}, "round": 1, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.40, "mean_val_loss": 0.65, "mean_val_accuracy": 0.6, "mean_val_precision": 0.4, "mean_val_recall": 0.4, "mean_val_roc_auc": 0.6}, "round": 2, "client_train_metrics": {}, "client_val_metrics": {}},
        {"mean_val_metrics": {"mean_val_f1": 0.40, "mean_val_loss": 0.55, "mean_val_accuracy": 0.6, "mean_val_precision": 0.4, "mean_val_recall": 0.4, "mean_val_roc_auc": 0.65}, "round": 3, "client_train_metrics": {}, "client_val_metrics": {}},
    ]

    mock_idx = 0
    def mock_run_round(server_round, local_epochs=1):
        nonlocal mock_idx
        res = round_mocks[mock_idx]
        mock_idx += 1
        return res

    server.run_round = mock_run_round

    history = server.train(num_rounds=3, local_epochs=1)

    # Round 2 has higher F1 than Round 1 (0.40 > 0.0). Round 3 ties Round 2 at 0.40.
    # Earliest round attaining max F1 (0.40) is Round 2.
    assert history["best_round"] == 2
    assert history["best_val_f1"] == 0.40

    checkpoint_path = tmp_path / "fedavg_dp_corrected_global_model.pt"
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert ckpt["round"] == 2


def test_all_baseline_artifacts_and_hashes_preserved():
    """Verify that all 30 baseline artifacts across all 3 prior baselines remain 100% intact."""
    base_dir = Path(__file__).resolve().parent.parent

    # Known reference SHA256 digests for all 30 baseline artifacts
    expected_hashes = {
        "centralized_baseline/centralized_cnn_checkpoint.pt": "05c0f24bfee8b0cacf69ed701800d0cefd8c95914eeab554f6abb2665bd1efba",
        "centralized_baseline/centralized_training_history.json": "4b9a0c60540f416b5be96c72e5310f25427e680d9345418abd1f68e318ff330f",
        "centralized_baseline/task-190_recovered_baseline_record.json": "9082eba8c90289aa01189593fde1fb04262293beccae267a134b6ca9c95b6621",
        "centralized_baseline/test_split.csv": "bebf37a2376bd6293e806fdfcfa210fbbe4b146919a29eadb4d2175f9a805504",
        "centralized_baseline/train_split.csv": "1e2ab3a1ca367095810799af9e74f130778e46ac0da4547dbf1c6229ad1124a9",
        "centralized_baseline/val_split.csv": "bd18c6704b9f40a0ba3585c4d6c88127dbfd56f4e6eed9f3231d72b8c80edb45",
        "fedavg_baseline/client_1_train.csv": "e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3",
        "fedavg_baseline/client_1_val.csv": "50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9",
        "fedavg_baseline/client_2_train.csv": "2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703",
        "fedavg_baseline/client_2_val.csv": "2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c",
        "fedavg_baseline/client_3_train.csv": "df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357",
        "fedavg_baseline/client_3_val.csv": "ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8",
        "fedavg_baseline/client_4_train.csv": "360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c",
        "fedavg_baseline/client_4_val.csv": "225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22",
        "fedavg_baseline/client_5_train.csv": "33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5",
        "fedavg_baseline/client_5_val.csv": "ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246",
        "fedavg_baseline/fedavg_global_model.pt": "d2c9dd56f907fd48b0ce36bd6b24b3ac6066c0b9b803c9e7970b75194e11cf84",
        "fedavg_baseline/fedavg_training_history.json": "497fe39d70bd0539fa733d4b1b28860542bb3e2e3ca7281cb4b795788ea8d9c7",
        "fedavg_dp_baseline/client_1_train.csv": "e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3",
        "fedavg_dp_baseline/client_1_val.csv": "50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9",
        "fedavg_dp_baseline/client_2_train.csv": "2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703",
        "fedavg_dp_baseline/client_2_val.csv": "2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c",
        "fedavg_dp_baseline/client_3_train.csv": "df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357",
        "fedavg_dp_baseline/client_3_val.csv": "ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8",
        "fedavg_dp_baseline/client_4_train.csv": "360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c",
        "fedavg_dp_baseline/client_4_val.csv": "225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22",
        "fedavg_dp_baseline/client_5_train.csv": "33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5",
        "fedavg_dp_baseline/client_5_val.csv": "ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246",
        "fedavg_dp_baseline/fedavg_dp_global_model.pt": "e5de6bd5684ed4652624efde55921370f2dece35be04bbcb8f29beeddb5ad759",
        "fedavg_dp_baseline/fedavg_dp_training_history.json": "2ee7871355a9e987877b0a1d38c4f91722d88b71eff151659a6c4e99e953b2b9",
    }

    assert len(expected_hashes) == 30
    for rel_path, expected_hash in expected_hashes.items():
        full_path = base_dir / "results" / rel_path
        assert full_path.exists(), f"Baseline artifact missing: {full_path}"
        actual_hash = hashlib.sha256(full_path.read_bytes()).hexdigest()
        assert actual_hash == expected_hash, f"Hash mismatch for {rel_path}: expected {expected_hash}, got {actual_hash}"


def test_corrected_dp_smoke_1_round(tmp_path):
    """Smoke test: 1 round of corrected FedAvg + DP writing strictly to tmp_path."""
    history = run_fedavg_dp_corrected_experiment(
        num_rounds=1,
        local_epochs=1,
        samples_per_client=10,
        batch_size=8,
        noise_multiplier=1.0,
        max_grad_norm=1.0,
        learning_rate=1e-3,
        target_delta=1e-5,
        seed=42,
        output_dir=tmp_path,
    )

    # 1. Output artifacts created in tmp_path
    checkpoint_path = tmp_path / "fedavg_dp_corrected_global_model.pt"
    history_path = tmp_path / "fedavg_dp_corrected_training_history.json"
    assert checkpoint_path.exists(), "Corrected checkpoint missing!"
    assert history_path.exists(), "Corrected history missing!"

    # 2. Checkpoint loadability
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert "model_state_dict" in ckpt
    model = SmallChestXrayCNN(in_channels=1, num_classes=1, num_groups=4)
    model.load_state_dict(ckpt["model_state_dict"], strict=True)

    # 3. History metadata
    assert history["experiment"] == "fedavg_dp_corrected"
    assert history["optimizer_reset_on_set_params"] is True
    assert history["selection_rule"] == "strict_mean_val_f1_earliest_tie"
    assert history["decision_threshold"] == 0.5
    assert history["held_out_test_metrics"]["sample_count"] == 30

    # 4. Verify results/fedavg_dp_corrected/ was not created during tmp_path run
    base_dir = Path(__file__).resolve().parent.parent
    real_corrected_dir = base_dir / "results" / "fedavg_dp_corrected"
    assert not real_corrected_dir.exists(), "Test must not write to official results directory!"
