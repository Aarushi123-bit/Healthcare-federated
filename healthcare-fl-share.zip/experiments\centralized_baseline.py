"""Centralized CNN training baseline on NIH ChestX-ray14.

Binary Classification Task:
- Positive (y = 1.0): Pneumonia (images where 'Pneumonia' is in 'Finding Labels').
- Negative (y = 0.0): No Finding (images from patients who NEVER had pneumonia).

Design Principles:
1. Patient-Wise Separation: No patient ID can appear in more than one split (Train, Val, Test).
2. Pure Control Cohort: Controls are selected strictly from patients without pneumonia history.
3. On-Demand Image Loading: Only images needed for batches are loaded into RAM via PIL.
4. Reproducibility: Seeded data sampling, splitting, and model weight initialization.
5. Held-Out Test Evaluation: The test split is evaluated only once on the best model, never tuned upon.
"""

from pathlib import Path
import sys
from typing import Dict, Optional, Tuple
import json
import time
import numpy as np
import pandas as pd
from PIL import Image
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import yaml

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from data.dataset import resolve_image_path
from data.partitioning import build_image_index, load_nih_metadata
from models.cnn import SmallChestXrayCNN


def load_config(config_path: Optional[Path] = None) -> dict:
    """Load configuration from config.yaml."""
    if config_path is None:
        config_path = BASE_DIR / "config.yaml"
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ------------------------------------------------------------------------------
# 1. Cohort Construction & Patient-Wise Splitting
# ------------------------------------------------------------------------------


def build_binary_cohort(
    df: pd.DataFrame,
    image_index: Dict[str, dict],
    raw_dir: Path,
    n_samples_per_class: int = 100,
    seed: int = 42,
) -> pd.DataFrame:
    """Extract a balanced cohort for Pneumonia (1.0) vs. No Finding (0.0).

    Selection Criteria:
      - Positive Class (y=1.0): Images where 'Pneumonia' is listed in 'Finding Labels'.
        1 representative scan per unique pneumonia patient.
      - Negative Class (y=0.0): Images with 'No Finding' from patients who NEVER
        had a pneumonia diagnosis in any recorded scan.
        1 representative scan per unique normal patient.

    Guarantees:
      - Set of pneumonia patients and normal patients are strictly disjoint from the outset.
    """
    # 1. Identify positive cases (Pneumonia)
    pneu_mask = df["Finding Labels"].apply(
        lambda x: "Pneumonia" in [f.strip() for f in str(x).split("|")]
    )
    pneu_df = df[pneu_mask].copy()
    pneu_patients = set(pneu_df["Patient ID"])

    # 1 scan per unique pneumonia patient
    pneu_unique = pneu_df.groupby("Patient ID").first().reset_index()

    # 2. Identify pure negative controls (No Finding, NEVER diagnosed with pneumonia)
    normal_mask = (df["Finding Labels"] == "No Finding") & (~df["Patient ID"].isin(pneu_patients))
    normal_df = df[normal_mask].copy()
    normal_unique = normal_df.groupby("Patient ID").first().reset_index()

    # 3. Sample balanced cohorts reproducibly
    sampled_pneu = pneu_unique.sample(n=min(n_samples_per_class, len(pneu_unique)), random_state=seed).copy()
    sampled_norm = normal_unique.sample(n=min(n_samples_per_class, len(normal_unique)), random_state=seed).copy()

    sampled_pneu["label"] = 1.0
    sampled_pneu["class_name"] = "Pneumonia"
    sampled_norm["label"] = 0.0
    sampled_norm["class_name"] = "No Finding"

    cohort = pd.concat([sampled_pneu, sampled_norm]).sample(frac=1.0, random_state=seed).reset_index(drop=True)

    # Attach relative file paths
    cohort["relative_path"] = cohort["Image Index"].map(
        lambda name: image_index[name]["relative_path"] if name in image_index else None
    )

    return cohort


def split_cohort_patient_wise(
    cohort_df: pd.DataFrame,
    test_ratio: float = 0.15,
    val_ratio: float = 0.15,
    seed: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Split cohort into Train, Validation, and Test sets stratified by label.

    Strict Invariant:
      Patients(Train) ∩ Patients(Val) = ∅
      Patients(Train) ∩ Patients(Test) = ∅
      Patients(Val) ∩ Patients(Test) = ∅
    """
    # Step 1: Split off held-out test set
    train_val, test_df = train_test_split(
        cohort_df,
        test_size=test_ratio,
        stratify=cohort_df["label"],
        random_state=seed,
    )

    # Step 2: Split remaining into train and validation
    # Adjusted val fraction relative to train_val size
    adjusted_val_ratio = val_ratio / (1.0 - test_ratio)
    train_df, val_df = train_test_split(
        train_val,
        test_size=adjusted_val_ratio,
        stratify=train_val["label"],
        random_state=seed,
    )

    # Invariant Verification
    p_train = set(train_df["Patient ID"])
    p_val = set(val_df["Patient ID"])
    p_test = set(test_df["Patient ID"])

    assert len(p_train.intersection(p_val)) == 0, "Patient leakage between Train and Val!"
    assert len(p_train.intersection(p_test)) == 0, "Patient leakage between Train and Test!"
    assert len(p_val.intersection(p_test)) == 0, "Patient leakage between Val and Test!"

    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


# ------------------------------------------------------------------------------
# 2. PyTorch Dataset for Binary Task
# ------------------------------------------------------------------------------


class BinaryChestXrayDataset(Dataset):
    """Lazy PyTorch Dataset loading single-channel grayscale chest X-rays with binary labels."""

    def __init__(
        self,
        df: pd.DataFrame,
        raw_dir: Path,
        image_size: Tuple[int, int] = (224, 224),
    ):
        self.df = df.reset_index(drop=True)
        self.raw_dir = Path(raw_dir)
        self.image_size = image_size

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        row = self.df.iloc[idx]
        image_name = row["Image Index"]
        rel_path = row.get("relative_path", None)

        # Resolve path across images_001-012
        file_path = resolve_image_path(self.raw_dir, image_name, rel_path)

        # Load with PIL, convert to grayscale 'L', resize to (224, 224)
        with Image.open(file_path) as img:
            gray = img.convert("L")
            resized = gray.resize(self.image_size, resample=Image.Resampling.BILINEAR)
            arr = np.array(resized, dtype=np.float32) / 255.0

        img_tensor = torch.from_numpy(arr).unsqueeze(0)  # Shape (1, 224, 224)
        label_tensor = torch.tensor([row["label"]], dtype=torch.float32)  # Shape (1,)

        meta = {
            "image_index": image_name,
            "patient_id": int(row["Patient ID"]),
            "class_name": row["class_name"],
            "finding_labels": row["Finding Labels"],
        }
        return img_tensor, label_tensor, meta


# ------------------------------------------------------------------------------
# 3. Model Evaluation Function
# ------------------------------------------------------------------------------


def evaluate_model(
    model: nn.Module,
    loader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> dict:
    """Evaluate model on a DataLoader and compute clinical classification metrics."""
    model.eval()
    total_loss = 0.0
    all_targets = []
    all_preds = []
    all_probs = []

    with torch.no_grad():
        for batch_images, batch_labels, _ in loader:
            batch_images = batch_images.to(device)
            batch_labels = batch_labels.to(device)

            logits = model(batch_images)
            loss = criterion(logits, batch_labels)
            total_loss += loss.item() * batch_images.size(0)

            probs = torch.sigmoid(logits).cpu().numpy().flatten()
            preds = (probs >= 0.5).astype(int)
            targets = batch_labels.cpu().numpy().flatten().astype(int)

            all_probs.extend(probs.tolist())
            all_preds.extend(preds.tolist())
            all_targets.extend(targets.tolist())

    y_true = np.array(all_targets)
    y_pred = np.array(all_preds)
    y_prob = np.array(all_probs)

    avg_loss = total_loss / len(loader.dataset)
    acc = float(accuracy_score(y_true, y_pred))
    prec = float(precision_score(y_true, y_pred, zero_division=0))
    rec = float(recall_score(y_true, y_pred, zero_division=0))
    f1 = float(f1_score(y_true, y_pred, zero_division=0))
    cm = confusion_matrix(y_true, y_pred).tolist()

    try:
        auc = float(roc_auc_score(y_true, y_prob))
    except ValueError:
        auc = 0.5

    return {
        "loss": float(avg_loss),
        "accuracy": acc,
        "precision": prec,
        "recall": rec,
        "f1_score": f1,
        "roc_auc": auc,
        "confusion_matrix": cm,
        "sample_count": len(y_true),
    }


# ------------------------------------------------------------------------------
# 4. Training Engine
# ------------------------------------------------------------------------------


def run_centralized_training(
    n_samples_per_class: int = 100,
    epochs: int = 5,
    batch_size: int = 16,
    learning_rate: float = 1e-3,
    image_size: Tuple[int, int] = (224, 224),
    seed: int = 42,
    config_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> dict:
    """Execute end-to-end centralized CNN baseline training.

    Saves:
      - Model checkpoint: output_dir / centralized_cnn_checkpoint.pt
      - Training history & metrics: output_dir / centralized_training_history.json
      - Split manifests: output_dir / (train|val|test)_split.csv
    """
    # 1. Load config and paths
    cfg = load_config(config_path)
    raw_dir = Path(cfg["dataset"]["raw_dir"])

    if output_dir is None:
        output_dir = BASE_DIR / "results" / "centralized_baseline"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    torch.manual_seed(seed)
    np.random.seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 2. Build image index & metadata
    image_index = build_image_index(raw_dir)
    csv_path = raw_dir / "Data_Entry_2017.csv"
    df = load_nih_metadata(csv_path, image_index=image_index)

    # 3. Build cohort and patient-wise splits
    cohort_df = build_binary_cohort(
        df=df,
        image_index=image_index,
        raw_dir=raw_dir,
        n_samples_per_class=n_samples_per_class,
        seed=seed,
    )
    train_df, val_df, test_df = split_cohort_patient_wise(
        cohort_df=cohort_df,
        test_ratio=0.15,
        val_ratio=0.15,
        seed=seed,
    )

    # 3b. Save split manifests with explicit patient-isolation verification
    manifest_cols = ["Image Index", "Patient ID", "label", "class_name", "Finding Labels", "relative_path"]
    train_manifest_path = output_dir / "train_split.csv"
    val_manifest_path = output_dir / "val_split.csv"
    test_manifest_path = output_dir / "test_split.csv"

    # Assert zero patient ID leakage across splits prior to saving
    p_train = set(train_df["Patient ID"])
    p_val = set(val_df["Patient ID"])
    p_test = set(test_df["Patient ID"])
    assert len(p_train.intersection(p_val)) == 0, "Patient leakage detected: Train and Val!"
    assert len(p_train.intersection(p_test)) == 0, "Patient leakage detected: Train and Test!"
    assert len(p_val.intersection(p_test)) == 0, "Patient leakage detected: Val and Test!"

    train_df[manifest_cols].to_csv(train_manifest_path, index=False)
    val_df[manifest_cols].to_csv(val_manifest_path, index=False)
    test_df[manifest_cols].to_csv(test_manifest_path, index=False)

    # 4. Create DataLoaders
    train_ds = BinaryChestXrayDataset(train_df, raw_dir, image_size=image_size)
    val_ds = BinaryChestXrayDataset(val_df, raw_dir, image_size=image_size)
    test_ds = BinaryChestXrayDataset(test_df, raw_dir, image_size=image_size)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    # 5. Initialize CNN (single output logit for binary classification)
    model = SmallChestXrayCNN(
        in_channels=1,
        num_classes=1,
        num_groups=4,
        dropout=0.1,
    ).to(device)

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)

    # 6. Training loop
    history = []
    best_val_f1 = -1.0
    best_epoch = -1
    checkpoint_path = output_dir / "centralized_cnn_checkpoint.pt"

    start_time = time.time()
    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        for batch_imgs, batch_lbls, _ in train_loader:
            batch_imgs = batch_imgs.to(device)
            batch_lbls = batch_lbls.to(device)

            optimizer.zero_grad()
            logits = model(batch_imgs)
            loss = criterion(logits, batch_lbls)
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * batch_imgs.size(0)

        epoch_train_loss = train_loss / len(train_ds)

        # Evaluate on validation split
        val_metrics = evaluate_model(model, val_loader, criterion, device)

        epoch_record = {
            "epoch": epoch,
            "train_loss": round(epoch_train_loss, 4),
            "val_loss": round(val_metrics["loss"], 4),
            "val_accuracy": round(val_metrics["accuracy"], 4),
            "val_precision": round(val_metrics["precision"], 4),
            "val_recall": round(val_metrics["recall"], 4),
            "val_f1_score": round(val_metrics["f1_score"], 4),
            "val_roc_auc": round(val_metrics["roc_auc"], 4),
            "val_confusion_matrix": val_metrics["confusion_matrix"],
        }
        history.append(epoch_record)

        # Checkpoint selection based on validation F1-score
        if val_metrics["f1_score"] >= best_val_f1:
            best_val_f1 = val_metrics["f1_score"]
            best_epoch = epoch
            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "best_val_f1": best_val_f1,
                    "hyperparameters": {
                        "epochs": epochs,
                        "batch_size": batch_size,
                        "learning_rate": learning_rate,
                        "image_size": list(image_size),
                        "seed": seed,
                    },
                },
                checkpoint_path,
            )

    train_duration = time.time() - start_time

    # 7. Final Held-Out Test Evaluation (using best model checkpoint)
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    test_metrics = evaluate_model(model, test_loader, criterion, device)

    # 8. Compile and save results
    log_file = output_dir / "centralized_training_history.json"
    experiment_results = {
        "task": "Pneumonia vs. No Finding (Binary Classification)",
        "dataset": "NIH ChestX-ray14",
        "random_seed": seed,
        "device": str(device),
        "preprocessing": {
            "normalization": "Grayscale 'L', scaled to [0.0, 1.0]",
            "image_size": list(image_size),
            "interpolation": "Bilinear",
        },
        "hyperparameters": {
            "epochs": epochs,
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            "optimizer": "Adam",
            "loss_function": "BCEWithLogitsLoss",
            "weight_decay": 1e-4,
        },
        "cohort_breakdown": {
            "total_images": len(cohort_df),
            "total_patients": cohort_df["Patient ID"].nunique(),
            "train_samples": len(train_df),
            "train_patients": train_df["Patient ID"].nunique(),
            "val_samples": len(val_df),
            "val_patients": val_df["Patient ID"].nunique(),
            "test_samples": len(test_df),
            "test_patients": test_df["Patient ID"].nunique(),
            "class_counts": {
                "Pneumonia": int((cohort_df["label"] == 1.0).sum()),
                "No Finding": int((cohort_df["label"] == 0.0).sum()),
            },
        },
        "training_time_seconds": round(train_duration, 2),
        "best_epoch": best_epoch,
        "best_val_f1": round(best_val_f1, 4),
        "training_history": history,
        "held_out_test_metrics": {
            "accuracy": round(test_metrics["accuracy"], 4),
            "precision": round(test_metrics["precision"], 4),
            "recall": round(test_metrics["recall"], 4),
            "f1_score": round(test_metrics["f1_score"], 4),
            "roc_auc": round(test_metrics["roc_auc"], 4),
            "confusion_matrix": test_metrics["confusion_matrix"],
            "sample_count": test_metrics["sample_count"],
        },
        "artifacts": {
            "output_directory": str(output_dir),
            "model_checkpoint": str(checkpoint_path),
            "history_log": str(log_file),
            "train_split_manifest": str(train_manifest_path),
            "val_split_manifest": str(val_manifest_path),
            "test_split_manifest": str(test_manifest_path),
        },
    }

    # Save history log
    with open(log_file, "w", encoding="utf-8") as f:
        json.dump(experiment_results, f, indent=2)

    return experiment_results


# ------------------------------------------------------------------------------
# 5. CLI Entrypoint
# ------------------------------------------------------------------------------


def run_centralized_cli():
    """Run centralized baseline training and display beginner-friendly reporting."""
    print("=" * 70)
    print("  CENTRALIZED CNN TRAINING BASELINE (NIH CHESTX-RAY14)")
    print("=" * 70)

    print("\nTask Definition:")
    print("  - Binary Target : Pneumonia (1.0) vs. No Finding (0.0)")
    print("  - Control Cohort: Strictly normal patients (never diagnosed with pneumonia)")
    print("  - Separation    : Patient-wise Train/Val/Test (zero patient overlap)")

    results = run_centralized_training(
        n_samples_per_class=100,
        epochs=5,
        batch_size=16,
        learning_rate=1e-3,
        seed=42,
    )

    cb = results["cohort_breakdown"]
    print(f"\nCohort & Partition Breakdown (Seed = {results['random_seed']}):")
    print(f"  - Total Samples   : {cb['total_images']} ({cb['class_counts']['Pneumonia']} Pneumonia, {cb['class_counts']['No Finding']} Normal)")
    print(f"  - Total Patients  : {cb['total_patients']} unique patients")
    print(f"  - Train Split     : {cb['train_samples']} samples ({cb['train_patients']} patients)")
    print(f"  - Val Split       : {cb['val_samples']} samples ({cb['val_patients']} patients)")
    print(f"  - Held-out Test   : {cb['test_samples']} samples ({cb['test_patients']} patients) [NEVER tuned on]")

    print(f"\nTraining Progress ({results['hyperparameters']['epochs']} Epochs in {results['training_time_seconds']}s):")
    print(f"  {'Epoch':<6} | {'Train Loss':<11} | {'Val Loss':<9} | {'Val Acc':<8} | {'Val Prec':<9} | {'Val Rec':<8} | {'Val F1'}")
    print("-" * 70)
    for h in results["training_history"]:
        print(
            f"  {h['epoch']:<6} | {h['train_loss']:<11.4f} | {h['val_loss']:<9.4f} | "
            f"{h['val_accuracy']:<8.4f} | {h['val_precision']:<9.4f} | {h['val_recall']:<8.4f} | {h['val_f1_score']:.4f}"
        )

    tm = results["held_out_test_metrics"]
    cm = tm["confusion_matrix"]
    print(f"\nFinal Held-Out Test Evaluation (Evaluated Once on Best Model @ Epoch {results['best_epoch']}):")
    print(f"  - Accuracy        : {tm['accuracy']:.4f} ({tm['accuracy']*100:.1f}%)")
    print(f"  - Precision       : {tm['precision']:.4f}")
    print(f"  - Recall          : {tm['recall']:.4f}")
    print(f"  - F1-Score        : {tm['f1_score']:.4f}")
    print(f"  - ROC-AUC         : {tm['roc_auc']:.4f}")
    print(f"  - Confusion Matrix:")
    print(f"      [TN={cm[0][0]:>2}, FP={cm[0][1]:>2}]  (Normal)")
    print(f"      [FN={cm[1][0]:>2}, TP={cm[1][1]:>2}]  (Pneumonia)")

    print(f"\nSaved Artifacts:")
    print(f"  - Model Checkpoint: {results['artifacts']['model_checkpoint']}")
    print(f"  - Full History Log: {results['artifacts']['history_log']}")

    print("\n" + "=" * 70)
    print("CENTRALIZED BASELINE RUN COMPLETE")
    print("=" * 70)


if __name__ == "__main__":
    run_centralized_cli()

