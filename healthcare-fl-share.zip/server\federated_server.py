"""Federated Server and Orchestration Module.

Implements the central orchestrator for FedAvg federated learning, managing
parameter broadcasting, weighted aggregation via Flower's FedAvg algorithm,
client-level validation monitoring, model checkpointing, and held-out test evaluation.
"""

from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import json
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from flwr.server.strategy.aggregate import aggregate

from clients.hospital_client import HospitalClient
from experiments.centralized_baseline import evaluate_model


class FederatedServer:
    """Federated Learning Server orchestrating iterative FedAvg aggregation."""

    def __init__(
        self,
        model: nn.Module,
        clients: List[HospitalClient],
        test_loader: DataLoader,
        device: torch.device,
        output_dir: Path,
        criterion: Optional[nn.Module] = None,
    ):
        self.model = model
        self.clients = clients
        self.test_loader = test_loader
        self.device = device
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.criterion = criterion or nn.BCEWithLogitsLoss()

    def get_parameters(self) -> List[np.ndarray]:
        """Extract global model weights as NumPy ndarrays."""
        return [val.cpu().numpy() for _, val in self.model.state_dict().items()]

    def set_parameters(self, parameters: List[np.ndarray]) -> None:
        """Update global model weights from NumPy ndarrays."""
        params_dict = zip(self.model.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.as_tensor(v) for k, v in params_dict})
        self.model.load_state_dict(state_dict, strict=True)

    def run_round(
        self,
        server_round: int,
        local_epochs: int = 1,
    ) -> Dict[str, Any]:
        """Execute a single FedAvg communication round across all clients.

        Steps:
        1. Broadcast current global parameters to clients.
        2. Perform local training on each client.
        3. Aggregate updated parameters using sample-count weighting.
        4. Update global model parameters.
        5. Evaluate updated global model on local client validation sets.
        """
        current_parameters = self.get_parameters()
        fit_config = {"local_epochs": local_epochs, "round": server_round}

        # 1. Local Training on Clients
        fit_results = []
        client_train_metrics = {}

        for client in self.clients:
            weights, num_examples, metrics = client.fit(
                parameters=current_parameters,
                config=fit_config,
            )
            fit_results.append((weights, num_examples))
            client_train_metrics[client.client_id] = metrics

        # 2. Server-side Weighted Aggregation (Flower FedAvg)
        aggregated_weights = aggregate(fit_results)
        self.set_parameters(aggregated_weights)

        # 3. Validation Evaluation Across All Clients
        eval_config = {"round": server_round}
        client_val_metrics = {}
        val_losses = []
        val_accuracies = []
        val_precisions = []
        val_recalls = []
        val_f1_scores = []
        val_roc_aucs = []

        updated_parameters = self.get_parameters()
        for client in self.clients:
            loss, num_examples, metrics = client.evaluate(
                parameters=updated_parameters,
                config=eval_config,
            )
            client_val_metrics[client.client_id] = metrics
            val_losses.append(metrics["loss"])
            val_accuracies.append(metrics["accuracy"])
            val_precisions.append(metrics["precision"])
            val_recalls.append(metrics["recall"])
            val_f1_scores.append(metrics["f1_score"])
            val_roc_aucs.append(metrics["roc_auc"])

        mean_val_metrics = {
            "mean_val_loss": round(float(np.mean(val_losses)), 4),
            "mean_val_accuracy": round(float(np.mean(val_accuracies)), 4),
            "mean_val_precision": round(float(np.mean(val_precisions)), 4),
            "mean_val_recall": round(float(np.mean(val_recalls)), 4),
            "mean_val_f1": round(float(np.mean(val_f1_scores)), 4),
            "mean_val_roc_auc": round(float(np.mean(val_roc_aucs)), 4),
        }

        return {
            "round": server_round,
            "client_train_metrics": client_train_metrics,
            "client_val_metrics": client_val_metrics,
            "mean_val_metrics": mean_val_metrics,
        }

    def train(
        self,
        num_rounds: int = 5,
        local_epochs: int = 1,
    ) -> Dict[str, Any]:
        """Execute full iterative FedAvg federated training loop."""
        checkpoint_path = self.output_dir / "fedavg_global_model.pt"
        history_path = self.output_dir / "fedavg_training_history.json"

        round_history = []
        best_round = -1
        best_val_f1 = -1.0
        best_val_loss = float("inf")

        start_time = time.time()

        for r in range(1, num_rounds + 1):
            round_summary = self.run_round(
                server_round=r,
                local_epochs=local_epochs,
            )
            round_history.append(round_summary)

            cur_f1 = round_summary["mean_val_metrics"]["mean_val_f1"]
            cur_loss = round_summary["mean_val_metrics"]["mean_val_loss"]

            # Frozen Model Selection Rule:
            # 1. Highest Mean Client Validation F1
            # 2. Lower Mean Validation Loss (tie-breaker)
            is_better = (cur_f1 > best_val_f1) or (
                cur_f1 == best_val_f1 and cur_loss < best_val_loss
            )

            if is_better:
                best_val_f1 = cur_f1
                best_val_loss = cur_loss
                best_round = r
                torch.save(
                    {
                        "round": r,
                        "model_state_dict": self.model.state_dict(),
                        "mean_val_f1": best_val_f1,
                        "mean_val_loss": best_val_loss,
                    },
                    checkpoint_path,
                )

        total_duration = time.time() - start_time

        # Held-Out Test Set Evaluation: Evaluated strictly ONCE on the selected best model
        assert checkpoint_path.exists(), "Best model checkpoint was not saved!"
        best_checkpoint = torch.load(
            checkpoint_path, map_location=self.device, weights_only=False
        )
        self.model.load_state_dict(best_checkpoint["model_state_dict"])

        test_metrics = evaluate_model(
            model=self.model,
            loader=self.test_loader,
            criterion=self.criterion,
            device=self.device,
        )

        final_history = {
            "experiment": "fedavg_baseline_no_dp",
            "num_rounds": num_rounds,
            "local_epochs": local_epochs,
            "num_clients": len(self.clients),
            "best_round": best_round,
            "best_val_f1": best_val_f1,
            "best_val_loss": best_val_loss,
            "training_duration_seconds": round(total_duration, 2),
            "rounds": round_history,
            "held_out_test_metrics": test_metrics,
            "checkpoint_path": str(checkpoint_path.resolve()),
        }

        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(final_history, f, indent=2)

        return final_history
