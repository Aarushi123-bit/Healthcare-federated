"""Verification script for the NIH ChestX-ray14 dataset.

This script performs Phase 1 data verification:
1. Confirms the dataset directory exists on the external drive.
2. Confirms Data_Entry_2017.csv exists and can be read.
3. Checks required metadata columns: image filename, patient ID, and labels.
4. Checks that all 12 image directories (images_001 through images_012) exist.
5. Verifies the presence and disk size of sample referenced image files
   WITHOUT loading full image matrices into memory.
"""

from pathlib import Path
import os
import pandas as pd
import pytest
import yaml

# ------------------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------------------


def load_config(config_path: Path = None) -> dict:
    """Load configuration from config.yaml."""
    if config_path is None:
        base_dir = Path(__file__).resolve().parent.parent
        config_path = base_dir / "config.yaml"
        if not config_path.exists():
            config_path = Path("config.yaml").resolve()

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found at: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_dataset_root() -> Path:
    """Retrieve and validate dataset raw_dir path from config.yaml."""
    cfg = load_config()
    raw_dir_str = cfg.get("dataset", {}).get("raw_dir")
    if not raw_dir_str:
        raise ValueError("Missing 'dataset.raw_dir' in config.yaml")
    return Path(raw_dir_str)


def resolve_image_folder(dataset_root: Path, folder_idx: int) -> Path:
    """Locate the image directory for images_{001-012}, supporting nested 'images' subfolder."""
    base_folder = dataset_root / f"images_{folder_idx:03d}"
    nested_folder = base_folder / "images"
    if nested_folder.is_dir():
        return nested_folder
    return base_folder


# ------------------------------------------------------------------------------
# Test Suite / Verifications
# ------------------------------------------------------------------------------


def test_dataset_directory_exists():
    """Requirement 1: Confirm the dataset directory exists on the target drive."""
    dataset_root = get_dataset_root()
    assert dataset_root.exists(), f"Dataset directory does not exist: {dataset_root}"
    assert dataset_root.is_dir(), f"Dataset path is not a directory: {dataset_root}"


def test_metadata_csv_readable():
    """Requirement 2: Confirm Data_Entry_2017.csv exists and can be parsed."""
    dataset_root = get_dataset_root()
    csv_path = dataset_root / "Data_Entry_2017.csv"

    assert csv_path.exists(), f"Data_Entry_2017.csv not found at: {csv_path}"
    assert csv_path.is_file(), f"Expected a file at: {csv_path}"
    assert csv_path.stat().st_size > 0, "Data_Entry_2017.csv is empty"

    # Read the first few rows to verify readability without heavy memory overhead
    df_sample = pd.read_csv(csv_path, nrows=10)
    assert len(df_sample) == 10, f"Expected 10 rows in sample, read {len(df_sample)}"


def test_metadata_columns():
    """Requirement 3: Check required columns (Image Index, Patient ID, Finding Labels)."""
    dataset_root = get_dataset_root()
    csv_path = dataset_root / "Data_Entry_2017.csv"

    df_sample = pd.read_csv(csv_path, nrows=5)
    columns = [col.strip() for col in df_sample.columns]

    required_columns = ["Image Index", "Patient ID", "Finding Labels"]
    for col in required_columns:
        assert col in columns, f"Required column '{col}' missing from metadata. Found: {columns}"

    # Verify sample data values are non-null
    for col in required_columns:
        assert df_sample[col].notna().all(), f"Found unexpected null values in column '{col}'"


def test_all_12_image_folders_exist():
    """Requirement 4: Confirm images_001 through images_012 all exist."""
    dataset_root = get_dataset_root()

    missing_folders = []
    found_folders = []

    for i in range(1, 13):
        folder_name = f"images_{i:03d}"
        folder_path = dataset_root / folder_name
        if folder_path.is_dir():
            resolved = resolve_image_folder(dataset_root, i)
            found_folders.append((folder_name, resolved))
        else:
            missing_folders.append(folder_name)

    assert len(missing_folders) == 0, f"Missing image folders: {missing_folders}"
    assert len(found_folders) == 12, f"Expected 12 folders, found {len(found_folders)}"


def test_referenced_images_exist_on_disk():
    """Requirement 5: Verify presence of sample referenced images without loading them into RAM."""
    dataset_root = get_dataset_root()
    csv_path = dataset_root / "Data_Entry_2017.csv"

    # Read sample image filenames from metadata
    df_sample = pd.read_csv(csv_path, nrows=5)
    sample_filenames = df_sample["Image Index"].tolist()

    # Pre-build folder search paths
    search_folders = [resolve_image_folder(dataset_root, i) for i in range(1, 13)]

    verified_samples = []
    for filename in sample_filenames:
        found_path = None
        for folder in search_folders:
            candidate = folder / filename
            if candidate.is_file():
                found_path = candidate
                break

        assert found_path is not None, f"Referenced image '{filename}' was not found in any image folder."
        # Verify file size on disk without reading pixel bytes into memory
        file_size_bytes = found_path.stat().st_size
        assert file_size_bytes > 0, f"Image file '{filename}' exists but is 0 bytes."

        verified_samples.append({
            "filename": filename,
            "path": str(found_path),
            "size_kb": file_size_bytes / 1024,
        })

    assert len(verified_samples) == len(sample_filenames)


# ------------------------------------------------------------------------------
# CLI Runner
# ------------------------------------------------------------------------------


def run_verification():
    """Run verification checks and print friendly diagnostics."""
    print("=" * 70)
    print("  NIH CHESTX-RAY14 DATASET VERIFICATION")
    print("=" * 70)

    dataset_root = get_dataset_root()
    print(f"\n[Check 1/5] Checking Dataset Root Directory...")
    print(f"  - Configured Path : {dataset_root}")
    if dataset_root.is_dir():
        print("  - Status          : Directory exists [OK]")
    else:
        print("  - Status          : FAILED - Directory not found!")
        return

    csv_path = dataset_root / "Data_Entry_2017.csv"
    print(f"\n[Check 2/5] Reading Metadata CSV (Data_Entry_2017.csv)...")
    if not csv_path.is_file():
        print(f"  - Status          : FAILED - {csv_path.name} not found!")
        return

    csv_size_mb = csv_path.stat().st_size / (1024 * 1024)
    print(f"  - File Size       : {csv_size_mb:.2f} MB")
    df_sample = pd.read_csv(csv_path, nrows=10)
    print(f"  - Read Status     : Successfully read sample rows [OK]")

    print(f"\n[Check 3/5] Verifying Required Metadata Columns...")
    columns = [col.strip() for col in df_sample.columns]
    expected_cols = ["Image Index", "Patient ID", "Finding Labels"]
    for col in expected_cols:
        present = col in columns
        print(f"  - Column '{col:<16}' : {'PRESENT [OK]' if present else 'MISSING [FAIL]'}")
        if not present:
            return

    # Display sample metadata row
    first_row = df_sample.iloc[0]
    print(f"  - Sample Record:")
    print(f"      Image Index    : {first_row['Image Index']}")
    print(f"      Patient ID     : {first_row['Patient ID']}")
    print(f"      Finding Labels : {first_row['Finding Labels']}")

    print(f"\n[Check 4/5] Checking 12 Image Directories (images_001 to images_012)...")
    folders_ok = 0
    search_folders = []
    for i in range(1, 13):
        folder_name = f"images_{i:03d}"
        folder_path = dataset_root / folder_name
        resolved = resolve_image_folder(dataset_root, i)
        search_folders.append(resolved)
        exists = folder_path.is_dir()
        if exists:
            folders_ok += 1
            print(f"  - {folder_name:<12} : Found (path: {resolved.name}/) [OK]")
        else:
            print(f"  - {folder_name:<12} : MISSING [FAIL]")

    print(f"  - Folder Summary  : {folders_ok}/12 folders verified [OK]")
    if folders_ok != 12:
        return

    print(f"\n[Check 5/5] Verifying Referenced Images on Disk (Lazy / No RAM loading)...")
    sample_filenames = df_sample["Image Index"].head(5).tolist()
    for filename in sample_filenames:
        found_path = None
        for folder in search_folders:
            candidate = folder / filename
            if candidate.is_file():
                found_path = candidate
                break

        if found_path:
            size_kb = found_path.stat().st_size / 1024
            print(f"  - File '{filename}': Found on disk ({size_kb:.1f} KB, RAM unallocated) [OK]")
        else:
            print(f"  - File '{filename}': NOT FOUND [FAIL]")
            return

    print("\n" + "=" * 70)
    print("VERIFICATION SUMMARY: ALL CHECKS PASSED SUCCESSFULLY")
    print("Dataset is verified and ready for lazy indexing and patient partitioning.")
    print("=" * 70)


if __name__ == "__main__":
    run_verification()

