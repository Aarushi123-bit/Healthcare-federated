"""Automated unit and integration tests for patient-wise indexing and partitioning.

Validates:
1. CSV header identification (Image Index, Patient ID, Finding Labels).
2. Lightweight image indexing across all 12 image directories.
3. Patient isolation: ZERO patient overlap across clients.
4. Image coverage: 100% of images accounted for, no image overlap.
5. Patient containment: Every image of a patient is in that patient's client.
6. Partition reproducibility using random seed.
7. Class distribution calculation and non-IID property reporting.
8. Manifest file generation (lightweight metadata only, no image copies).
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest

from data.partitioning import (
    COL_FINDING_LABELS,
    COL_IMAGE_INDEX,
    COL_PATIENT_ID,
    build_image_index,
    generate_federated_partitions,
    load_config,
    load_nih_metadata,
    partition_patients_non_iid,
    save_partition_manifests,
)


@pytest.fixture(scope="module")
def project_config():
    """Fixture providing project configuration."""
    return load_config()


@pytest.fixture(scope="module")
def raw_dataset_dir(project_config):
    """Fixture providing the raw dataset root directory."""
    return Path(project_config["dataset"]["raw_dir"])


@pytest.fixture(scope="module")
def indexed_data(raw_dataset_dir, project_config):
    """Fixture providing the indexed dataframe and federated partitions."""
    image_index = build_image_index(raw_dataset_dir)
    csv_path = raw_dataset_dir / "Data_Entry_2017.csv"
    df = load_nih_metadata(csv_path, image_index=image_index)

    num_clients = project_config["partitioning"]["num_clients"]
    alpha = project_config["partitioning"]["dirichlet_alpha"]
    seed = project_config["project"]["seed"]

    partitions = partition_patients_non_iid(
        df=df,
        num_clients=num_clients,
        dirichlet_alpha=alpha,
        seed=seed,
    )
    return {"df": df, "partitions": partitions, "image_index": image_index}


def test_csv_headers_identification(raw_dataset_dir):
    """Requirement 1: Verify actual CSV headers are identified."""
    csv_path = raw_dataset_dir / "Data_Entry_2017.csv"
    df = pd.read_csv(csv_path, nrows=5)
    headers = [col.strip() for col in df.columns]

    assert COL_IMAGE_INDEX in headers, f"Missing '{COL_IMAGE_INDEX}' in {headers}"
    assert COL_PATIENT_ID in headers, f"Missing '{COL_PATIENT_ID}' in {headers}"
    assert COL_FINDING_LABELS in headers, f"Missing '{COL_FINDING_LABELS}' in {headers}"


def test_lightweight_image_index(indexed_data):
    """Requirement 2: Verify lightweight index across all 12 folders without pixel memory."""
    image_index = indexed_data["image_index"]

    # All 112,120 images should be indexed
    assert len(image_index) == 112120, f"Expected 112,120 indexed images, got {len(image_index)}"

    # Check structure of entries
    sample_key = next(iter(image_index))
    sample_entry = image_index[sample_key]
    assert "relative_path" in sample_entry
    assert "full_path" in sample_entry
    assert "folder" in sample_entry

    # Verify that it is lightweight strings, not image pixel arrays
    assert isinstance(sample_entry["relative_path"], str)
    assert Path(sample_entry["full_path"]).is_file()


def test_patient_disjointness_no_overlap(indexed_data):
    """Requirements 3 & 5: Ensure zero patient overlap across all five clients."""
    partitions = indexed_data["partitions"]
    total_unique_patients = indexed_data["df"][COL_PATIENT_ID].nunique()

    client_patient_sets = []
    for c_id, pdata in partitions.items():
        assert pdata["patient_count"] > 0, f"{c_id} has 0 patients!"
        client_patient_sets.append(set(pdata["patient_ids"]))

    # Pairwise disjointness verification
    for i in range(len(client_patient_sets)):
        for j in range(i + 1, len(client_patient_sets)):
            overlap = client_patient_sets[i].intersection(client_patient_sets[j])
            assert len(overlap) == 0, (
                f"Patient overlap detected between client {i+1} and {j+1}: {overlap}"
            )

    # Total patient coverage
    all_assigned = set().union(*client_patient_sets)
    assert len(all_assigned) == total_unique_patients, (
        f"Assigned {len(all_assigned)} patients, expected {total_unique_patients}"
    )


def test_image_coverage_and_patient_containment(indexed_data):
    """Requirements 3 & 5: Ensure every image of a patient is in exactly one client."""
    df = indexed_data["df"]
    partitions = indexed_data["partitions"]

    total_images_in_dataset = len(df)
    client_image_sets = []

    for c_id, pdata in partitions.items():
        client_df = pdata["client_df"]
        client_images = set(client_df[COL_IMAGE_INDEX])
        client_image_sets.append(client_images)

        # Verify patient containment: every image's patient ID must belong to this client
        client_pids = set(pdata["patient_ids"])
        for pid in client_df[COL_PATIENT_ID].unique():
            assert pid in client_pids, (
                f"Image with patient {pid} found in {c_id}, but patient is not assigned to this client!"
            )

    # Pairwise image disjointness
    for i in range(len(client_image_sets)):
        for j in range(i + 1, len(client_image_sets)):
            overlap = client_image_sets[i].intersection(client_image_sets[j])
            assert len(overlap) == 0, (
                f"Image overlap detected between client {i+1} and {j+1}: {overlap}"
            )

    # 100% image coverage
    all_assigned_images = set().union(*client_image_sets)
    assert len(all_assigned_images) == total_images_in_dataset, (
        f"Assigned {len(all_assigned_images)} images, expected {total_images_in_dataset}"
    )


def test_reproducible_partitioning(indexed_data, project_config):
    """Requirement 4: Verify identical seeds produce identical splits."""
    df = indexed_data["df"]
    num_clients = project_config["partitioning"]["num_clients"]
    alpha = project_config["partitioning"]["dirichlet_alpha"]
    seed = project_config["project"]["seed"]

    # Re-run partition with identical seed
    repeat_partitions = partition_patients_non_iid(
        df=df, num_clients=num_clients, dirichlet_alpha=alpha, seed=seed
    )

    for c_id in indexed_data["partitions"]:
        orig_pids = indexed_data["partitions"][c_id]["patient_ids"]
        repeat_pids = repeat_partitions[c_id]["patient_ids"]
        assert orig_pids == repeat_pids, f"Patient IDs for {c_id} differed across runs with identical seed!"

    # Run with different seed and verify difference
    diff_partitions = partition_patients_non_iid(
        df=df, num_clients=num_clients, dirichlet_alpha=alpha, seed=seed + 100
    )
    diff_pids = diff_partitions["hospital_client_1"]["patient_ids"]
    assert orig_pids != diff_pids, "Different seeds unexpectedly produced identical patient splits!"


def test_manifest_metadata_saved_no_images(project_config):
    """Requirement 6: Verify manifests and summaries are saved with NO image copies."""
    base_dir = Path(__file__).resolve().parent.parent
    processed_dir = base_dir / project_config["dataset"]["processed_dir"]

    # Generate and save
    partitions, saved_files = generate_federated_partitions()

    assert (processed_dir / "partitions_summary.json").is_file()
    assert (processed_dir / "patient_client_allocation.csv").is_file()

    for i in range(1, 6):
        manifest = processed_dir / f"hospital_client_{i}_manifest.csv"
        assert manifest.is_file(), f"Missing manifest for hospital_client_{i}"
        # Verify it has rows and columns
        m_df = pd.read_csv(manifest, nrows=5)
        assert COL_IMAGE_INDEX in m_df.columns
        assert COL_PATIENT_ID in m_df.columns

    # Verify NO image files (.png, .jpg) were created in processed_dir
    image_files_in_processed = list(processed_dir.rglob("*.png")) + list(processed_dir.rglob("*.jpg"))
    assert len(image_files_in_processed) == 0, (
        f"Found unexpected image copies in processed directory: {image_files_in_processed}"
    )


def test_class_distribution_reporting(indexed_data):
    """Requirements 7 & 8: Verify label distribution is reported and non-empty for all clients."""
    partitions = indexed_data["partitions"]

    for c_id, pdata in partitions.items():
        label_dist = pdata["label_distribution"]
        assert len(label_dist) > 0, f"Label distribution for {c_id} is empty!"
        assert "No Finding" in label_dist, f"'No Finding' missing from {c_id}"

        # Total counts should equal or exceed image count (since findings can be multi-label)
        total_finding_tags = sum(label_dist.values())
        assert total_finding_tags >= pdata["image_count"], (
            f"Total tags {total_finding_tags} less than images {pdata['image_count']} for {c_id}"
        )

