# Experimental Results Summary: Privacy-Preserving Federated Learning

## 1. Multi-Baseline Comparison Matrix

All experiments evaluated the binary classification task (Pneumonia vs. Clean Control on the NIH ChestX-ray14 dataset) under identical patient-level cohorts.

> [!IMPORTANT]
> **Checkpoint Selection Protocol:** In all federated experiments, global checkpoints were selected strictly by highest mean client validation F1 at fixed threshold $0.50$, with ties broken in favor of the earliest round. Secondary metrics (loss or ROC-AUC) were not permitted to break ties. Held-out test evaluation was executed strictly once on the selected checkpoint.

| Metric / Dimension | Centralized Baseline | Vanilla FedAvg Baseline | FedAvg + DP Baseline | FedAvg + DP (Corrected) | **FedAvg + DP ($E=3$)** |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **System Architecture** | Centralized Model | 5 Simulated Clients | 5 Simulated Clients | 5 Simulated Clients | **5 Simulated Clients** |
| **Differential Privacy** | None ($\epsilon = \infty$) | None ($\epsilon = \infty$) | Opacus DP-SGD | Opacus DP-SGD | **Opacus DP-SGD** |
| **Optimizer Management** | Standard Adam | Standard Adam | Stale Adam Across Rnds | Reset Adam on Sync | **Reset Adam on Sync** |
| **Local Epochs ($E$)** | 5 (Global Epochs) | 1 Epoch / Round | 1 Epoch / Round | 1 Epoch / Round | **3 Epochs / Round** |
| **Completed Rounds** | N/A | 5 Rounds | 5 Rounds | 5 Rounds | **2 Rounds (Budget Stop)** |
| **Total Steps / Client** | 15 (Global Steps) | 15 Steps | 15 Steps | 15 Steps | **18 Steps** |
| **Cumulative $\epsilon$ ($\delta=10^{-5}$)** | $\infty$ | $\infty$ | $9.1137$ | $9.1137$ | **$9.9496 \le 10.0$** |
| **Selected Checkpoint Round** | Epoch 2 | Round 3 | Round 3 (Loss tie-breaker) | Round 1 (Earliest tie) | **Round 1 (Earliest tie)** |
| **Selected Checkpoint Val F1** | **0.7586** | **0.6824** | 0.0000 | 0.0000 | **0.0000** |
| **Selected Checkpoint Val ROC-AUC**| **0.8229** | **0.7056** | 0.6333 | 0.6222 | **0.6167** |
| **Latest Round Val ROC-AUC** | 0.8125 (Epoch 5) | 0.7389 (Round 5) | 0.6333 (Round 5) | 0.5722 (Round 5) | **0.7278 (Round 2)** |
| **Held-Out Test Accuracy** | **76.67%** (23/30) | **56.67%** (17/30) | 50.00% (15/30) | 50.00% (15/30) | **50.00%** (15/30) |
| **Held-Out Test Precision**| **0.8333** | **0.5417** | 0.0000 | 0.0000 | **0.0000** |
| **Held-Out Test Recall** | **0.6667** | **0.8667** | 0.0000 | 0.0000 | **0.0000** |
| **Held-Out Test F1 ($\tau=0.50$)**| **0.7407** | **0.6667** | 0.0000 | 0.0000 | **0.0000** |
| **Held-Out Test ROC-AUC** | **0.8400** | **0.7556** | 0.5022 | 0.4400 | **0.5067** |
| **Held-Out Test BCE Loss** | **0.5518** | **0.6708** | 0.6989 | 0.7001 | **0.6982** |

---

## 2. Held-Out Test Evaluation & Confusion Matrices ($N=30$)

All models were evaluated on the held-out centralized test split of 30 unseen patients (15 Pneumonia, 15 Clean Control) using the fixed classification decision threshold $\tau = 0.50$:

```
Centralized (Epoch 2):            Vanilla FedAvg (Round 3):         All DP Variants (Selected Models):
          Predicted                         Predicted                         Predicted
          Neg    Pos                        Neg    Pos                        Neg    Pos
Act Neg [ 13      2 ]             Act Neg [  4     11 ]             Act Neg [ 15      0 ]
Act Pos [  5     10 ]             Act Pos [  2     13 ]             Act Pos [ 15      0 ]
```

### Clarification on Selected Checkpoint vs. Trajectory:
- In `fedavg_dp_3epoch`, mean client validation ROC-AUC progressed from $0.6167$ in Round 1 to $0.7278$ in Round 2.
- However, because validation F1 at threshold $0.50$ was $0.0000$ in both rounds, the earliest-round tie-breaking protocol selected **Round 1**.
- The one-time held-out test evaluation was performed strictly on the **Round 1 checkpoint**, achieving test accuracy of 50.00% (15/30), F1 = 0.0000, and ROC-AUC = 0.5067. Round 2 was not selected or evaluated on the test set.

---

## 3. Communication Round Progression

Mean client validation metrics across all 5 simulated hospital cohorts (12 validation scans per client, 60 total):

| Experiment | Metric | Round 1 | Round 2 | Round 3 | Round 4 | Round 5 |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **Vanilla FedAvg** | Loss | 0.6896 | 0.6805 | 0.6809 | 0.6617 | 0.6525 |
| | F1 ($\tau=0.5$) | 0.5552 | 0.6121 | **0.6824\*** | 0.6478 | 0.6548 |
| | ROC-AUC | 0.6389 | 0.7000 | **0.7056** | 0.7167 | 0.7389 |
| **FedAvg + DP Baseline ($E=1$)** | Loss | 0.6970 | 0.6961 | 0.6958 | 0.6962 | 0.6975 |
| | F1 ($\tau=0.5$) | 0.0000 | 0.0000 | 0.0000\* | 0.0000 | 0.0000 |
| | ROC-AUC | 0.6222 | 0.6111 | **0.6333** | 0.6278 | 0.6333 |
| **FedAvg + DP Corrected ($E=1$)** | Loss | 0.6970 | 0.6972 | 0.6965 | 0.6969 | 0.7015 |
| | F1 ($\tau=0.5$) | 0.0000\* | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| | ROC-AUC | **0.6222** | 0.6056 | 0.6333 | 0.6056 | 0.5722 |
| **FedAvg + DP 3Epoch ($E=3$)** | Loss | 0.6957 | 0.6946 | — | — | — |
| | F1 ($\tau=0.5$) | 0.0000\* | 0.0000 | — | — | — |
| | ROC-AUC | **0.6167** | **0.7278** | — *(Budget Stop)*| — | — |

*\*Indicates the round selected as the global model checkpoint under each experiment's selection rule.*

---

## 4. Analysis of Classification Performance and Threshold Effects

1. **Observed Classification Behavior**:
   - Across all three DP experiments, every sample on both the client validation sets and the held-out test set received an estimated probability below 0.50. Under the fixed decision rule $\hat{y} = \mathbb{I}(p \ge 0.50)$, all predictions were assigned to the negative class ($y=0$).
   - This resulted in 100% negative predictions, yielding F1 = 0.0000 and accuracy = 50.00% (matching the negative class proportion on the balanced 15/15 test set).
2. **Distinction Between Ranking and Hard Classification**:
   - Validation ROC-AUC values ranged from 0.6167 to 0.7278, indicating that the network outputs higher relative probabilities for positive cases than negative cases.
   - However, because the predicted probabilities did not cross the default threshold of 0.50, threshold-dependent metrics collapsed to zero.
   - While post-hoc threshold adjustment on validation data (as explored in the diagnostic study) showed that alternative cutoffs could produce non-zero F1 on validation splits, threshold tuning was not applied to the held-out test set to maintain evaluation protocol integrity.
3. **Schedule & Step Non-Equivalence**:
   - The 1-epoch and 3-epoch experiments operated under different communication and optimization schedules:
     - 1-epoch runs executed 5 rounds with 3 steps per round (15 total steps per client).
     - 3-epoch run executed 2 rounds with 9 steps per round (18 total steps per client).
   - These configurations should not be viewed as perfectly matched comparisons of communication efficiency, but rather as two different trade-offs under a cumulative privacy bound of $\epsilon \le 10.0$.

---

## 5. Construction of the Evaluation Cohort

The test cohort consists of 30 chest radiographs (15 Pneumonia, 15 Clean Controls) subsampled from the NIH ChestX-ray14 dataset under strict patient-level isolation:
- No patient in the test set appears in any of the five hospital client cohorts (training or validation).
- Clean controls were restricted to patients who had "No Finding" and no record of pneumonia in any image across the entire NIH dataset.
- The test cohort was set aside before client cohort partitioning and evaluated strictly once per completed experiment.
