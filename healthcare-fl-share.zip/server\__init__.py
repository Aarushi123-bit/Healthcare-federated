"""Federated server and strategy module."""

from server.federated_server import FederatedServer

__all__ = ["FederatedServer"]
