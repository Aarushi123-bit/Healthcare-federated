"""Data package for clinical dataset loading, indexing, and federated partitioning."""

