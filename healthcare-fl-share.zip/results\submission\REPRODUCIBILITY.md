# Reproducibility Guide & Cryptographic Provenance

This guide provides instructions and reference hashes to independently audit, test, and inspect all experimental results reported in the `healthcare-fl` project.

---

## 1. Environment & Working Directory

- **Project Root Directory:** `healthcare-fl` (e.g., `C:\Users\Vaishnavi Sinha\OneDrive\Desktop\SRM\Project\healthcare-fl`)
- **Python Environment:** Use the existing provisioned virtual environment at `healthcare-fl\.venv`
- **Activation Command (PowerShell):**
  ```powershell
  cd "C:\Users\Vaishnavi Sinha\OneDrive\Desktop\SRM\Project\healthcare-fl"
  .\.venv\Scripts\Activate.ps1
  ```
- **Key Installed Packages:**
  - `torch`: 2.5.1
  - `opacus`: 1.4.1
  - `flwr`: 1.15.2
  - `scikit-learn`: 1.6.1
  - `pandas`: 2.2.3
  - `numpy`: 1.26.4
  - `matplotlib`: 3.11.2
  - `pytest`: 9.1.1

> [!NOTE]
> The environment is already fully provisioned. It is not necessary to recreate the virtual environment or reinstall dependencies unless migrating to a new machine.

---

## 2. Non-Destructive Verification Commands

These commands verify code correctness, cryptographic integrity, and visualization outputs **without modifying existing results or accessing the held-out test set**:

### Command A: Run Core Test Suite (26 Tests, 0 Failures, Zero Test Set Access)
```powershell
.\.venv\Scripts\pytest.exe tests\test_fedavg_dp_3epoch.py tests\test_partitioning.py tests\test_cnn_data_loading.py tests\test_fedavg.py -v
```
*Expected Result:* `26 passed, 12 warnings in ~35-55s`. Zero test set access.

### Command B: Cryptographic Verification of All 54 Master Artifacts
```powershell
.\.venv\Scripts\python.exe -c "
import hashlib, json; from pathlib import Path
b1 = json.loads(Path('results/baseline_integrity_hashes.json').read_text())
b2 = json.loads(Path('results/fedavg_dp_corrected_integrity_hashes.json').read_text())
b3 = json.loads(Path('results/fedavg_dp_3epoch_integrity_hashes.json').read_text())
all_54 = {**b1, **{f'fedavg_dp_baseline/{k}': v for k, v in b2.items() if 'corrected' not in k}, **{f'fedavg_dp_corrected/{k}': v for k, v in b2.items()}, **{f'fedavg_dp_3epoch/{k}': v for k, v in b3.items()}}
all_54['fedavg_dp_baseline/fedavg_dp_global_model.pt'] = 'e5de6bd5684ed4652624efde55921370f2dece35be04bbcb8f29beeddb5ad759'
all_54['fedavg_dp_baseline/fedavg_dp_training_history.json'] = '2ee7871355a9e987877b0a1d38c4f91722d88b71eff151659a6c4e99e953b2b9'
mismatches = [f for f, h in all_54.items() if hashlib.sha256(Path('results/' + f).read_bytes()).hexdigest() != h]
print('Verification Result:', 'ALL 54 ARTIFACTS VERIFIED IDENTICAL' if not mismatches else f'Mismatches: {mismatches}')
"
```
*Expected Result:* `Verification Result: ALL 54 ARTIFACTS VERIFIED IDENTICAL`.

### Command C: Re-Generate Submission Figures from Saved History
```powershell
.\.venv\Scripts\python.exe "C:\Users\Vaishnavi Sinha\.gemini\antigravity\brain\f41af908-3db4-4858-a43c-0b56480cf353\scratch\generate_submission_plots.py"
```
*Expected Result:* Re-generates the four publication PNG figures in `results/submission/plots/` using actual recorded values from saved JSON histories.

---

## 3. Training Execution Reference (Archival Reference Only)

> [!CAUTION]
> The following commands execute training pipelines and overwrite existing outputs in their respective results directories. They are provided for completeness and **must not be executed** during normal auditing or verification:
> - Centralized Baseline: `.\.venv\Scripts\python.exe experiments\centralized_baseline.py`
> - Vanilla FedAvg: `.\.venv\Scripts\python.exe experiments\fedavg_baseline.py`
> - FedAvg + DP Corrected: `.\.venv\Scripts\python.exe experiments\fedavg_dp_corrected.py`
> - FedAvg + DP 3Epoch: `.\.venv\Scripts\python.exe experiments\fedavg_dp_3epoch.py`

---

## 4. Master Cryptographic Hash Registry (All 54 Artifacts)

### A. Centralized Baseline (6 artifacts)
- `centralized_baseline/centralized_cnn_checkpoint.pt`: `05c0f24bfee8b0cacf69ed701800d0cefd8c95914eeab554f6abb2665bd1efba`
- `centralized_baseline/centralized_training_history.json`: `4b9a0c60540f416b5be96c72e5310f25427e680d9345418abd1f68e318ff330f`
- `centralized_baseline/task-190_recovered_baseline_record.json`: `9082eba8c90289aa01189593fde1fb04262293beccae267a134b6ca9c95b6621`
- `centralized_baseline/test_split.csv`: `bebf37a2376bd6293e806fdfcfa210fbbe4b146919a29eadb4d2175f9a805504`
- `centralized_baseline/train_split.csv`: `1e2ab3a1ca367095810799af9e74f130778e46ac0da4547dbf1c6229ad1124a9`
- `centralized_baseline/val_split.csv`: `bd18c6704b9f40a0ba3585c4d6c88127dbfd56f4e6eed9f3231d72b8c80edb45`

### B. Vanilla FedAvg Baseline (12 artifacts)
- `fedavg_baseline/fedavg_global_model.pt`: `d2c9dd56f907fd48b0ce36bd6b24b3ac6066c0b9b803c9e7970b75194e11cf84`
- `fedavg_baseline/fedavg_training_history.json`: `497fe39d70bd0539fa733d4b1b28860542bb3e2e3ca7281cb4b795788ea8d9c7`
- 10 Client CSVs (Matches master manifest hashes below)

### C. FedAvg + DP Baseline (Original) (12 artifacts)
- `fedavg_dp_baseline/fedavg_dp_global_model.pt`: `e5de6bd5684ed4652624efde55921370f2dece35be04bbcb8f29beeddb5ad759`
- `fedavg_dp_baseline/fedavg_dp_training_history.json`: `2ee7871355a9e987877b0a1d38c4f91722d88b71eff151659a6c4e99e953b2b9`
- 10 Client CSVs (Matches master manifest hashes below)

### D. FedAvg + DP Baseline (Corrected) (12 artifacts)
- `fedavg_dp_corrected/fedavg_dp_corrected_global_model.pt`: `c700c5dbd4feaf81652e3b82ff2df09ccc115fb35c7de5dd539229248ca262e8`
- `fedavg_dp_corrected/fedavg_dp_corrected_training_history.json`: `8083fa377f87e239f8794b74cda2e4b26035c4dd0b047caced91eee5973700e6`
- 10 Client CSVs (Matches master manifest hashes below)

### E. FedAvg + DP (3 Local Epochs) (12 artifacts)
- `fedavg_dp_3epoch/fedavg_dp_3epoch_global_model.pt`: `8843ae6cab0ae5bfd5bffe5f915bbf00c3726fa0ccc2bad6c5718d8cc64c3cf9`
- `fedavg_dp_3epoch/fedavg_dp_3epoch_training_history.json`: `04a20c4fce77ae4d413252865ffc726d82c60ff5a127fb8da5a7d61045632e91`
- 10 Client CSVs (Matches master manifest hashes below)

### F. Deterministic Client Cohort Manifests (Identical across all 4 federated experiments)
- `client_1_train.csv`: `e78f586abf9e3a6326d868dc689fa1684add97d81ab72eb3684dfae930661dc3`
- `client_1_val.csv`: `50bf9fda4c5ce960796bacdcb265a97197d074e31849c6ff17cbf5d270aca7c9`
- `client_2_train.csv`: `2266fe42044b671d5c7fc8c962ad05a01200f206aac87490b61fedc1b26b9703`
- `client_2_val.csv`: `2775b2531a6d1d65bf7f2b43d3dc072301887abe9824c85594e0207879a89e0c`
- `client_3_train.csv`: `df78c7d6fbb062ea26576f9e91f64d1578d87a1815b04649a5ff7505ccbba357`
- `client_3_val.csv`: `ef10408d108400e9fe9aab4548b8033d6eb1e95516db0eb2afec586fa69511b8`
- `client_4_train.csv`: `360a053fe796eaf48750634d1003c186a97a66ee54ba297b4eb9d5f628c7b80c`
- `client_4_val.csv`: `225e869f04efbb4dd0ad060052b5087f297cde0280d68aa84966b1c848449f22`
- `client_5_train.csv`: `33d32337cf66d6f10462e00d5e116db261b28f67604c4442328ae9886efe63a5`
- `client_5_val.csv`: `ebc5c0309da494972733a97eb1ff21c9742607345ceb1b7586f26eec1bedb246`
