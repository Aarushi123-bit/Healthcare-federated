"""Hospital Client implementation with Opacus Differential Privacy (DP-SGD).

Subclasses Flower's NumPyClient. Implements local patient-level DP-SGD
with per-sample gradient clipping, calibrated Gaussian noise injection,
Poisson subsampling, and cumulative PRV privacy accounting across FL rounds.
"""

from collections import OrderedDict
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from flwr.client import NumPyClient
from opacus import PrivacyEngine


class HospitalDPClient(NumPyClient):
    """Flower NumPyClient simulating a hospital node training with Opacus DP-SGD."""

    def __init__(
        self,
        client_id: str,
        train_loader: DataLoader,
        val_loader: DataLoader,
        model: nn.Module,
        device: torch.device,
        noise_multiplier: float = 1.0,
        max_grad_norm: float = 1.0,
        learning_rate: float = 1e-3,
        weight_decay: float = 1e-4,
        target_delta: float = 1e-5,
        reset_optimizer_on_set_params: bool = False,
    ):
        self.client_id = client_id
        self.raw_train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.noise_multiplier = noise_multiplier
        self.max_grad_norm = max_grad_norm
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.target_delta = target_delta
        self.reset_optimizer_on_set_params = reset_optimizer_on_set_params
        self.criterion = nn.BCEWithLogitsLoss()

        # Initialize local base optimizer
        self.base_optimizer = torch.optim.Adam(
            model.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )

        # Initialize Opacus PrivacyEngine with supported Poisson sampling
        self.privacy_engine = PrivacyEngine()
        self.dp_model, self.dp_optimizer, self.dp_loader = self.privacy_engine.make_private(
            module=model,
            optimizer=self.base_optimizer,
            data_loader=self.raw_train_loader,
            noise_multiplier=self.noise_multiplier,
            max_grad_norm=self.max_grad_norm,
            poisson_sampling=True,
        )

        # Sample rate under Poisson subsampling: q = batch_size / dataset_size
        self.sample_rate = float(self.dp_loader.sample_rate)

    def reset_optimizer_state(self) -> None:
        """Clear local Adam momentum and variance buffers without affecting PrivacyEngine."""
        self.dp_optimizer.state.clear()

    def get_parameters(self, config: Optional[Dict[str, Any]] = None) -> List[np.ndarray]:
        """Extract local model weights as a list of NumPy ndarrays."""
        return [val.cpu().numpy() for _, val in self.dp_model.state_dict().items()]

    def set_parameters(self, parameters: List[np.ndarray]) -> None:
        """Update local model weights from a list of NumPy ndarrays.
        
        If reset_optimizer_on_set_params is enabled, clears Adam's first- and second-
        moment buffers to eliminate stale momentum across rounds, while preserving
        the client's Opacus PrivacyEngine and cumulative privacy accountant.
        """
        params_dict = zip(self.dp_model.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.as_tensor(v) for k, v in params_dict})
        self.dp_model.load_state_dict(state_dict, strict=True)
        if self.reset_optimizer_on_set_params:
            self.reset_optimizer_state()

    def fit(
        self,
        parameters: List[np.ndarray],
        config: Dict[str, Any],
    ) -> Tuple[List[np.ndarray], int, Dict[str, Any]]:
        """Perform local DP-SGD training on hospital client data for local_epochs.

        Handles Poisson-subsampled batches safely. In the event of an empty batch
        (|B| = 0), a zero loss backward pass is executed to trigger hooks without NaN,
        adding pure Gaussian noise and updating the privacy accountant correctly.
        """
        self.set_parameters(parameters)
        local_epochs = int(config.get("local_epochs", 1))

        self.dp_model.train()
        total_loss = 0.0
        total_samples = 0
        observed_batch_sizes = []
        steps_executed = 0

        for epoch in range(local_epochs):
            epoch_loss = 0.0
            for batch in self.dp_loader:
                batch_imgs = batch[0]
                batch_lbls = batch[1]
                batch_size = batch_imgs.size(0)
                observed_batch_sizes.append(batch_size)
                self.dp_optimizer.zero_grad()

                if batch_size == 0:
                    # Handle empty Poisson batch: backpropagate 0 to trigger hooks, add noise, step accountant
                    batch_imgs = batch_imgs.to(self.device)
                    out = self.dp_model(batch_imgs)
                    dummy_loss = out.sum()  # Evaluates to 0.0 without NaN
                    dummy_loss.backward()
                    self.dp_optimizer.step()
                    steps_executed += 1
                    continue

                batch_imgs = batch_imgs.to(self.device)
                batch_lbls = batch_lbls.to(self.device)

                logits = self.dp_model(batch_imgs)
                loss = self.criterion(logits, batch_lbls)
                loss.backward()
                self.dp_optimizer.step()

                epoch_loss += loss.item() * batch_size
                total_samples += batch_size
                steps_executed += 1

            total_loss += epoch_loss

        avg_loss = total_loss / max(total_samples, 1)
        current_epsilon = float(self.privacy_engine.get_epsilon(delta=self.target_delta))

        metrics = {
            "train_loss": float(avg_loss),
            "client_id": self.client_id,
            "epsilon": current_epsilon,
            "delta": self.target_delta,
            "sample_rate": self.sample_rate,
            "steps_in_round": steps_executed,
            "total_steps": sum(entry[2] for entry in self.privacy_engine.accountant.history) if self.privacy_engine.accountant.history else 0,
            "observed_batch_sizes": observed_batch_sizes,
        }

        return (
            self.get_parameters(),
            len(self.raw_train_loader.dataset),
            metrics,
        )

    def evaluate(
        self,
        parameters: List[np.ndarray],
        config: Dict[str, Any],
    ) -> Tuple[float, int, Dict[str, Any]]:
        """Evaluate local validation set using clinical metrics."""
        from experiments.centralized_baseline import evaluate_model

        self.set_parameters(parameters)
        metrics = evaluate_model(
            model=self.dp_model,
            loader=self.val_loader,
            criterion=self.criterion,
            device=self.device,
        )
        metrics["client_id"] = self.client_id
        metrics["epsilon"] = float(self.privacy_engine.get_epsilon(delta=self.target_delta))
        metrics["delta"] = self.target_delta
        return float(metrics["loss"]), len(self.val_loader.dataset), metrics
