"""FedAvg baseline experiment with Differential Privacy (Opacus DP-SGD).

Simulates 5 non-IID hospital clients using real NIH ChestX-ray14 radiographs.
Guarantees:
1. Patient-Level Differential Privacy: One representative scan per unique patient,
   ensuring sample-level per-sample gradient clipping equals patient-level clipping.
2. Mathematically Valid Accounting: Opacus Poisson sampling (poisson_sampling=True)
   paired with PRVAccountant (Privacy Random Variable Accountant).
3. Cumulative Accounting: Privacy budget monotonically accumulated across all FL rounds.
4. Baseline Preservation: Does not overwrite centralized or vanilla FedAvg baselines.
5. Strict Test Isolation: Centralized held-out test set evaluated strictly once after training.
"""

from pathlib import Path
import sys
from typing import Any, Dict, List, Optional, Tuple
import json
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from clients.hospital_dp_client import HospitalDPClient
from data.partitioning import build_image_index
from experiments.centralized_baseline import (
    BinaryChestXrayDataset,
    evaluate_model,
    load_config,
)
from experiments.fedavg_baseline import build_client_cohorts
from models.cnn import SmallChestXrayCNN
from server.federated_server import FederatedServer


def run_fedavg_dp_experiment(
    num_rounds: int = 5,
    local_epochs: int = 1,
    samples_per_client: int = 60,
    batch_size: int = 16,
    noise_multiplier: float = 1.0,
    max_grad_norm: float = 1.0,
    learning_rate: float = 1e-3,
    target_delta: float = 1e-5,
    image_size: Tuple[int, int] = (224, 224),
    seed: int = 42,
    config_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Execute end-to-end FedAvg + DP-SGD baseline experiment across 5 hospital clients."""
    # 1. Deterministic seeding
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 2. Paths and configuration
    cfg = load_config(config_path)
    raw_dir = Path(cfg["dataset"]["raw_dir"])
    proc_dir = BASE_DIR / cfg["dataset"]["processed_dir"]

    if output_dir is None:
        output_dir = BASE_DIR / "results" / "fedavg_dp_baseline"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 3. Load centralized test split (strictly preserved and held out)
    central_test_path = BASE_DIR / "results" / "centralized_baseline" / "test_split.csv"
    if not central_test_path.exists():
        raise FileNotFoundError(f"Centralized test split not found at: {central_test_path}")

    test_df = pd.read_csv(central_test_path)
    test_patient_ids = set(test_df["Patient ID"])
    test_ds = BinaryChestXrayDataset(test_df, raw_dir, image_size=image_size)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    # 4. Build image index for fast lookup
    image_index = build_image_index(raw_dir)

    # 5. Build patient-isolated client cohorts
    client_cohorts = build_client_cohorts(
        manifests_dir=proc_dir,
        image_index=image_index,
        test_patient_ids=test_patient_ids,
        output_dir=output_dir,
        samples_per_client=samples_per_client,
        val_ratio=0.2,
        seed=seed,
    )

    # 6. Initialize HospitalDPClient instances with Opacus DP-SGD
    clients: List[HospitalDPClient] = []
    for c in range(1, 6):
        client_id = f"hospital_{c}"
        train_df = client_cohorts[client_id]["train"]
        val_df = client_cohorts[client_id]["val"]

        train_ds = BinaryChestXrayDataset(train_df, raw_dir, image_size=image_size)
        val_ds = BinaryChestXrayDataset(val_df, raw_dir, image_size=image_size)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

        client_model = SmallChestXrayCNN(
            in_channels=1,
            num_classes=1,
            num_groups=4,
            dropout=0.1,
        ).to(device)

        client = HospitalDPClient(
            client_id=client_id,
            train_loader=train_loader,
            val_loader=val_loader,
            model=client_model,
            device=device,
            noise_multiplier=noise_multiplier,
            max_grad_norm=max_grad_norm,
            learning_rate=learning_rate,
            target_delta=target_delta,
        )
        clients.append(client)

    # 7. Initialize Global Server Model and Orchestrator
    global_model = SmallChestXrayCNN(
        in_channels=1,
        num_classes=1,
        num_groups=4,
        dropout=0.1,
    ).to(device)

    server = FederatedServer(
        model=global_model,
        clients=clients,
        test_loader=test_loader,
        device=device,
        output_dir=output_dir,
    )

    # 8. Run Federated Training
    base_history = server.train(
        num_rounds=num_rounds,
        local_epochs=local_epochs,
    )

    # 9. Extract final privacy accounting details from clients
    final_client_privacy = {}
    for client in clients:
        eps = float(client.privacy_engine.get_epsilon(delta=target_delta))
        final_client_privacy[client.client_id] = {
            "epsilon": eps,
            "delta": target_delta,
            "sample_rate": client.sample_rate,
            "total_steps": sum(entry[2] for entry in client.privacy_engine.accountant.history) if client.privacy_engine.accountant.history else 0,
        }

    # Rename checkpoint and history file for DP baseline clarity
    dp_checkpoint_path = output_dir / "fedavg_dp_global_model.pt"
    default_checkpoint_path = output_dir / "fedavg_global_model.pt"
    if default_checkpoint_path.exists():
        default_checkpoint_path.replace(dp_checkpoint_path)

    dp_history = {
        "experiment": "fedavg_dp_baseline",
        "privacy_mechanism": "opacus_dp_sgd",
        "privacy_unit": "patient_level_within_client",
        "accountant_type": "PRVAccountant",
        "poisson_sampling": True,
        "noise_multiplier": noise_multiplier,
        "max_grad_norm": max_grad_norm,
        "target_delta": target_delta,
        "num_rounds": num_rounds,
        "local_epochs": local_epochs,
        "num_clients": len(clients),
        "best_round": base_history["best_round"],
        "best_val_f1": base_history["best_val_f1"],
        "best_val_loss": base_history["best_val_loss"],
        "training_duration_seconds": base_history["training_duration_seconds"],
        "rounds": base_history["rounds"],
        "held_out_test_metrics": base_history["held_out_test_metrics"],
        "final_client_privacy": final_client_privacy,
        "checkpoint_path": str(dp_checkpoint_path.resolve()),
    }

    dp_history_path = output_dir / "fedavg_dp_training_history.json"
    with open(dp_history_path, "w", encoding="utf-8") as f:
        json.dump(dp_history, f, indent=2)

    # Clean up default history if present
    default_history_path = output_dir / "fedavg_training_history.json"
    if default_history_path.exists():
        default_history_path.unlink()

    return dp_history


if __name__ == "__main__":
    run_fedavg_dp_experiment()

