"""Automated unit and integration tests for the centralized CNN baseline.

Verifies:
1. Label mapping: Pneumonia maps strictly to 1.0, No Finding maps to 0.0.
2. Control purity: Normal controls are drawn exclusively from patients without pneumonia.
3. Split leakage: Strict zero patient ID and zero image overlap across Train/Val/Test.
4. Reproducibility: Identical seeds produce identical cohorts and splits.
5. Saved artifacts: Valid model checkpoint (.pt) and JSON history log.
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
import torch

from data.partitioning import build_image_index, load_nih_metadata
from experiments.centralized_baseline import (
    BASE_DIR,
    build_binary_cohort,
    load_config,
    run_centralized_training,
    split_cohort_patient_wise,
)


@pytest.fixture(scope="module")
def project_setup():
    """Load config and metadata once for testing."""
    cfg = load_config()
    raw_dir = Path(cfg["dataset"]["raw_dir"])
    image_index = build_image_index(raw_dir)
    csv_path = raw_dir / "Data_Entry_2017.csv"
    df = load_nih_metadata(csv_path, image_index=image_index)
    return {"cfg": cfg, "raw_dir": raw_dir, "image_index": image_index, "df": df}


def test_binary_label_mapping_and_control_purity(project_setup):
    """Requirement 1 & 7: Verify label mapping and clean control selection."""
    df = project_setup["df"]
    raw_dir = project_setup["raw_dir"]
    image_index = project_setup["image_index"]

    cohort = build_binary_cohort(
        df=df,
        image_index=image_index,
        raw_dir=raw_dir,
        n_samples_per_class=30,
        seed=42,
    )

    # 1. Check labels are strictly 0.0 or 1.0
    unique_labels = set(cohort["label"].unique())
    assert unique_labels == {0.0, 1.0}, f"Expected labels {{0.0, 1.0}}, got {unique_labels}"

    # 2. Check Pneumonia rows
    pneu_rows = cohort[cohort["label"] == 1.0]
    for _, row in pneu_rows.iterrows():
        findings = [f.strip() for f in str(row["Finding Labels"]).split("|")]
        assert "Pneumonia" in findings, f"Pneumonia missing from positive row: {row['Finding Labels']}"
        assert row["class_name"] == "Pneumonia"

    # 3. Check No Finding rows and control purity
    norm_rows = cohort[cohort["label"] == 0.0]
    all_pneu_patients = set(
        df[df["Finding Labels"].str.contains(r"\bPneumonia\b", na=False)]["Patient ID"]
    )
    for _, row in norm_rows.iterrows():
        assert row["Finding Labels"] == "No Finding", f"Unexpected label in control row: {row['Finding Labels']}"
        assert row["class_name"] == "No Finding"
        # Control purity: patient must NEVER have had pneumonia
        assert row["Patient ID"] not in all_pneu_patients, (
            f"Control patient {row['Patient ID']} has a pneumonia history elsewhere in dataset!"
        )


def test_patient_wise_split_leakage(project_setup):
    """Requirements 2 & 7: Verify zero patient and image overlap between Train, Val, and Test."""
    df = project_setup["df"]
    raw_dir = project_setup["raw_dir"]
    image_index = project_setup["image_index"]

    cohort = build_binary_cohort(
        df=df,
        image_index=image_index,
        raw_dir=raw_dir,
        n_samples_per_class=50,
        seed=42,
    )

    train_df, val_df, test_df = split_cohort_patient_wise(
        cohort_df=cohort,
        test_ratio=0.15,
        val_ratio=0.15,
        seed=42,
    )

    # Patient ID Sets
    train_pts = set(train_df["Patient ID"])
    val_pts = set(val_df["Patient ID"])
    test_pts = set(test_df["Patient ID"])

    # Strict Patient Isolation Invariants
    assert len(train_pts.intersection(val_pts)) == 0, "Patient leakage between Train and Val!"
    assert len(train_pts.intersection(test_pts)) == 0, "Patient leakage between Train and Test!"
    assert len(val_pts.intersection(test_pts)) == 0, "Patient leakage between Val and Test!"

    # Strict Image Isolation Invariants
    train_imgs = set(train_df["Image Index"])
    val_imgs = set(val_df["Image Index"])
    test_imgs = set(test_df["Image Index"])

    assert len(train_imgs.intersection(val_imgs)) == 0, "Image leakage between Train and Val!"
    assert len(train_imgs.intersection(test_imgs)) == 0, "Image leakage between Train and Test!"
    assert len(val_imgs.intersection(test_imgs)) == 0, "Image leakage between Val and Test!"

    # Total accounting
    total_split_images = len(train_df) + len(val_df) + len(test_df)
    assert total_split_images == len(cohort), "Image count mismatch in splits"


def test_cohort_and_split_reproducibility(project_setup):
    """Requirement 6: Verify identical random seeds produce identical cohorts and splits."""
    df = project_setup["df"]
    raw_dir = project_setup["raw_dir"]
    image_index = project_setup["image_index"]

    cohort_1 = build_binary_cohort(df, image_index, raw_dir, n_samples_per_class=20, seed=42)
    cohort_2 = build_binary_cohort(df, image_index, raw_dir, n_samples_per_class=20, seed=42)

    pd.testing.assert_frame_equal(cohort_1, cohort_2)

    t1, v1, te1 = split_cohort_patient_wise(cohort_1, seed=42)
    t2, v2, te2 = split_cohort_patient_wise(cohort_2, seed=42)

    pd.testing.assert_frame_equal(t1, t2)
    pd.testing.assert_frame_equal(v1, v2)
    pd.testing.assert_frame_equal(te1, te2)


def test_fast_training_artifacts_and_metrics_ranges(tmp_path):
    """Requirements 4, 5, 6: Run 1-epoch quick verification writing strictly to tmp_path."""
    test_output_dir = tmp_path / "test_artifacts"
    results = run_centralized_training(
        n_samples_per_class=20,
        epochs=1,
        batch_size=16,
        learning_rate=1e-3,
        seed=42,
        output_dir=test_output_dir,
    )

    # 1. Verify artifacts exist inside the isolated test directory
    checkpoint_path = Path(results["artifacts"]["model_checkpoint"])
    history_path = Path(results["artifacts"]["history_log"])
    train_manifest = Path(results["artifacts"]["train_split_manifest"])
    val_manifest = Path(results["artifacts"]["val_split_manifest"])
    test_manifest = Path(results["artifacts"]["test_split_manifest"])

    assert checkpoint_path.is_file(), f"Missing checkpoint: {checkpoint_path}"
    assert history_path.is_file(), f"Missing history log: {history_path}"
    assert train_manifest.is_file(), f"Missing train manifest: {train_manifest}"
    assert val_manifest.is_file(), f"Missing val manifest: {val_manifest}"
    assert test_manifest.is_file(), f"Missing test manifest: {test_manifest}"

    # Confirm all artifacts are inside tmp_path (NOT in production results/)
    for path_item in [checkpoint_path, history_path, train_manifest, val_manifest, test_manifest]:
        assert str(test_output_dir) in str(path_item), f"Artifact leaked outside test directory: {path_item}"

    # 2. Verify split manifests have zero patient overlap
    df_train = pd.read_csv(train_manifest)
    df_val = pd.read_csv(val_manifest)
    df_test = pd.read_csv(test_manifest)

    p_tr = set(df_train["Patient ID"])
    p_va = set(df_val["Patient ID"])
    p_te = set(df_test["Patient ID"])

    assert len(p_tr.intersection(p_va)) == 0, "Patient leakage in saved train/val manifests!"
    assert len(p_tr.intersection(p_te)) == 0, "Patient leakage in saved train/test manifests!"
    assert len(p_va.intersection(p_te)) == 0, "Patient leakage in saved val/test manifests!"

    # 3. Verify checkpoint loads into PyTorch
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    assert "model_state_dict" in ckpt
    assert "epoch" in ckpt

    # 4. Verify metrics range sanity
    tm = results["held_out_test_metrics"]
    assert 0.0 <= tm["accuracy"] <= 1.0
    assert 0.0 <= tm["precision"] <= 1.0
    assert 0.0 <= tm["recall"] <= 1.0
    assert 0.0 <= tm["f1_score"] <= 1.0
    assert len(tm["confusion_matrix"]) == 2
    assert len(tm["confusion_matrix"][0]) == 2


def test_production_artifacts_protection(tmp_path):
    """Requirement 6: Verify automated test runs never overwrite production results directory."""
    prod_dir = BASE_DIR / "results" / "centralized_baseline"
    prod_dir.mkdir(parents=True, exist_ok=True)

    # Snapshot existing files in production directory before test
    files_before = set(prod_dir.rglob("*"))
    mtimes_before = {f: f.stat().st_mtime for f in files_before if f.is_file()}

    # Run quick test specifying isolated tmp_path
    isolated_dir = tmp_path / "isolated_run"
    results = run_centralized_training(
        n_samples_per_class=10,
        epochs=1,
        batch_size=16,
        learning_rate=1e-3,
        seed=42,
        output_dir=isolated_dir,
    )

    # Verify artifacts were written to isolated_dir
    assert (isolated_dir / "centralized_cnn_checkpoint.pt").is_file()
    assert (isolated_dir / "centralized_training_history.json").is_file()
    assert (isolated_dir / "train_split.csv").is_file()

    # Verify production directory was NOT touched or modified by this run
    files_after = set(prod_dir.rglob("*"))
    assert files_before == files_after, "Production directory contents unexpectedly changed during test!"
    for f in files_before:
        if f.is_file():
            assert f.stat().st_mtime == mtimes_before[f], f"Production file was modified during test: {f}"


