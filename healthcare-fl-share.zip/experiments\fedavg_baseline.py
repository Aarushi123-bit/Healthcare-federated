"""FedAvg baseline experiment without Differential Privacy.

Simulates 5 non-IID hospital clients using real NIH ChestX-ray14 radiographs.
Enforces patient-level isolation:
1. All 30 patients from the centralized held-out test split are strictly excluded.
2. Hospital clients have zero patient overlap with each other.
3. Within each client, training and validation patients are mutually disjoint.
4. Model selection is frozen on mean client validation F1-score.
5. Held-out test set is evaluated strictly once after federated training completes.
"""

from pathlib import Path
import sys
from typing import Any, Dict, List, Optional, Set, Tuple
import json
import random
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import yaml

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from clients.hospital_client import HospitalClient
from data.partitioning import build_image_index, load_nih_metadata
from experiments.centralized_baseline import (
    BinaryChestXrayDataset,
    evaluate_model,
    load_config,
)
from models.cnn import SmallChestXrayCNN
from server.federated_server import FederatedServer


def build_client_cohorts(
    manifests_dir: Path,
    image_index: Dict[str, dict],
    test_patient_ids: Set[int],
    output_dir: Path,
    samples_per_client: int = 60,
    val_ratio: float = 0.2,
    seed: int = 42,
) -> Dict[str, Dict[str, pd.DataFrame]]:
    """Construct patient-isolated training and validation cohorts for 5 hospital clients.

    Guarantees:
      - Patients(Client_i) ∩ Patients(Central_Test) = ∅
      - Patients(Client_i) ∩ Patients(Client_j) = ∅  for i != j
      - Patients(Client_i_Train) ∩ Patients(Client_i_Val) = ∅
      - Controls are clean: patients who NEVER had pneumonia in the full dataset.
    """
    manifests_dir = Path(manifests_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load all client manifests to find all pneumonia patients in the entire dataset
    client_manifest_paths = [
        manifests_dir / f"hospital_client_{c}_manifest.csv" for c in range(1, 6)
    ]
    manifest_dfs = [pd.read_csv(p) for p in client_manifest_paths]
    full_df = pd.concat(manifest_dfs, ignore_index=True)

    all_pneu_mask = full_df["Finding Labels"].apply(
        lambda x: "Pneumonia" in [f.strip() for f in str(x).split("|")]
    )
    all_pneu_patients = set(full_df.loc[all_pneu_mask, "Patient ID"])

    client_cohorts = {}
    all_client_train_pts = set()
    all_client_val_pts = set()

    manifest_cols = [
        "Image Index",
        "Patient ID",
        "label",
        "class_name",
        "Finding Labels",
        "relative_path",
    ]

    for c in range(1, 6):
        client_name = f"hospital_{c}"
        m = manifest_dfs[c - 1]

        # Step A: Exclude centralized test patients
        m_filtered = m[~m["Patient ID"].isin(test_patient_ids)].copy()

        # Step B: Identify Pneumonia (y=1.0) - 1 scan per unique patient
        c_pneu_mask = m_filtered["Finding Labels"].apply(
            lambda x: "Pneumonia" in [f.strip() for f in str(x).split("|")]
        )
        c_pneu_df = m_filtered[c_pneu_mask].copy()
        c_pneu_unique = c_pneu_df.groupby("Patient ID").first().reset_index()

        # Step C: Identify Clean Controls (y=0.0) - No Finding and NEVER had pneumonia
        c_norm_mask = (m_filtered["Finding Labels"] == "No Finding") & (
            ~m_filtered["Patient ID"].isin(all_pneu_patients)
        )
        c_norm_df = m_filtered[c_norm_mask].copy()
        c_norm_unique = c_norm_df.groupby("Patient ID").first().reset_index()

        # Step D: Sample balanced cohort
        n_per_class = samples_per_client // 2
        sampled_pneu = c_pneu_unique.sample(
            n=min(n_per_class, len(c_pneu_unique)),
            random_state=seed + c,
        ).copy()
        sampled_norm = c_norm_unique.sample(
            n=min(n_per_class, len(c_norm_unique)),
            random_state=seed + c,
        ).copy()

        sampled_pneu["label"] = 1.0
        sampled_pneu["class_name"] = "Pneumonia"
        sampled_norm["label"] = 0.0
        sampled_norm["class_name"] = "No Finding"

        cohort = pd.concat([sampled_pneu, sampled_norm]).sample(
            frac=1.0, random_state=seed + c
        ).reset_index(drop=True)

        cohort["relative_path"] = cohort["Image Index"].map(
            lambda name: image_index[name]["relative_path"] if name in image_index else None
        )

        # Step E: Patient-wise split into local train and local val
        train_df, val_df = train_test_split(
            cohort,
            test_size=val_ratio,
            stratify=cohort["label"],
            random_state=seed + c,
        )
        train_df = train_df.reset_index(drop=True)
        val_df = val_df.reset_index(drop=True)

        # Verify patient isolation invariants
        p_train = set(train_df["Patient ID"])
        p_val = set(val_df["Patient ID"])
        assert len(p_train.intersection(p_val)) == 0, f"Patient leakage between train & val in {client_name}!"
        assert len(p_train.intersection(test_patient_ids)) == 0, f"Test patient leakage in {client_name} train!"
        assert len(p_val.intersection(test_patient_ids)) == 0, f"Test patient leakage in {client_name} val!"
        assert len(p_train.intersection(all_client_train_pts)) == 0, f"Cross-client leakage for {client_name} train!"
        assert len(p_val.intersection(all_client_val_pts)) == 0, f"Cross-client leakage for {client_name} val!"

        all_client_train_pts.update(p_train)
        all_client_val_pts.update(p_val)

        # Save manifests
        train_df[manifest_cols].to_csv(output_dir / f"client_{c}_train.csv", index=False)
        val_df[manifest_cols].to_csv(output_dir / f"client_{c}_val.csv", index=False)

        client_cohorts[client_name] = {
            "train": train_df,
            "val": val_df,
        }

    return client_cohorts


def run_fedavg_experiment(
    num_rounds: int = 5,
    local_epochs: int = 1,
    samples_per_client: int = 60,
    batch_size: int = 16,
    learning_rate: float = 1e-3,
    image_size: Tuple[int, int] = (224, 224),
    seed: int = 42,
    config_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Execute end-to-end FedAvg baseline experiment across 5 hospital clients."""
    # 1. Deterministic seeding
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 2. Paths and configuration
    cfg = load_config(config_path)
    raw_dir = Path(cfg["dataset"]["raw_dir"])
    proc_dir = BASE_DIR / cfg["dataset"]["processed_dir"]

    if output_dir is None:
        output_dir = BASE_DIR / "results" / "fedavg_baseline"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 3. Load centralized test split (strictly preserved and held out)
    central_test_path = BASE_DIR / "results" / "centralized_baseline" / "test_split.csv"
    if not central_test_path.exists():
        raise FileNotFoundError(f"Centralized test split not found at: {central_test_path}")

    test_df = pd.read_csv(central_test_path)
    test_patient_ids = set(test_df["Patient ID"])
    test_ds = BinaryChestXrayDataset(test_df, raw_dir, image_size=image_size)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    # 4. Build image index for fast lookup
    image_index = build_image_index(raw_dir)

    # 5. Build patient-isolated client cohorts
    client_cohorts = build_client_cohorts(
        manifests_dir=proc_dir,
        image_index=image_index,
        test_patient_ids=test_patient_ids,
        output_dir=output_dir,
        samples_per_client=samples_per_client,
        val_ratio=0.2,
        seed=seed,
    )

    # 6. Initialize HospitalClient instances
    clients: List[HospitalClient] = []
    for c in range(1, 6):
        client_id = f"hospital_{c}"
        train_df = client_cohorts[client_id]["train"]
        val_df = client_cohorts[client_id]["val"]

        train_ds = BinaryChestXrayDataset(train_df, raw_dir, image_size=image_size)
        val_ds = BinaryChestXrayDataset(val_df, raw_dir, image_size=image_size)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

        client_model = SmallChestXrayCNN(
            in_channels=1,
            num_classes=1,
            num_groups=4,
            dropout=0.1,
        ).to(device)

        client = HospitalClient(
            client_id=client_id,
            train_loader=train_loader,
            val_loader=val_loader,
            model=client_model,
            device=device,
            learning_rate=learning_rate,
        )
        clients.append(client)

    # 7. Initialize Global Server Model and Orchestrator
    global_model = SmallChestXrayCNN(
        in_channels=1,
        num_classes=1,
        num_groups=4,
        dropout=0.1,
    ).to(device)

    server = FederatedServer(
        model=global_model,
        clients=clients,
        test_loader=test_loader,
        device=device,
        output_dir=output_dir,
    )

    # 8. Run Federated Training
    history = server.train(
        num_rounds=num_rounds,
        local_epochs=local_epochs,
    )

    return history


if __name__ == "__main__":
    run_fedavg_experiment()
