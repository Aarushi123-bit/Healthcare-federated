"""Patient-wise indexing and non-IID partitioning for NIH ChestX-ray14.

This module splits the clinical dataset across simulated hospital clients
while strictly preserving patient-wise isolation:
- Every image of a given patient is assigned to exactly one hospital client.
- No patient IDs or image filenames overlap across clients.
- Partitioning is non-IID (Dirichlet label skew and quantity disparity)
  and 100% reproducible using the configured seed.
- Only lightweight metadata manifests are saved to disk; images are never copied.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import os
import numpy as np
import pandas as pd
import yaml

# Standard column names from Data_Entry_2017.csv
COL_IMAGE_INDEX = "Image Index"
COL_FINDING_LABELS = "Finding Labels"
COL_PATIENT_ID = "Patient ID"
COL_PATIENT_AGE = "Patient Age"
COL_PATIENT_GENDER = "Patient Gender"
COL_VIEW_POSITION = "View Position"


def load_config(config_path: Optional[Path] = None) -> dict:
    """Load and parse the project's config.yaml configuration file."""
    if config_path is None:
        base_dir = Path(__file__).resolve().parent.parent
        config_path = base_dir / "config.yaml"
        if not config_path.exists():
            config_path = Path("config.yaml").resolve()

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found at: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_image_index(dataset_root: Path) -> Dict[str, Dict[str, str]]:
    """Build a fast, lightweight in-memory lookup map of image filenames to paths.

    Scans folders images_001 through images_012 without loading image pixels into RAM.

    Returns:
        Dict mapping filename (e.g. '00000001_000.png') to metadata dict:
        {'relative_path': '...', 'full_path': '...', 'folder': 'images_001'}
    """
    image_index = {}
    for i in range(1, 13):
        folder_name = f"images_{i:03d}"
        folder_path = dataset_root / folder_name
        # Support archives with nested images/ directory
        img_dir = folder_path / "images" if (folder_path / "images").is_dir() else folder_path

        if not img_dir.is_dir():
            raise FileNotFoundError(f"Expected image directory not found: {img_dir}")

        for entry in os.scandir(img_dir):
            if entry.name.endswith(".png"):
                rel_path = os.path.relpath(entry.path, dataset_root).replace("\\", "/")
                image_index[entry.name] = {
                    "full_path": entry.path,
                    "relative_path": rel_path,
                    "folder": folder_name,
                }

    return image_index


def load_nih_metadata(
    csv_path: Path, image_index: Optional[Dict[str, Dict[str, str]]] = None
) -> pd.DataFrame:
    """Read Data_Entry_2017.csv and validate required headers.

    Identifies:
      - Patient ID: COL_PATIENT_ID ('Patient ID')
      - Image Filename: COL_IMAGE_INDEX ('Image Index')
      - Finding Labels: COL_FINDING_LABELS ('Finding Labels')

    Attaches indexed relative paths without loading image pixels into memory.
    """
    if not csv_path.is_file():
        raise FileNotFoundError(f"Metadata file not found: {csv_path}")

    df = pd.read_csv(csv_path)
    df.columns = [col.strip() for col in df.columns]

    # Validate essential columns exist
    required_cols = [COL_IMAGE_INDEX, COL_PATIENT_ID, COL_FINDING_LABELS]
    for col in required_cols:
        if col not in df.columns:
            raise KeyError(
                f"Required column '{col}' missing from metadata CSV. Found columns: {list(df.columns)}"
            )

    # Attach file paths if index is provided
    if image_index is not None:
        df["relative_path"] = df[COL_IMAGE_INDEX].map(
            lambda name: image_index[name]["relative_path"] if name in image_index else None
        )
        missing_count = df["relative_path"].isna().sum()
        if missing_count > 0:
            raise ValueError(
                f"{missing_count} images referenced in metadata CSV were not found on disk!"
            )

    return df


def compute_patient_primary_labels(df: pd.DataFrame) -> pd.DataFrame:
    """Determine a representative primary clinical finding for each unique patient.

    This enables non-IID Dirichlet partitioning by clinical condition at the
    patient level, preventing patient data leakage across hospital clients.
    """

    def get_first_finding(label_str: str) -> str:
        if pd.isna(label_str) or not str(label_str).strip():
            return "No Finding"
        findings = [f.strip() for f in str(label_str).split("|") if f.strip()]
        # Prioritize positive pathological findings over 'No Finding'
        positives = [f for f in findings if f != "No Finding"]
        return positives[0] if positives else "No Finding"

    # Group by Patient ID and pick the most prominent finding across their scans
    patient_summary = (
        df.groupby(COL_PATIENT_ID)[COL_FINDING_LABELS]
        .apply(lambda series: [get_first_finding(s) for s in series])
        .reset_index()
    )

    def dominant_patient_finding(findings_list: List[str]) -> str:
        positives = [f for f in findings_list if f != "No Finding"]
        if positives:
            # Most common positive pathology for this patient
            vals, counts = np.unique(positives, return_counts=True)
            return vals[np.argmax(counts)]
        return "No Finding"

    patient_summary["primary_label"] = patient_summary[COL_FINDING_LABELS].apply(
        dominant_patient_finding
    )
    return patient_summary[[COL_PATIENT_ID, "primary_label"]]


def partition_patients_non_iid(
    df: pd.DataFrame,
    num_clients: int = 5,
    dirichlet_alpha: float = 0.5,
    seed: int = 42,
    min_samples_per_client: int = 30,
) -> Dict[str, dict]:
    """Partition unique patients across simulated hospital clients using a

    reproducible Dirichlet distribution over primary pathologies.

    Guarantees:
      1. Every patient belongs to EXACTLY one client.
      2. Every image of that patient belongs to the same client.
      3. No patient overlap across clients (empty intersection).
      4. Complete coverage (sum of client patients == total unique patients).
    """
    patient_labels_df = compute_patient_primary_labels(df)
    unique_classes = patient_labels_df["primary_label"].unique()

    rng = np.random.RandomState(seed)
    client_patients: Dict[int, List[int]] = {i: [] for i in range(num_clients)}

    # Distribute patients class-by-class using Dirichlet proportions
    for c in unique_classes:
        subset = patient_labels_df[patient_labels_df["primary_label"] == c]
        patient_ids = subset[COL_PATIENT_ID].values
        # Permute deterministically
        shuffled_ids = rng.permutation(patient_ids)

        # Sample Dirichlet proportions
        proportions = rng.dirichlet(np.repeat(dirichlet_alpha, num_clients))
        counts = (proportions * len(shuffled_ids)).astype(int)

        # Distribute rounding remainder
        remainder = len(shuffled_ids) - counts.sum()
        for rem_idx in range(remainder):
            counts[rem_idx % num_clients] += 1

        splits = np.split(shuffled_ids, np.cumsum(counts)[:-1])
        for client_idx in range(num_clients):
            client_patients[client_idx].extend(splits[client_idx].tolist())

    # Build client partition dictionaries
    partitions = {}
    all_assigned_patients = set()
    all_assigned_images = set()

    for client_idx in range(num_clients):
        c_id = f"hospital_client_{client_idx + 1}"
        c_patients = set(client_patients[client_idx])

        # Verify no overlap with previously assigned clients
        overlap = all_assigned_patients.intersection(c_patients)
        if len(overlap) > 0:
            raise ValueError(f"Patient overlap detected in {c_id}: {overlap}")

        all_assigned_patients.update(c_patients)

        # Filter dataset rows for this client's patients
        client_df = df[df[COL_PATIENT_ID].isin(c_patients)].copy()
        client_images = set(client_df[COL_IMAGE_INDEX])

        # Verify no image overlap
        img_overlap = all_assigned_images.intersection(client_images)
        if len(img_overlap) > 0:
            raise ValueError(f"Image overlap detected in {c_id}: {img_overlap}")

        all_assigned_images.update(client_images)

        # Compute full label distribution for this client
        label_counts: Dict[str, int] = {}
        for finding_str in client_df[COL_FINDING_LABELS].dropna():
            for label in str(finding_str).split("|"):
                cleaned = label.strip()
                if cleaned:
                    label_counts[cleaned] = label_counts.get(cleaned, 0) + 1

        partitions[c_id] = {
            "client_id": c_id,
            "patient_count": len(c_patients),
            "image_count": len(client_df),
            "patient_ids": sorted(list(c_patients)),
            "label_distribution": dict(sorted(label_counts.items(), key=lambda x: x[1], reverse=True)),
            "client_df": client_df,
        }

    # Verify 100% patient coverage
    total_unique_patients = df[COL_PATIENT_ID].nunique()
    if len(all_assigned_patients) != total_unique_patients:
        raise ValueError(
            f"Patient coverage mismatch! Assigned {len(all_assigned_patients)} of {total_unique_patients}"
        )

    # Verify 100% image coverage
    if len(all_assigned_images) != len(df):
        raise ValueError(
            f"Image coverage mismatch! Assigned {len(all_assigned_images)} of {len(df)}"
        )

    return partitions


def save_partition_manifests(
    partitions: Dict[str, dict],
    output_dir: Path,
    metadata_info: Optional[dict] = None,
) -> Dict[str, str]:
    """Save lightweight metadata manifests and summary JSON to processed_dir.

    Only CSV manifests and JSON summaries are written. NO image files are copied.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    saved_files = {}

    summary = {
        "metadata": metadata_info or {},
        "clients": {},
    }

    patient_client_rows = []

    for c_id, pdata in partitions.items():
        client_df = pdata["client_df"]
        manifest_filename = f"{c_id}_manifest.csv"
        manifest_path = output_dir / manifest_filename

        # Save client manifest with lightweight columns
        manifest_cols = [
            COL_IMAGE_INDEX,
            COL_PATIENT_ID,
            COL_FINDING_LABELS,
            COL_PATIENT_AGE,
            COL_PATIENT_GENDER,
            COL_VIEW_POSITION,
        ]
        if "relative_path" in client_df.columns:
            manifest_cols.append("relative_path")

        client_df[manifest_cols].to_csv(manifest_path, index=False)
        saved_files[manifest_filename] = str(manifest_path)

        # Collect patient-to-client rows
        for pid in pdata["patient_ids"]:
            patient_client_rows.append({"patient_id": pid, "client_id": c_id})

        # Summary telemetry
        summary["clients"][c_id] = {
            "patient_count": pdata["patient_count"],
            "image_count": pdata["image_count"],
            "label_distribution": pdata["label_distribution"],
            "manifest_file": manifest_filename,
        }

    # Save complete patient-client mapping
    alloc_path = output_dir / "patient_client_allocation.csv"
    pd.DataFrame(patient_client_rows).to_csv(alloc_path, index=False)
    saved_files["patient_client_allocation.csv"] = str(alloc_path)

    # Save summary JSON
    summary_path = output_dir / "partitions_summary.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    saved_files["partitions_summary.json"] = str(summary_path)

    return saved_files


def generate_federated_partitions(config_path: Optional[Path] = None) -> Tuple[Dict[str, dict], Dict[str, str]]:
    """Execute end-to-end patient-wise indexing and non-IID partitioning."""
    cfg = load_config(config_path)

    raw_dir = Path(cfg["dataset"]["raw_dir"])
    base_dir = Path(__file__).resolve().parent.parent
    processed_dir = base_dir / cfg["dataset"]["processed_dir"]

    num_clients = cfg["partitioning"]["num_clients"]
    dirichlet_alpha = cfg["partitioning"]["dirichlet_alpha"]
    seed = cfg["project"]["seed"]

    # 1. Build image index (strings only, no pixels in RAM)
    image_index = build_image_index(raw_dir)

    # 2. Load metadata CSV and associate paths
    csv_path = raw_dir / "Data_Entry_2017.csv"
    df = load_nih_metadata(csv_path, image_index=image_index)

    # 3. Partition patients non-IID with reproducibility
    partitions = partition_patients_non_iid(
        df=df,
        num_clients=num_clients,
        dirichlet_alpha=dirichlet_alpha,
        seed=seed,
    )

    # 4. Save lightweight manifests
    metadata_info = {
        "dataset": "NIH ChestX-ray14",
        "seed": seed,
        "num_clients": num_clients,
        "dirichlet_alpha": dirichlet_alpha,
        "total_patients": df[COL_PATIENT_ID].nunique(),
        "total_images": len(df),
    }
    saved_files = save_partition_manifests(partitions, processed_dir, metadata_info)

    return partitions, saved_files


if __name__ == "__main__":
    print("=" * 70)
    print("  PATIENT-WISE NON-IID FEDERATED DATA PARTITIONING")
    print("=" * 70)

    partitions, saved_files = generate_federated_partitions()

    print("\nSaved Partition Manifests (no image files copied):")
    for fname, fpath in saved_files.items():
        print(f"  - {fname:<30}: {fpath}")

    print("\nHospital Client Partitions Summary:")
    print("-" * 70)
    for c_id, pdata in partitions.items():
        print(f"\n[{c_id.upper()}]")
        print(f"  Patients    : {pdata['patient_count']:,}")
        print(f"  Images      : {pdata['image_count']:,}")
        print(f"  Top Findings:")
        top_labels = list(pdata["label_distribution"].items())[:6]
        for lbl, count in top_labels:
            print(f"    - {lbl:<20}: {count:>6,} ({count / pdata['image_count'] * 100:.1f}%)")

    print("\n" + "=" * 70)
    print("PARTITIONING COMPLETE: ALL CONSTRAINTS VERIFIED")
    print("=" * 70)

