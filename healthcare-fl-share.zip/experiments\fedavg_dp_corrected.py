"""Corrected FedAvg baseline experiment with Differential Privacy (Opacus DP-SGD).

Key corrections over fedavg_dp_baseline:
1. Optimizer-State Reset: When new global weights are loaded via set_parameters(),
   local Adam momentum (m_t) and variance (v_t) buffers are reset to eliminate
   stale momentum carry-over and noise variance accumulation across FL rounds,
   while preserving the client's Opacus PrivacyEngine and cumulative PRV privacy accountant.
2. Corrected Model Selection Rule: Checkpoint is selected using mean client validation
   F1 ONLY. If validation F1 scores tie across rounds, the EARLIEST round attaining
   the maximum F1 is retained. Neither validation loss nor ROC-AUC is used as a tie-breaker.
3. Baseline Preservation: All artifacts are written exclusively to results/fedavg_dp_corrected/,
   leaving centralized, vanilla FedAvg, and first DP baseline results 100% untouched.
4. Strict Test Isolation: The held-out test set is evaluated strictly once on the
   selected best model checkpoint at standard threshold 0.5.
"""

from pathlib import Path
import sys
import time
from typing import Any, Dict, List, Optional, Tuple
import json
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from clients.hospital_dp_client import HospitalDPClient
from data.partitioning import build_image_index
from experiments.centralized_baseline import (
    BinaryChestXrayDataset,
    evaluate_model,
    load_config,
)
from experiments.fedavg_baseline import build_client_cohorts
from models.cnn import SmallChestXrayCNN
from server.federated_server import FederatedServer


class CorrectedDPFederatedServer(FederatedServer):
    """Federated server with strict F1-only checkpoint selection (earliest round on tie)."""

    def train(
        self,
        num_rounds: int = 5,
        local_epochs: int = 1,
    ) -> Dict[str, Any]:
        """Execute full iterative FedAvg training loop with corrected model selection."""
        checkpoint_path = self.output_dir / "fedavg_dp_corrected_global_model.pt"
        history_path = self.output_dir / "fedavg_dp_corrected_training_history.json"

        round_history = []
        best_round = -1
        best_val_f1 = -1.0
        best_val_loss = float("inf")

        start_time = time.time()

        for r in range(1, num_rounds + 1):
            round_summary = self.run_round(
                server_round=r,
                local_epochs=local_epochs,
            )
            round_history.append(round_summary)

            cur_f1 = round_summary["mean_val_metrics"]["mean_val_f1"]
            cur_loss = round_summary["mean_val_metrics"]["mean_val_loss"]

            # Corrected Model Selection Rule (Requirement 6):
            # Select using mean client validation F1 ONLY.
            # If scores tie, retain the EARLIEST round attaining the maximum F1.
            # Do NOT use validation loss or ROC-AUC as a tie-breaker.
            is_better = cur_f1 > best_val_f1

            if is_better:
                best_val_f1 = cur_f1
                best_val_loss = cur_loss
                best_round = r
                torch.save(
                    {
                        "round": r,
                        "model_state_dict": self.model.state_dict(),
                        "mean_val_f1": best_val_f1,
                        "mean_val_loss": best_val_loss,
                    },
                    checkpoint_path,
                )

        total_duration = time.time() - start_time

        # Held-Out Test Set Evaluation: Evaluated strictly ONCE on the selected best model
        assert checkpoint_path.exists(), "Best model checkpoint was not saved!"
        best_checkpoint = torch.load(
            checkpoint_path, map_location=self.device, weights_only=False
        )
        self.model.load_state_dict(best_checkpoint["model_state_dict"])
        test_metrics = evaluate_model(
            model=self.model,
            loader=self.test_loader,
            criterion=self.criterion,
            device=self.device,
        )
        test_metrics["sample_count"] = len(self.test_loader.dataset)

        history = {
            "best_round": best_round,
            "best_val_f1": best_val_f1,
            "best_val_loss": best_val_loss,
            "training_duration_seconds": round(total_duration, 2),
            "rounds": round_history,
            "held_out_test_metrics": test_metrics,
        }

        with open(history_path, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)

        return history


def run_fedavg_dp_corrected_experiment(
    num_rounds: int = 5,
    local_epochs: int = 1,
    samples_per_client: int = 60,
    batch_size: int = 16,
    noise_multiplier: float = 1.0,
    max_grad_norm: float = 1.0,
    learning_rate: float = 1e-3,
    target_delta: float = 1e-5,
    image_size: Tuple[int, int] = (224, 224),
    seed: int = 42,
    config_path: Optional[Path] = None,
    output_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Execute end-to-end corrected FedAvg + DP-SGD experiment across 5 hospital clients."""
    # 1. Deterministic seeding
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 2. Paths and configuration
    cfg = load_config(config_path)
    raw_dir = Path(cfg["dataset"]["raw_dir"])
    proc_dir = BASE_DIR / cfg["dataset"]["processed_dir"]

    if output_dir is None:
        output_dir = BASE_DIR / "results" / "fedavg_dp_corrected"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 3. Load centralized test split (strictly preserved and held out)
    central_test_path = BASE_DIR / "results" / "centralized_baseline" / "test_split.csv"
    if not central_test_path.exists():
        raise FileNotFoundError(f"Centralized test split not found at: {central_test_path}")

    test_df = pd.read_csv(central_test_path)
    test_patient_ids = set(test_df["Patient ID"])
    test_ds = BinaryChestXrayDataset(test_df, raw_dir, image_size=image_size)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)

    # 4. Build image index for fast lookup
    image_index = build_image_index(raw_dir)

    # 5. Build patient-isolated client cohorts
    client_cohorts = build_client_cohorts(
        manifests_dir=proc_dir,
        image_index=image_index,
        test_patient_ids=test_patient_ids,
        output_dir=output_dir,
        samples_per_client=samples_per_client,
        val_ratio=0.2,
        seed=seed,
    )

    # 6. Initialize HospitalDPClient instances with reset_optimizer_on_set_params=True
    clients: List[HospitalDPClient] = []
    for c in range(1, 6):
        client_id = f"hospital_{c}"
        train_df = client_cohorts[client_id]["train"]
        val_df = client_cohorts[client_id]["val"]

        train_ds = BinaryChestXrayDataset(train_df, raw_dir, image_size=image_size)
        val_ds = BinaryChestXrayDataset(val_df, raw_dir, image_size=image_size)

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)

        client_model = SmallChestXrayCNN(
            in_channels=1,
            num_classes=1,
            num_groups=4,
            dropout=0.1,
        ).to(device)

        client = HospitalDPClient(
            client_id=client_id,
            train_loader=train_loader,
            val_loader=val_loader,
            model=client_model,
            device=device,
            noise_multiplier=noise_multiplier,
            max_grad_norm=max_grad_norm,
            learning_rate=learning_rate,
            target_delta=target_delta,
            reset_optimizer_on_set_params=True,  # Corrected: reset Adam state on weight sync
        )
        clients.append(client)

    # 7. Initialize Global Server Model and Corrected Orchestrator
    global_model = SmallChestXrayCNN(
        in_channels=1,
        num_classes=1,
        num_groups=4,
        dropout=0.1,
    ).to(device)

    server = CorrectedDPFederatedServer(
        model=global_model,
        clients=clients,
        test_loader=test_loader,
        device=device,
        output_dir=output_dir,
    )

    # 8. Run Federated Training
    base_history = server.train(
        num_rounds=num_rounds,
        local_epochs=local_epochs,
    )

    # 9. Extract final privacy accounting details from clients
    final_client_privacy = {}
    for client in clients:
        eps = float(client.privacy_engine.get_epsilon(delta=target_delta))
        final_client_privacy[client.client_id] = {
            "epsilon": eps,
            "delta": target_delta,
            "sample_rate": client.sample_rate,
            "total_steps": sum(entry[2] for entry in client.privacy_engine.accountant.history) if client.privacy_engine.accountant.history else 0,
        }

    checkpoint_path = output_dir / "fedavg_dp_corrected_global_model.pt"

    dp_history = {
        "experiment": "fedavg_dp_corrected",
        "privacy_mechanism": "opacus_dp_sgd",
        "privacy_unit": "patient_level_within_client",
        "accountant_type": "PRVAccountant",
        "poisson_sampling": True,
        "optimizer_reset_on_set_params": True,
        "selection_rule": "strict_mean_val_f1_earliest_tie",
        "decision_threshold": 0.5,
        "noise_multiplier": noise_multiplier,
        "max_grad_norm": max_grad_norm,
        "target_delta": target_delta,
        "num_rounds": num_rounds,
        "local_epochs": local_epochs,
        "num_clients": len(clients),
        "best_round": base_history["best_round"],
        "best_val_f1": base_history["best_val_f1"],
        "best_val_loss": base_history["best_val_loss"],
        "training_duration_seconds": base_history["training_duration_seconds"],
        "rounds": base_history["rounds"],
        "held_out_test_metrics": base_history["held_out_test_metrics"],
        "final_client_privacy": final_client_privacy,
        "checkpoint_path": str(checkpoint_path.resolve()),
    }

    history_path = output_dir / "fedavg_dp_corrected_training_history.json"
    with open(history_path, "w", encoding="utf-8") as f:
        json.dump(dp_history, f, indent=2)

    return dp_history


if __name__ == "__main__":
    run_fedavg_dp_corrected_experiment()

