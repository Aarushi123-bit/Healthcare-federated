# Project Progress & Submission Log

This log tracks the progress of the healthcare federated learning project across all implementation, evaluation, verification, and submission phases.

---

## Phase 1 — Audit and Preserve Completed Experiment
- **Status:** **COMPLETE**
- **Artifacts Verified:**
  - All 42 protected baseline artifacts across `results/centralized_baseline/` (6), `results/fedavg_baseline/` (12), `results/fedavg_dp_baseline/` (12), and `results/fedavg_dp_corrected/` (12) were cryptographically verified using SHA256 digests. 100% matched.
  - All 12 artifacts in `results/fedavg_dp_3epoch/` (checkpoint, JSON history, and 10 client cohort manifests) were cryptographically verified against `results/fedavg_dp_3epoch_integrity_hashes.json`. 100% matched.
- **Experimental Findings from Saved History (`results/fedavg_dp_3epoch/`):**
  - **Completed Rounds:** Exactly 2 rounds completed.
  - **Budget Halting Rule:** Training halted dynamically before Round 3 because projected $\epsilon = 12.1878 > 10.0$ at $\delta = 10^{-5}$.
  - **Per-Client Steps:** Exactly 9 optimizer steps in Round 1, 9 optimizer steps in Round 2 (18 cumulative steps per client).
  - **Realized Privacy Expenditure:** $\epsilon = 7.2074$ after Round 1; $\epsilon = 9.9496 \le 10.0$ after Round 2 at $\delta = 10^{-5}$.
  - **Mean Validation Metrics:**
    - Round 1: Loss = 0.6957, F1 = 0.0000, ROC-AUC = 0.6167.
    - Round 2: Loss = 0.6946, F1 = 0.0000, ROC-AUC = 0.7278.
  - **Checkpoint Selection:** Round 1 selected under strict validation F1 tie-breaking (earliest round on tie).
  - **One-Time Held-Out Test Evaluation ($N=30$):**
    - Accuracy = 50.00% (15/30), F1 = 0.0000, Precision = 0.0000, Recall = 0.0000, ROC-AUC = 0.5067, BCE Loss = 0.6982.
    - Confusion Matrix: `[[15, 0], [15, 0]]` (all-negative predictions at threshold 0.50).
- **Repository Integrity:** No git repository initialized. Existing user files and baselines are completely intact and unmodified.

---

## Phase 2 — Validate Implementation and Tests
- **Status:** **COMPLETE**
- **Implementation Audit:**
  - **Data Partitioning & Isolation:** In `data/partitioning.py` and `experiments/fedavg_baseline.py` (`build_client_cohorts`), verified strict patient disjointness: $\text{Patients}(C_i) \cap \text{Patients}(C_j) = \emptyset$, $\text{Patients}(\text{Train}) \cap \text{Patients}(\text{Val}) = \emptyset$, and $\text{Patients}(C_i) \cap \text{Patients}(\text{Test}) = \emptyset$. Clean controls are strictly guaranteed (patients who never had pneumonia across the entire NIH dataset).
  - **Model Architecture:** `SmallChestXrayCNN` complies strictly with Opacus requirements via Group Normalization (`num_groups=4`, no BatchNorm to prevent inter-sample gradient leakage).
  - **Local DP-SGD Mechanics:** Verified Poisson subsampling ($q = 16/48 = 0.3333$), per-sample gradient clipping ($C = 1.0$), Gaussian noise multiplier ($\sigma = 1.0$), and target delta ($\delta = 10^{-5}$).
  - **Adam State Reset:** Verified `reset_optimizer_on_set_params=True` clears Adam momentum and variance state on each round's parameter update, preventing stale momentum leakage across rounds while maintaining live Opacus `PRVAccountant` persistence.
  - **Aggregation Weights:** Verified Flower sample-weighted averaging ($\theta = \sum_k \frac{n_k}{N} \theta_k$) assigns equal $1/5$ weight to each balanced client ($n_k = 48$).
  - **Dynamic Privacy Budget Guard:** Verified `DP3EpochFederatedServer.train` computes non-mutating projections of each client's PRV accountant prior to executing each round, halting before Round 3 without any optimizer steps executed in Round 3.
  - **Model Selection & Test Evaluation:** Checkpoint selected strictly on mean client validation F1 at fixed threshold $0.50$ (earliest on tie). Test set was evaluated strictly once at the end.
- **Test Suite Results:**
  - `healthcare-fl/tests/test_fedavg_dp_3epoch.py`: 8 passed, 0 failed.
  - `healthcare-fl/tests/test_partitioning.py`, `test_cnn_data_loading.py`, `test_fedavg.py`: 18 passed, 0 failed.
  - Total: 26 passed, 0 failed. Zero test set leakage.

---

## Phase 3 — Experimental Analysis
- **Status:** **COMPLETE**
- **Cross-Experiment Comparison Matrix:**
  | Metric | Centralized Baseline | Vanilla FedAvg Baseline | FedAvg + DP Baseline | FedAvg + DP (Corrected) | FedAvg + DP ($E=3$) |
  | :--- | :---: | :---: | :---: | :---: | :---: |
  | **Training Paradigm** | Centralized ML | 5-Hospital FedAvg | 5-Hospital FedAvg + DP | 5-Hospital FedAvg + DP | 5-Hospital FedAvg + DP |
  | **Local Epochs ($E$)** | 5 (Global Epochs) | 1 Epoch/Round | 1 Epoch/Round | 1 Epoch/Round | **3 Epochs/Round** |
  | **Rounds Completed** | N/A | 5 Rounds | 5 Rounds | 5 Rounds | **2 Rounds (Budget Stop)** |
  | **Optimizer Steps/Client**| 15 (Global Steps) | 15 Steps | 15 Steps | 15 Steps | **18 Steps** |
  | **Privacy ($\epsilon, \delta=10^{-5}$)** | None ($\infty$) | None ($\infty$) | $\epsilon = 9.1137$ | $\epsilon = 9.1137$ | $\mathbf{\epsilon = 9.9496 \le 10.0}$ |
  | **Best Val Selection** | Epoch 2 | Round 3 | Round 3 (Loss tie-breaker) | Round 1 (Earliest tie) | **Round 1 (Earliest tie)** |
  | **Best Val F1** | **0.7586** | **0.6824** | 0.0000 | 0.0000 | **0.0000** |
  | **Val ROC-AUC (Final Round)**| 0.8125 | 0.7389 | 0.6333 | 0.5722 | **0.7278** |
  | **Held-Out Test Accuracy**| **76.67%** (23/30) | **56.67%** (17/30) | 50.00% (15/30) | 50.00% (15/30) | **50.00%** (15/30) |
  | **Held-Out Test Precision**| **0.8333** | **0.5417** | 0.0000 | 0.0000 | **0.0000** |
  | **Held-Out Test Recall** | **0.6667** | **0.8667** | 0.0000 | 0.0000 | **0.0000** |
  | **Held-Out Test F1** | **0.7407** | **0.6667** | 0.0000 | 0.0000 | **0.0000** |
  | **Held-Out Test ROC-AUC** | **0.8400** | **0.7556** | 0.5022 | 0.4400 | **0.5067** |
  | **Held-Out Test Loss** | 0.5518 | 0.6708 | 0.6989 | 0.7001 | **0.6982** |
  | **Test Confusion Matrix** | `[[13, 2], [5, 10]]` | `[[4, 11], [2, 13]]` | `[[15, 0], [15, 0]]` | `[[15, 0], [15, 0]]` | `[[15, 0], [15, 0]]` |
- **Clinical & Empirical Insights:**
  - **Representation Learning vs. Calibration:** In `fedavg_dp_3epoch`, mean validation ROC-AUC progressed from $0.6167$ in Round 1 to **$0.7278$ in Round 2**, indicating that multi-epoch local training allowed the network to learn feature representations approaching non-private FedAvg (ROC-AUC $0.7389$).
  - **The Default Threshold Issue:** Differential privacy noise ($\sigma = 1.0$) combined with small sample batches causes model output logits to remain concentrated below zero ($p < 0.50$). Consequently, uncalibrated binary predictions at threshold $0.50$ classify all held-out cases as negative ($\text{FN}=15, \text{TN}=15, \text{TP}=0, \text{FP}=0$).
  - **Sample Size Context:** The held-out test split is purposefully small ($N=30$) to preserve sample volume for multi-client partitioning. It provides a clean, unbiased benchmark, but has high sensitivity to discrete threshold boundaries.

---

## Phase 4 — Plots and Interpretation
- **Status:** **COMPLETE**
- **Generated Plots (saved in `results/submission/plots/`):**
  1. `val_roc_auc_by_round.png`: Tracks mean client validation ROC-AUC across rounds, illustrating the jump from $0.6167$ to $0.7278$ under $E=3$ before halting at Round 3, compared with $E=1$ trajectories.
  2. `test_accuracy_f1_comparison.png`: Grouped bar chart comparing held-out test accuracy and test F1 across Centralized (76.7% / 74.1%), Vanilla FedAvg (56.7% / 66.7%), and DP variants (50.0% / 0.0%) under the fixed threshold 0.50.
  3. `cumulative_epsilon_vs_steps.png`: Shows privacy accounting trajectories ($\epsilon$ at $\delta = 10^{-5}$) versus cumulative optimizer steps for $E=1$ (15 steps, $\epsilon = 9.1137$) and $E=3$ (18 steps, $\epsilon = 9.9496$), with the red budget limit at $\epsilon = 10.0$ and the projected Round 3 halt point at 27 steps ($\epsilon = 12.1878$).
  4. `per_client_validation_variation.png`: Bar chart of individual hospital validation ROC-AUC scores in Round 2, showing inter-client heterogeneity across the 5 simulated hospital cohorts.
- **Fair Comparison Note:** Documented that $E=3$ ran 2 rounds (18 steps) under the budget guard, whereas $E=1$ ran 5 rounds (15 steps). They are not matched in communication frequency, but operate under the same cumulative privacy envelope ($\epsilon \approx 9 - 10, \delta = 10^{-5}$).

---

## Phase 5 — Final Verification
- **Status:** **COMPLETE**
- **Comprehensive Test Suite Execution:**
  - Command: `healthcare-fl\.venv\Scripts\pytest.exe healthcare-fl\tests\test_fedavg_dp_3epoch.py healthcare-fl\tests\test_partitioning.py healthcare-fl\tests\test_cnn_data_loading.py healthcare-fl\tests\test_fedavg.py -v`
  - Results: **26 passed, 0 failed, 12 warnings** in 53.23s.
  - Zero test set leakage: All tests strictly use synthetic data loaders or check static properties; the held-out centralized test set was never loaded or evaluated during testing.
- **Artifact Hash Verification:**
  - All 42 protected baseline artifacts: **100% MATCH**.
  - All 12 `fedavg_dp_3epoch` artifacts: **100% MATCH**.
- **Submission Package Cleanliness:**
  - `results/submission/` inspected recursively.
  - Verified that no raw image files, credentials, cache blobs, virtual environment files, or unnecessary model binaries are included in `results/submission/`. Only documentation and plots are present.

---

## Phase 6 — Submission Documentation
- **Status:** **COMPLETE**
- **Created Submission Documents (in `results/submission/`):**
  1. `IMPLEMENTATION_GUIDE.md`: Comprehensive technical and mathematical guide detailing system architecture, patient-level isolation, Opacus DP-SGD mechanics, Adam state resets, PRV accounting, and dynamic budget projection.
  2. `RESULTS_SUMMARY.md`: Full cross-experiment comparison matrix, round progression tables, confusion matrices, and in-depth analysis of logit suppression and default decision threshold effects.
  3. `KNOWN_LIMITATIONS.md`: Academic simulation disclaimer, single-source public dataset constraints, small test set sensitivity ($N=30$), binary simplification, and clinical calibration requirements.
  4. `TEST_REPORT.md`: Granular audit of all 26 passing tests across 4 test suites, execution commands, durations, upstream warning audits, and test set isolation guarantees.
  5. `REPRODUCIBILITY.md`: Environment setup instructions, reproduction commands, and master cryptographic registry of all 54 SHA256 artifact hashes.
  6. `PROGRESS.md`: Complete chronological log of sequential execution across all phases.
- **README Updates:** Updated project `README.md` to accurately document the NIH ChestX-ray14 architecture, 5-baseline comparative results, key scientific findings, quickstart commands, and links to submission documentation.

---

## Phase 7 — Final Submission Readiness
- **Status:** **COMPLETE**
- **Verification of Consistency:** All source code, test results, figures, documentation, and file paths have been verified for 100% internal consistency.
- **Scientific Audit Completed:**
  - Qualified all privacy statements: clarified that $\epsilon = 9.9496$ at $\delta = 10^{-5}$ represents a bounded privacy loss random variable whose practical protection depends on the threat model and adversary background knowledge.
  - Clarified checkpoint selection: explicitly noted that in `fedavg_dp_3epoch`, Round 1 was selected under earliest-round tie-breaking (Val F1 = 0.0, Val ROC-AUC = 0.6167), and that Round 2 (Val ROC-AUC = 0.7278) was not the model evaluated on the held-out test set.
  - Clarified Normalization choice: accurately explained that standard BatchNorm couples activations across mini-batch samples in standard DP-SGD implementations, requiring sample-independent normalization like GroupNorm (`num_groups=4`).
  - Clarified dataset scope: stated that the 5 simulated hospital clients and the 30-sample test cohort are synthetic, patient-isolated partitions subsampled from the NIH ChestX-ray14 public dataset.
- **Master Artifact Registry:** 54 artifacts verified bit-exact via SHA256 (42 protected baseline artifacts + 12 `fedavg_dp_3epoch` artifacts).
- **Final Test Verification:** 26 passed, 0 failed, 12 warnings across all 4 core test suites.
- **Zero Test Set Leakage:** Held-out test set evaluated strictly once; all unit and integration tests strictly use synthetic data loaders.
- **Readiness:** Submission package is fully assembled in `results/submission/` and ready for faculty review and project presentation.

---

