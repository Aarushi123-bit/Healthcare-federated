"""Model architectures module for healthcare diagnostic networks."""

from models.cnn import SmallChestXrayCNN

__all__ = ["SmallChestXrayCNN"]
