"""Smoke test and environment verification with synthetic hospital partitions.

DISCLAIMER:
All data generated in this script is strictly SYNTHETIC TEST DATA
generated for software verification. It does NOT represent or contain
any real medical or patient information.
"""

from pathlib import Path
import numpy as np
import pytest
import yaml

# ------------------------------------------------------------------------------
# 1. Environment & Package Verification Helper
# ------------------------------------------------------------------------------


def check_required_imports():
    """Verify that core research libraries can be imported without error."""
    results = {}

    import torch

    results["torch"] = torch.__version__

    import flwr

    results["flwr"] = flwr.__version__

    import opacus

    results["opacus"] = opacus.__version__

    import sklearn

    results["sklearn"] = sklearn.__version__

    results["numpy"] = np.__version__

    return results


# ------------------------------------------------------------------------------
# 2. Config Loader Helper
# ------------------------------------------------------------------------------


def load_project_config(config_path: Path = None) -> dict:
    """Load and parse the project configuration YAML file."""
    if config_path is None:
        # Resolve config.yaml relative to this test file or current directory
        base_dir = Path(__file__).resolve().parent.parent
        config_path = base_dir / "config.yaml"
        if not config_path.exists():
            config_path = Path("config.yaml").resolve()

    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found at: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    return config


# ------------------------------------------------------------------------------
# 3. Synthetic Data Generator & Disjoint Partitioning Helper
# ------------------------------------------------------------------------------


def generate_synthetic_hospital_partitions(
    num_clients: int = 5,
    samples_per_client: int = 50,
    num_features: int = 10,
    seed: int = 42,
) -> dict:
    """Generate a small synthetic binary-classification dataset and partition it

    across simulated hospital clients without any sample index overlap.

    NOTE: This is synthetic benchmark data for testing purposes only,
    NOT medical data.
    """
    from sklearn.datasets import make_classification

    total_samples = num_clients * samples_per_client

    # 1. Generate synthetic binary classification dataset
    X_synthetic, y_synthetic = make_classification(
        n_samples=total_samples,
        n_features=num_features,
        n_informative=6,
        n_redundant=2,
        n_classes=2,
        random_state=seed,
    )

    # Global sample indices: [0, 1, 2, ..., total_samples - 1]
    global_indices = np.arange(total_samples)

    # 2. Shuffle indices reproducibly using the specified seed
    rng = np.random.RandomState(seed)
    shuffled_indices = rng.permutation(global_indices)

    # 3. Partition indices into disjoint subsets for each simulated hospital
    partitions = {}
    for client_idx in range(num_clients):
        start_idx = client_idx * samples_per_client
        end_idx = start_idx + samples_per_client
        client_sample_indices = shuffled_indices[start_idx:end_idx]

        client_key = f"hospital_client_{client_idx + 1}"
        partitions[client_key] = {
            "client_id": client_key,
            "sample_indices": client_sample_indices,
            "X": X_synthetic[client_sample_indices],
            "y": y_synthetic[client_sample_indices],
            "data_classification": "SYNTHETIC_TEST_DATA",
            "is_medical_data": False,
            "sample_count": len(client_sample_indices),
        }

    dataset_bundle = {
        "metadata": {
            "data_type": "SYNTHETIC_TEST_DATA",
            "is_medical_data": False,
            "disclaimer": "This is synthetic test data only. Not clinical or medical data.",
            "num_clients": num_clients,
            "total_samples": total_samples,
            "num_features": num_features,
            "seed": seed,
        },
        "clients": partitions,
    }

    return dataset_bundle


# ------------------------------------------------------------------------------
# 4. PyTest Test Suite
# ------------------------------------------------------------------------------


def test_required_imports():
    """Test 1: Verify PyTorch, Flower, Opacus, NumPy, and scikit-learn import cleanly."""
    imported_versions = check_required_imports()

    assert "torch" in imported_versions, "PyTorch import failed."
    assert "flwr" in imported_versions, "Flower (flwr) import failed."
    assert "opacus" in imported_versions, "Opacus import failed."
    assert "numpy" in imported_versions, "NumPy import failed."
    assert "sklearn" in imported_versions, "scikit-learn import failed."


def test_config_loading_and_seed():
    """Test 2: Verify config.yaml can be read and contains the expected seed and client count."""
    config = load_project_config()

    assert "project" in config, "Missing 'project' section in config.yaml"
    assert "seed" in config["project"], "Missing 'seed' in config.yaml project section"
    assert config["project"]["seed"] == 42, f"Expected seed 42, got {config['project']['seed']}"

    assert "partitioning" in config, "Missing 'partitioning' section in config.yaml"
    assert config["partitioning"]["num_clients"] == 5, (
        f"Expected 5 clients, got {config['partitioning']['num_clients']}"
    )


def test_synthetic_data_labeling_and_structure():
    """Test 3: Verify synthetic dataset is created and clearly labeled as test data, not medical data."""
    config = load_project_config()
    seed = config["project"]["seed"]
    num_clients = config["partitioning"]["num_clients"]

    bundle = generate_synthetic_hospital_partitions(
        num_clients=num_clients,
        samples_per_client=50,
        num_features=10,
        seed=seed,
    )

    metadata = bundle["metadata"]
    assert metadata["is_medical_data"] is False, "Metadata must explicitly state is_medical_data is False"
    assert metadata["data_type"] == "SYNTHETIC_TEST_DATA", "Dataset must be labeled as SYNTHETIC_TEST_DATA"

    for client_key, client_data in bundle["clients"].items():
        assert client_data["is_medical_data"] is False
        assert client_data["data_classification"] == "SYNTHETIC_TEST_DATA"
        # Verify binary classification labels: only 0 and 1
        unique_labels = set(np.unique(client_data["y"]))
        assert unique_labels.issubset({0, 1}), f"Labels must be binary (0 or 1), got {unique_labels}"


def test_client_partitions_data_presence_and_no_overlap():
    """Test 4: Verify that all five simulated clients have data and no sample indices overlap."""
    config = load_project_config()
    seed = config["project"]["seed"]
    num_clients = config["partitioning"]["num_clients"]

    bundle = generate_synthetic_hospital_partitions(
        num_clients=num_clients,
        samples_per_client=50,
        num_features=10,
        seed=seed,
    )

    clients = bundle["clients"]

    # 1. Verify there are data partitions for all 5 clients
    assert len(clients) == 5, f"Expected 5 clients, but got {len(clients)}"

    all_client_indices = []
    for client_key, client_data in clients.items():
        indices = client_data["sample_indices"]
        # Verify each client has positive data count
        assert len(indices) > 0, f"{client_key} has no assigned samples!"
        assert client_data["sample_count"] == len(indices)
        assert len(client_data["X"]) == len(indices)
        assert len(client_data["y"]) == len(indices)
        all_client_indices.append(set(indices))

    # 2. Pairwise verification: no overlapping sample indices between any two clients
    for i in range(len(all_client_indices)):
        for j in range(i + 1, len(all_client_indices)):
            overlap = all_client_indices[i].intersection(all_client_indices[j])
            assert len(overlap) == 0, (
                f"Overlap detected between client {i+1} and client {j+1}: {overlap}"
            )

    # 3. Overall disjointness check: union size equals sum of individual partition sizes
    total_unique_indices = len(set().union(*all_client_indices))
    total_assigned_indices = sum(len(indices_set) for indices_set in all_client_indices)
    assert total_unique_indices == total_assigned_indices, (
        f"Indices overlap detected: unique count {total_unique_indices} != total assigned {total_assigned_indices}"
    )


def test_reproducibility_with_seed():
    """Test 5: Verify that identical seeds from config.yaml produce exactly identical splits."""
    config = load_project_config()
    seed = config["project"]["seed"]
    num_clients = config["partitioning"]["num_clients"]

    run_1 = generate_synthetic_hospital_partitions(num_clients=num_clients, seed=seed)
    run_2 = generate_synthetic_hospital_partitions(num_clients=num_clients, seed=seed)
    run_different_seed = generate_synthetic_hospital_partitions(num_clients=num_clients, seed=seed + 999)

    for client_key in run_1["clients"]:
        # Identical runs must produce identical sample indices
        np.testing.assert_array_equal(
            run_1["clients"][client_key]["sample_indices"],
            run_2["clients"][client_key]["sample_indices"],
            err_msg=f"Indices for {client_key} did not match across runs with identical seed.",
        )
        # Identical runs must produce identical feature arrays
        np.testing.assert_allclose(
            run_1["clients"][client_key]["X"],
            run_2["clients"][client_key]["X"],
            err_msg=f"Features for {client_key} did not match across runs with identical seed.",
        )

    # A different seed should produce different index assignments
    indices_run_1 = run_1["clients"]["hospital_client_1"]["sample_indices"]
    indices_diff = run_different_seed["clients"]["hospital_client_1"]["sample_indices"]
    assert not np.array_equal(indices_run_1, indices_diff), (
        "Different seeds unexpectedly produced identical sample indices."
    )


# ------------------------------------------------------------------------------
# 5. Standalone Execution Entrypoint
# ------------------------------------------------------------------------------


def run_smoke_test_cli():
    """Run all smoke test checks sequentially and print beginner-friendly progress."""
    print("=" * 70)
    print("  PRIVACY-PRESERVING FEDERATED LEARNING - SMOKE TEST")
    print("=" * 70)

    print("\n[Step 1/5] Checking Required Package Imports...")
    imports = check_required_imports()
    for pkg, ver in imports.items():
        print(f"  - {pkg:<12} : v{ver} [OK]")

    print("\n[Step 2/5] Reading Configuration (config.yaml)...")
    config = load_project_config()
    seed = config["project"]["seed"]
    num_clients = config["partitioning"]["num_clients"]
    print(f"  - Project Name      : {config['project']['name']}")
    print(f"  - Random Seed       : {seed}")
    print(f"  - Hospital Clients  : {num_clients}")

    print("\n[Step 3/5] Generating Synthetic Benchmark Dataset...")
    bundle = generate_synthetic_hospital_partitions(
        num_clients=num_clients,
        samples_per_client=50,
        num_features=10,
        seed=seed,
    )
    meta = bundle["metadata"]
    print(f"  - Data Classification : {meta['data_type']}")
    print(f"  - Disclaimer          : {meta['disclaimer']}")
    print(f"  - Total Test Samples  : {meta['total_samples']}")
    print(f"  - Feature Dimension   : {meta['num_features']}")

    print("\n[Step 4/5] Verifying 5 Simulated Hospital Partitions & Index Isolation...")
    clients = bundle["clients"]
    all_indices = []
    for client_key, cdata in clients.items():
        indices = cdata["sample_indices"]
        all_indices.append(set(indices))
        label_dist = dict(zip(*np.unique(cdata["y"], return_counts=True)))
        print(
            f"  - {client_key:<20}: {len(indices)} samples | "
            f"Indices range [{indices.min():3d} - {indices.max():3d}] | "
            f"Class balance {label_dist}"
        )

    # Check for index overlaps
    for i in range(len(all_indices)):
        for j in range(i + 1, len(all_indices)):
            overlap = all_indices[i].intersection(all_indices[j])
            assert len(overlap) == 0, f"Overlap between client {i+1} and {j+1}!"

    total_unique = len(set().union(*all_indices))
    total_assigned = sum(len(s) for s in all_indices)
    assert total_unique == total_assigned == meta["total_samples"]
    print(f"  - Non-overlapping Disjoint Check: PASSED (0 index collisions among {num_clients} clients)")

    print("\n[Step 5/5] Testing Reproducibility with Seed = 42...")
    bundle_repeat = generate_synthetic_hospital_partitions(num_clients=num_clients, seed=seed)
    for c_id in clients:
        np.testing.assert_array_equal(
            clients[c_id]["sample_indices"],
            bundle_repeat["clients"][c_id]["sample_indices"],
        )
    print("  - Seed Reproducibility Check: PASSED (Identical partitions across repeated runs)")

    print("\n" + "=" * 70)
    print("SMOKE TEST SUMMARY: ALL 5 CHECKS PASSED SUCCESSFULLY")
    print("Note: CNN, Differential Privacy mechanisms, and Federated training")
    print("are intentionally deferred to subsequent implementation phases.")
    print("=" * 70)


if __name__ == "__main__":
    run_smoke_test_cli()

