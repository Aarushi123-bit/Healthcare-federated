"""Simulated federated clients module."""

from clients.hospital_client import HospitalClient
from clients.hospital_dp_client import HospitalDPClient

__all__ = ["HospitalClient", "HospitalDPClient"]
