"""Hospital Client implementation for Privacy-Preserving Federated Learning.

Subclasses Flower's NumPyClient to enable standardized federated model
training and validation across distributed hospital nodes.
"""

from collections import OrderedDict
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from flwr.client import NumPyClient


class HospitalClient(NumPyClient):
    """Flower NumPyClient simulating a hospital node training on local radiograph data."""

    def __init__(
        self,
        client_id: str,
        train_loader: DataLoader,
        val_loader: DataLoader,
        model: nn.Module,
        device: torch.device,
        learning_rate: float = 1e-3,
        weight_decay: float = 1e-4,
    ):
        self.client_id = client_id
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.model = model
        self.device = device
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.criterion = nn.BCEWithLogitsLoss()

    def get_parameters(self, config: Optional[Dict[str, Any]] = None) -> List[np.ndarray]:
        """Extract local model weights as a list of NumPy ndarrays."""
        return [val.cpu().numpy() for _, val in self.model.state_dict().items()]

    def set_parameters(self, parameters: List[np.ndarray]) -> None:
        """Update local model weights from a list of NumPy ndarrays."""
        params_dict = zip(self.model.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.as_tensor(v) for k, v in params_dict})
        self.model.load_state_dict(state_dict, strict=True)

    def fit(
        self,
        parameters: List[np.ndarray],
        config: Dict[str, Any],
    ) -> Tuple[List[np.ndarray], int, Dict[str, Any]]:
        """Perform local training on hospital client data for local_epochs."""
        self.set_parameters(parameters)
        local_epochs = int(config.get("local_epochs", 1))

        optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )

        self.model.train()
        total_loss = 0.0

        for epoch in range(local_epochs):
            epoch_loss = 0.0
            for batch_imgs, batch_lbls, _ in self.train_loader:
                batch_imgs = batch_imgs.to(self.device)
                batch_lbls = batch_lbls.to(self.device)

                optimizer.zero_grad()
                logits = self.model(batch_imgs)
                loss = self.criterion(logits, batch_lbls)
                loss.backward()
                optimizer.step()

                batch_size = batch_imgs.size(0)
                epoch_loss += loss.item() * batch_size
            total_loss += epoch_loss

        avg_loss = total_loss / (local_epochs * len(self.train_loader.dataset))

        return (
            self.get_parameters(),
            len(self.train_loader.dataset),
            {"train_loss": float(avg_loss), "client_id": self.client_id},
        )

    def evaluate(
        self,
        parameters: List[np.ndarray],
        config: Dict[str, Any],
    ) -> Tuple[float, int, Dict[str, Any]]:
        """Evaluate local validation set using clinical metrics."""
        from experiments.centralized_baseline import evaluate_model

        self.set_parameters(parameters)
        metrics = evaluate_model(
            model=self.model,
            loader=self.val_loader,
            criterion=self.criterion,
            device=self.device,
        )
        metrics["client_id"] = self.client_id
        return float(metrics["loss"]), len(self.val_loader.dataset), metrics

